package dev.bookwave.core.sync

import dev.bookwave.core.model.ListeningProgress

/**
 * Lightweight multi-device sync contract.
 *
 * Devices exchange full per-book progress records (they are tiny) and merge
 * them with [dev.bookwave.core.model.ProgressMerge]. A real transport (WebDAV
 * sidecar file, Dropbox file, custom backend…) is plugged in the app layer;
 * this module only defines the deterministic convergence rules.
 */
data class SyncPayload(
    val deviceId: String,
    val revision: Long,
    val entries: List<ListeningProgress>,
)

data class SyncResult(
    val merged: List<ListeningProgress>,
    val conflictsResolved: Int,
)

object SyncEngine {

    /**
     * Merges two snapshots keyed by book id. Records present on only one side
     * are kept as-is; records on both sides are merged pairwise.
     */
    fun mergeAll(local: SyncPayload, remote: SyncPayload): SyncResult {
        // v0.8.0 — indexed once instead of scanning both lists per book id
        // (the old two `firstOrNull` calls per book made a 2 000-book sync do
        // 8 million comparisons on the worker thread).
        val left = local.entries.associateBy { it.bookId }
        val right = remote.entries.associateBy { it.bookId }
        val books: Set<String> = left.keys + right.keys
        var conflicts = 0
        val merged = books.sorted().mapNotNull { id ->
            val l = left[id]
            val r = right[id]
            when {
                l == null -> r
                r == null -> l
                l == r -> l
                else -> {
                    conflicts++
                    dev.bookwave.core.model.ProgressMerge.merge(l, r)
                }
            }
        }
        return SyncResult(merged = merged, conflictsResolved = conflicts)
    }
}
