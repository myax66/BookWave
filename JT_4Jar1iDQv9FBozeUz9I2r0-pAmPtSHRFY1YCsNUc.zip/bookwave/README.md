# Bookwave 📚🎧

**Lecteur de livres audio cloud pour Android, imaginé et piloté sans savoir coder.**

> ## Je ne sais pas coder — et ce projet est **100 % vibe codé** ✨
>
> Je ne suis pas développeur et je n’ai pas écrit le code de Bookwave moi-même.
> J’ai décrit mes idées, mes envies et les problèmes à corriger avec des prompts,
> puis j’ai utilisé l’IA pour générer, modifier, auditer et corriger le code.
>
> **Il n’y a donc aucune ligne de code écrite manuellement par moi dans ce projet.**
> Bookwave est un projet personnel et expérimental réalisé entièrement en
> *vibe coding*, pas le travail d’un développeur professionnel.

## Le vibe coding, concrètement

Pour ce projet, cela signifie :

- je pars d’une idée ou d’un besoin, plutôt que d’une compétence technique ;
- je décris en français ce que l’application doit faire ;
- l’IA produit le code et le fait évoluer au fil de mes demandes ;
- les audits et les tests automatisés m’aident à vérifier le résultat, sans tout
  comprendre techniquement ;
- je peux piloter le produit, mais je ne prétends pas maîtriser chaque ligne du
  code ni chaque choix d’architecture.

C’est une manière accessible de transformer une idée en application. Cela ne
rend pas le code parfait : **il peut rester des bugs, des limitations ou des
problèmes de sécurité**. Les explications, retours et contributions sont donc
les bienvenus.

## Ce que fait Bookwave

- **Bibliothèque cloud** : parcourt une source WebDAV, notamment Nextcloud,
  ownCloud ou AllDebrid, et regroupe les fichiers en livres audio.
- **Lecture adaptée aux audiobooks** : chapitres, reprise de la lecture, vitesse
  mémorisée par livre, minuteur de sommeil et lecture en arrière-plan.
- **Progression** : sauvegarde locale et synchronisation expérimentale entre
  appareils via WebDAV.
- **Métadonnées Audible** : recherche du titre, de l’auteur, du narrateur, de la
  couverture, du résumé et d’autres informations de l’édition.
- **Nettoyage des noms de fichiers** : reconnaissance des auteurs, sagas, tomes
  et numéros de pistes pour obtenir une bibliothèque plus lisible.
- **Catalogue et transferts** : recherche Torznab et envoi de transferts vers
  AllDebrid, selon la configuration de l’utilisateur.

> Utilisez l’application uniquement avec des contenus et des services auxquels
> vous avez légalement accès.

## État du projet

| Élément | Information |
|---|---|
| Version du code source | **0.8.0** (`versionCode 31`) |
| Plateforme | Android 8.0 ou plus récent (API 26+) |
| Technologies | Kotlin, Jetpack Compose, Media3, Koin, OkHttp |
| Tests | 108 tests unitaires dans le module `core`, documentés dans l’audit v0.8.0 |
| Maturité | Projet personnel expérimental, fourni sans garantie |

La synchronisation multi-appareils, certaines estimations de durée et plusieurs
fonctions de la feuille de route restent à améliorer ou à tester davantage.

## Consulter ou compiler le code

Ce dépôt contient le **code source**, pas un APK publié.

Pour compiler le projet, il faut notamment **Android Studio Ladybug ou plus
récent** et **Gradle 8.10.2+**. Le wrapper Gradle n’est pas inclus dans l’archive
d’origine. Les instructions détaillées sont dans [TECHNIQUE.md](TECHNIQUE.md).

```bash
gradle :core:test
gradle :app:assembleDebug
```

## Structure

```text
app/     Application Android, interface, lecteur, cloud et synchronisation
core/    Logique métier Kotlin et tests unitaires
tools/   Outils de vérification et de mesure
gradle/  Catalogue des dépendances
```

## Sécurité et confidentialité

- **Aucune clé de signature n’est incluse dans ce dépôt.** Le fichier
  `debug.keystore` présent dans l’archive de travail a volontairement été retiré.
- Sans clé locale, Android utilise sa clé de débogage par défaut. Un APK signé
  avec une autre clé ne pourra pas remplacer une installation existante sans
  désinstallation préalable.
- Ne publiez jamais vos identifiants WebDAV, clés API, fichiers `.torrent`
  contenant une passkey, ni vos clés de signature.
- Les identifiants enregistrés par l’application utilisent actuellement les
  préférences Android non chiffrées ; la sauvegarde cloud de ces données est
  désactivée dans l’application.

## Documentation

- [Documentation technique et feuille de route](TECHNIQUE.md)
- [Audit général de la v0.8.0](audit-general-v0.8.0.md)
- [Audit général de la v0.7.2](audit-general-v0.7.2.md)
- [Audit de la recherche Audible](audit-recherche-audible.md)

## Contributions

Les idées, rapports de bugs, explications et pull requests sont les bienvenus.
Comme je ne sais pas coder, merci d’expliquer simplement **ce que fait une
modification, pourquoi elle est utile et comment la tester**.

---

**Bookwave : une idée, beaucoup de prompts, et zéro ligne de code écrite à la
main par son auteur. 100 % vibe code assumé.** 💜
