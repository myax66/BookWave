package dev.bookwave.core.model

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertNull

class ChapterIndexTest {

    private val chapters = listOf(
        Chapter(0, "Prologue", 0, 1_000),
        Chapter(1, "One", 1_000, 5_000),
        // gap 5_000..6_000
        Chapter(2, "Two", 6_000, 9_000),
    )
    private val index = ChapterIndex(chapters)

    @Test
    fun lookupInsideChapters() {
        assertEquals(0, index.chapterAt(0)?.index)
        assertEquals(1, index.chapterAt(1_000)?.index)
        assertEquals(1, index.chapterAt(4_999)?.index)
        assertEquals(2, index.chapterAt(6_500)?.index)
    }

    @Test
    fun gapFallsBackToPrecedingChapter() {
        assertEquals(1, index.chapterAt(5_500)?.index)
    }

    @Test
    fun outsideRangeReturnsNull() {
        assertNull(index.chapterAt(-1))
        assertNull(index.chapterAt(9_000))
    }

    @Test
    fun overlappingChaptersRejected() {
        assertFailsWith<IllegalArgumentException> {
            ChapterIndex(listOf(Chapter(0, null, 0, 2_000), Chapter(1, null, 1_000, 3_000)))
        }
    }

    @Test
    fun fallbackChaptersFromSortedFiles() {
        val built = FallbackChapters.fromFiles(
            fileNames = listOf("02-chapitre.mp3", "01-intro.mp3"),
            durationsMs = mapOf("01-intro.mp3" to 60_000, "02-chapitre.mp3" to 120_000),
        )
        assertEquals(listOf("01-intro", "02-chapitre"), built.map { it.title })
        assertEquals(0, built[0].startMs)
        assertEquals(60_000, built[1].startMs)
        assertEquals(180_000, built[1].endMs)
    }
}
