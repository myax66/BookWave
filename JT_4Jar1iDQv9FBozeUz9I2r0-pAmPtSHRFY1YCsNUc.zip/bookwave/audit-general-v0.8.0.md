# Audit général — Bookwave v0.8.0 (versionCode 31)

**Date :** 22 octobre 2026
**Périmètre :** les 42 fichiers Kotlin de l'application — `app/` (7 583 lignes,
UI + données + lecteur + sync) et `core/` (1 670 lignes, logique pure).
**Méthode :** lecture intégrale des fichiers critiques, recherche systématique
de motifs à risque (`runCatching`, `!!`, `remember`, `lowercase()` sans locale,
`while (true)`, écritures disque, appels bloquants), puis **reproduction** de
chaque défaut dans le code avant correction. Aucun constat n'est théorique :
chaque ligne du tableau §2 pointe le fichier corrigé.

**Résultat :** 14 défauts corrigés, dont **3 bloquants** (un défaut
fonctionnel silencieux, une régression d'interface, et une passe
d'identification qui s'arrêtait à la première coupure réseau).
**108 tests verts** (+5), ICU 53/53, APK vc31, signature inchangée
`ba7966a8…`.

---

## 1. Ce que fait l'application (état réel du code)

| Domaine | Fichiers | Rôle |
|---|---|---|
| Sources cloud | `WebDavSource`, `BookRepository` | PROPFIND récursif (profondeur 5, 6 requêtes en parallèle, budgets 4 000 requêtes / 1 500 dossiers) |
| Nettoyage des noms | `TitleCleaner` (539 l.) | auteur avant/après, tome au milieu, tags de release |
| Identification | `MetadataEnricher`, `AudibleQueries`, `AudibleCatalog`, `MetadataMatcher`, `MetadataStore` | échelle de requêtes + balayage auteur, scoring 4 signaux, cache + registre d'échecs |
| Lecture | `PlaybackService`, `PlayerScreen`, `ProgressSaver` | ExoPlayer + MediaSession, sauvegarde toutes les 10 s, reprise au chapitre près |
| Synchronisation | `SyncCoordinator`, `ProgressSyncWorker`, `WebDavSyncTransport` | fusion déterministe (`ProgressMerge`), cycle de 30 min |
| Catalogue | `TorznabApi`, `AllDebridApi`, `CatalogScreen`, `AddTorrentScreen` | recherche multi-trackers, envoi magnet, suivi du transfert |
| UI | `LibraryScreen` (1 442 l.), `SettingsScreen`, `CoverImage` | grille, filtres, fiche, recherche manuelle, pochettes |

---

## 2. Constats corrigés

### 🔴 Bloquants

**C1 — La passe d'identification s'arrêtait au premier échec réseau**
`LibraryScreen.runEnrichPass` faisait `break` sur le premier
`EnrichResult.Failed`. Une seule coupure Wi-Fi (ou un 503 d'Audible) pendant
les 60 livres identifiait **zéro** livre restant, jusqu'au prochain lancement —
et l'utilisateur ne voyait qu'une ligne minuscule. C'est exactement la classe
de défaut qui produit les « ça ne marche pas » à répétition.
→ Le livre est maintenant réessayé après 2 s ; la passe ne s'arrête qu'après
**3 échecs consécutifs**, ce qui signifie réellement « le réseau est tombé ».
Le compteur est remis à zéro à chaque succès.

**C2 — Le bouton « Relancer l'identification » annulait son propre effet**
`SettingsScreen` construisait `MetadataStore(context)` à chaque clic. Cette
seconde instance avait **son propre cache mémoire** : elle effaçait le registre
sur le disque, puis l'instance réelle (celle de `BookRepository`, utilisée par
la bibliothèque) réécrivait l'ancien contenu à sa prochaine écriture. Le bouton
était donc sans effet durable.
→ `MetadataStore` est maintenant un **singleton Koin** lié au dépôt
(`single { get<BookRepository>().metadata }`), et le bouton écrit immédiatement.

**C3 — Le même bouton était rendu deux fois**
Deux blocs `Button` identiques, à la suite, dans la section « Métadonnées ».
Défaut visible à l'œil nu sur l'écran Réglages. → Doublon supprimé.

### 🟠 Majeurs (performance, réactivité, perte de données)

**M1 — Réécriture complète du cache de métadonnées à chaque livre**
`MetadataStore.flush()` sérialisait **toutes** les fiches (jusqu'à 5 000
entrées, chacune avec le résumé Audible) et réécrivait le fichier, à chaque
`put()` et chaque `markTried()`. Une passe de 60 livres = 60 sérialisations
complètes ; sur un compte chargé c'est de l'ordre de 240 Mo écrits par passe.
→ **Écritures groupées** : `beginBatch()` suspend les écritures, `endBatch()`
en fait **une seule** (atomique, `tmp` + `rename`). Hors passe, un debounce de
700 ms regroupe les rafales. La version de cache (`version`) est toujours
incrémentée immédiatement, donc l'UI reste instantanée.

**M2 — Fusion bibliothèque en O(n²)**
`books.map { book -> metadata.merge(book) to saved.firstOrNull { it.bookId == book.id } }`
scannait la liste des progressions **pour chaque livre**, à chaque émission du
flux — et une passe d'identification en émet une par livre. 2 000 livres =
4 millions de comparaisons par émission.
→ `saved.associateBy { it.bookId }` construit une fois par émission.

**M3 — `SyncEngine.mergeAll` en O(n²)**
Deux `firstOrNull` par identifiant, sur le thread du worker. → indexation.

**M4 — Le lecteur interrogeait le player 2 fois par seconde, indéfiniment**
`LaunchedEffect(controller)` bouclait sur `delay(500)` **même en pause**, et
réécrivait 4 états Compose à chaque tour : recomposition complète de l'écran
2 fois/seconde, pour rien quand rien ne bouge, pendant toute la lecture.
→ Cadence adaptative (**250 ms en lecture, 1 s en pause**) et **écriture
uniquement si la valeur change**. Sur une heure de lecture en pause, c'est
7 200 recompositions évitées.

**M5 — Aucun réessai réseau, nulle part**
Toutes les couches traitaient une erreur HTTP comme définitive. Un 502
d'Audible ou un 503 de Nextcloud coûtait un livre (voire la passe entière, cf.
C1). De plus toutes les erreurs étaient des `IOException` nues : impossible de
distinguer « mot de passe faux » de « serveur surchargé ».
→ `HttpStatusException` typée + `withRetry` (backoff exponentiel plafonné,
**jitter** pour ne pas synchroniser les 6 PROPFIND parallèles) appliqué au
catalogue Audible et au PROPFIND WebDAV. **Liste blanche** de statuts
réessayables : 408, 425, 429, 500, 502, 503, 504, 520-524 — 501 (non
implémenté) et 507 (disque plein) sont exclus, un test le vérifie.

**M6 — Le cache de métadonnées était parsé sur le thread principal**
`LibraryViewModel.init` → `metadata.clearTried()` → `cache()` → lecture +
`JSONObject` de tout le fichier, sur le thread UI. Proportionnel au nombre de
fiches résolues.
→ `warmUp()` appelé depuis `Application.onCreate` sur `Dispatchers.IO`, et
`enrich()` exécuté entièrement sur IO (il faisait ses lectures d'état et son
écriture finale sur le thread principal).

### 🟡 Mineurs corrigés

| # | Défaut | Correction |
|---|---|---|
| m1 | Recherche de bibliothèque **sensible aux accents** : « energie » ne trouvait pas « Énergie », « voeu » ne trouvait pas « Vœu » | `MetadataMatcher.normalize()` des deux côtés (même normaliseur que le moteur Audible, ligatures incluses) |
| m2 | `lowercase()` / `uppercase()` sans locale (6 sites) — en turc, « I » devient « ı » et casse les clés de cache et la détection d'ASIN | `Locale.ROOT` |
| m3 | `LibraryCache.reclean` **effaçait** un auteur/saga connus quand le nettoyeur ne les retrouvait pas (à chaque démarrage à froid) | repli sur la valeur déjà en cache |
| m4 | `ProgressStore.upsert` réécrivait DataStore (disque) pour un enregistrement **identique** — le service sauvegarde toutes les 10 s | écriture ignorée si position/vitesse/état inchangés |
| m5 | `inProgress` (bandeau « Reprendre ») recalculé à **chaque** recomposition, `AppSettings` relu 3× par recomposition | `remember(...)` |
| m6 | La passe d'identification démarrait sur la **première** émission (= cache disque, `refreshing = true`) et se battait avec le scan WebDAV pour les 5 threads OkHttp | attend un scan stabilisé, 20 s maximum |

---

## 3. Constats **non** corrigés (assumés)

| # | Constat | Pourquoi | Coût estimé |
|---|---|---|---|
| O1 | Mot de passe WebDAV et clés API en clair dans `SharedPreferences` | migration `EncryptedSharedPreferences` non testable ici (Keystore absent du sandbox) ; une erreur casserait l'accès aux identifiants | 2 h + test sur appareil |
| O2 | WebDAV en `http://` sur réseau local bloqué (pas de `networkSecurityConfig`) | décision produit (sécurité) à valider | 30 min |
| O3 | Polling AllDebrid toutes les 10 s tant que l'écran est ouvert | nécessite un cycle de vie + arrêt automatique ; l'écran est court | 1 h |
| O4 | Progressions stockées en un seul JSON DataStore | borné par le nombre de livres suivis (centaines, pas milliers) | 2 h |
| O5 | Pas de build release minifié testé, pas de CI (detekt/lint) | hors périmètre « fonctionnement » | 1 j |
| O6 | Aucun test instrumenté (UI, migrations de cache) | nécessite un appareil/émulateur | 1 j |
| O7 | `TorznabApi` / `AllDebridApi` sans réessai | ces appels sont déclenchés par l'utilisateur, l'erreur est affichée | 30 min |

---

## 4. Vérifications

| Contrôle | Résultat |
|---|---|
| `:core:test` | **108 tests, 0 échec** (+5 : `BackoffTest`, fusion 2 000 livres) |
| `tools/check-regex-icu.sh` | **53 motifs, 0 invalide** |
| `:app:assembleDebug` | OK — APK vc31 / 0.8.0, **23 977 974 o** |
| Signature | `ba7966a8f861af75d08161193f910e1c7448554fd1748338746ec774351a8173` (inchangée) |
| API live (v0.7.4, non-régression) | 18/18 dossiers du corpus identifiés correctement |

Le moteur de recherche Audible n'a **pas** été modifié dans cette version : la
non-régression est garantie par `SearchCorpusTest` (18 cas réels).

---

## 5. Ce qui change à l'usage

1. Une coupure réseau passagère **n'interrompt plus** l'identification des
   livres : elle reprend.
2. « Relancer l'identification maintenant » (Réglages) **fonctionne vraiment**,
   et n'apparaît plus en double.
3. Une passe d'identification écrit **une fois** sur le disque au lieu de
   60 fois → moins d'I/O, moins de chauffe, démarrage plus rapide.
4. Le lecteur ne recompose plus l'écran en boucle quand la lecture est en pause.
5. La recherche de la bibliothèque ignore accents et ligatures.
6. Un serveur qui répond 503 est réessayé au lieu de vider la bibliothèque.
