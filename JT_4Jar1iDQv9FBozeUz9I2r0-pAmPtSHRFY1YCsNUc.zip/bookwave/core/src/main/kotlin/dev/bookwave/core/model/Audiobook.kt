package dev.bookwave.core.model

/**
 * A remote audiobook as discovered on a cloud source.
 *
 * Chapter handling is audiobook-first: a book may expose embedded chapters
 * (m4b/container metadata) or fall back to one chapter per audio file
 * (see [dev.bookwave.core.model.FallbackChapters]).
 */
data class Audiobook(
    val id: String,
    val title: String,
    val author: String? = null,
    val narrator: String? = null,
    val series: String? = null,
    val seriesIndex: Double? = null,
    val coverUrl: String? = null,
    val durationMs: Long,
    val chapters: List<Chapter> = emptyList(),
    val source: SourceRef,
    val sizeBytes: Long = 0,
) {
    init {
        require(id.isNotBlank()) { "book id must not be blank" }
        require(title.isNotBlank()) { "book title must not be blank" }
        require(durationMs >= 0) { "duration must be >= 0" }
        require(sizeBytes >= 0) { "size must be >= 0" }
    }

    val chapterIndex: ChapterIndex get() = ChapterIndex(chapters)
}

/** Where the audio lives on a cloud provider. */
data class SourceRef(
    val provider: String,
    val account: String,
    val path: String,
    val contentUrl: String? = null,
)

/**
 * A chapter span inside a book. [endMs] is exclusive.
 * Gaps between chapters are allowed (e.g. silence or embedded covers).
 */
data class Chapter(
    val index: Int,
    val title: String?,
    val startMs: Long,
    val endMs: Long,
) {
    init {
        require(index >= 0) { "chapter index must be >= 0" }
        require(startMs >= 0) { "chapter start must be >= 0" }
        require(endMs > startMs) { "chapter end must be after start" }
    }

    val durationMs: Long get() = endMs - startMs

    fun contains(positionMs: Long): Boolean = positionMs in startMs until endMs
}

/**
 * Index for O(log n) chapter lookup by position, tolerant of gaps:
 * a position falling in a gap belongs to the nearest preceding chapter.
 */
class ChapterIndex(val chapters: List<Chapter>) {

    init {
        require(chapters.zipWithNext().all { (a, b) -> a.endMs <= b.startMs }) {
            "chapters must be ordered and non-overlapping"
        }
    }

    val isEmpty: Boolean get() = chapters.isEmpty()

    fun chapterAt(positionMs: Long): Chapter? {
        if (chapters.isEmpty()) return null
        // Binary search over start offsets, then clamp to the preceding chapter.
        var lo = 0
        var hi = chapters.size - 1
        var candidate: Chapter? = null
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            val ch = chapters[mid]
            if (ch.startMs <= positionMs) {
                candidate = ch
                lo = mid + 1
            } else {
                hi = mid - 1
            }
        }
        return if (candidate != null && (candidate.contains(positionMs) || positionMs < chapters.last().endMs)) {
            candidate
        } else {
            null
        }
    }

    fun chapterOfIndex(index: Int): Chapter? = chapters.firstOrNull { it.index == index }

    fun isLast(chapter: Chapter): Boolean = chapters.lastOrNull()?.index == chapter.index
}

/** Builds chapters when a container has no chapter metadata: one file = one chapter. */
object FallbackChapters {
    fun fromFiles(fileNames: List<String>, durationsMs: Map<String, Long>): List<Chapter> {
        var offset = 0L
        return fileNames.sorted().mapIndexed { i, name ->
            val dur = durationsMs[name] ?: 0L
            val chapter = Chapter(
                index = i,
                title = name.substringBeforeLast('.'),
                startMs = offset,
                endMs = offset + dur.coerceAtLeast(1),
            )
            offset = chapter.endMs
            chapter
        }
    }
}
