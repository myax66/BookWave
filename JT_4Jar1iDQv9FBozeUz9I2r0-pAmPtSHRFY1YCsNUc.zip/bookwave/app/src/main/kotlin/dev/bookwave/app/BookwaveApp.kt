package dev.bookwave.app

import android.app.Application
import dev.bookwave.app.data.AppSettings
import dev.bookwave.app.data.BookRepository
import dev.bookwave.app.data.ProgressStore
import dev.bookwave.app.sync.ProgressSyncWorker
import dev.bookwave.app.sync.SyncCoordinator
import dev.bookwave.app.sync.SyncTransport
import dev.bookwave.app.sync.WebDavSyncTransport
import dev.bookwave.app.ui.library.LibraryViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.GlobalContext
import org.koin.core.context.startKoin
import org.koin.dsl.module

class BookwaveApp : Application() {

    override fun onCreate() {
        super.onCreate()
        startKoin {
            androidContext(this@BookwaveApp)
            modules(appModule)
        }
        // Multi-device progress sync: the worker existed but was NEVER
        // scheduled — the feature silently never ran. Enqueued once (KEEP
        // policy), then WorkManager owns the 30-min network-constrained cycle.
        ProgressSyncWorker.schedule(this)

        // Parse the metadata cache off the main thread while the first frame
        // draws (see MetadataStore.warmUp). The library VM touches it during
        // its own init; without this the first screen waits for the parse.
        CoroutineScope(Dispatchers.IO).launch {
            runCatching { GlobalContext.get().get<dev.bookwave.app.data.metadata.MetadataStore>().warmUp() }
        }
    }
}

val appModule = module {
    // AppSettings MUST be registered: SettingsScreen and the demo CTA resolve it
    // from Koin (NoDefinitionFoundException = crash on opening "Sources").
    single { AppSettings(androidContext()) }
    single { ProgressStore(androidContext()) }
    single { BookRepository(androidContext()) }
    // v0.8.0 — the ONE metadata store. Before this, Settings built its own
    // instance (separate in-memory cache, separate flush thread) and its
    // "relancer l'identification" button was silently overwritten by the
    // library's instance. Bound to the repository, never rebuilt.
    single { get<BookRepository>().metadata }
    single<SyncTransport> { WebDavSyncTransport(androidContext()) }
    // Stable device id from settings — the same one progress records carry.
    single { SyncCoordinator(get(), get(), get<AppSettings>().deviceId) }
    factory { LibraryViewModel(get(), get()) }
}
