package dev.bookwave.app.data

import android.content.Context
import dev.bookwave.core.playback.AudioSpeed

/**
 * User settings. Thin SharedPreferences wrapper (replace with DataStore when
 * the settings screen grows) — keys are stable, defaults are EMPTY so the UI
 * can tell "not configured" from "configured with errors".
 */
class AppSettings(context: Context) {

    private val prefs = context.getSharedPreferences("bookwave", Context.MODE_PRIVATE)

    var webdavUrl: String
        get() = prefs.getString(KEY_URL, "")!!
        set(value) = prefs.edit().putString(KEY_URL, value.trim()).apply()

    var webdavUser: String
        get() = prefs.getString(KEY_USER, "")!!
        set(value) = prefs.edit().putString(KEY_USER, value.trim()).apply()

    var webdavPassword: String
        get() = prefs.getString(KEY_PASS, "")!!
        set(value) = prefs.edit().putString(KEY_PASS, value).apply()

    /** Demo library: offline sample books so the app is explorable with zero setup. */
    var demoMode: Boolean
        get() = prefs.getBoolean(KEY_DEMO, false)
        set(value) = prefs.edit().putBoolean(KEY_DEMO, value).apply()

    /** Audible metadata enrichment (titles/authors/covers/runtime sent to Amazon). */
    var enrichEnabled: Boolean
        get() = prefs.getBoolean("enrich_enabled", true)
        set(value) = prefs.edit().putBoolean("enrich_enabled", value).apply()

    /** One-shot flag: Settings asked for a fresh identification pass. */
    var enrichPassRequested: Boolean
        get() = prefs.getBoolean("enrich_pass_requested", false)
        set(value) = prefs.edit().putBoolean("enrich_pass_requested", value).apply()

    fun consumeEnrichPassRequest(): Boolean {
        if (!enrichPassRequested) return false
        enrichPassRequested = false
        return true
    }

    /** One-shot migration: v0.6.1 ledgered network ERRORS as misses for 7
     *  days; the first v0.6.2+ launch wipes that polluted ledger. */
    var enrichLedgerV2Done: Boolean
        get() = prefs.getBoolean("enrich_ledger_v2_done", false)
        set(value) = prefs.edit().putBoolean("enrich_ledger_v2_done", value).apply()

    /** Matching engine version: whenever the query/matching logic changes,
     *  the stored miss-ledger from the older engine is wiped on launch so
     *  improved matching re-evaluates every book (v0.6.3+). */
    var enrichLedgerVersion: Int
        get() = prefs.getInt("enrich_ledger_version", 0)
        set(value) = prefs.edit().putInt("enrich_ledger_version", value).apply()

    /** Preferred Audible market: "auto" (fr then com), "fr" or "com". */
    var enrichMarket: String
        get() = prefs.getString("enrich_market", "auto") ?: "auto"
        set(value) = prefs.edit().putString("enrich_market", value).apply()

    /** C411 tracker base URL (native Torznab API). */
    var c411Url: String
        get() = prefs.getString(KEY_C411_URL, DEFAULT_C411_URL)!!
        set(value) = prefs.edit().putString(KEY_C411_URL, normalizeBase(value)).apply()

    /** C411 API key (profile → API keys). Distinct from the AllDebrid key. */
    var c411ApiKey: String
        get() = prefs.getString(KEY_C411_KEY, "")!!
        set(value) = prefs.edit().putString(KEY_C411_KEY, value.trim()).apply()

    val isC411Configured: Boolean
        get() = c411ApiKey.isNotBlank()

    /** TR4KER base URL (Torznab served from /api/torznab/all). */
    var tr4kerUrl: String
        get() = prefs.getString(KEY_TR4KER_URL, DEFAULT_TR4KER_URL)!!
        set(value) = prefs.edit().putString(KEY_TR4KER_URL, normalizeBase(value, DEFAULT_TR4KER_URL)).apply()

    /** TR4KER API key (Mon compte → Paramètres → Clé API). */
    var tr4kerApiKey: String
        get() = prefs.getString(KEY_TR4KER_KEY, "")!!
        set(value) = prefs.edit().putString(KEY_TR4KER_KEY, value.trim()).apply()

    val isTr4kerConfigured: Boolean
        get() = tr4kerApiKey.isNotBlank()

    /** True when at least one catalogue tracker can be queried. */
    val hasCatalog: Boolean
        get() = isC411Configured || isTr4kerConfigured

    /** Stable per-install id for progress sync records. */
    val deviceId: String
        get() = prefs.getString(KEY_DEVICE, null)
            ?: java.util.UUID.randomUUID().toString().also { prefs.edit().putString(KEY_DEVICE, it).apply() }

    val isConfigured: Boolean
        get() = demoMode || webdavUrl.isNotBlank()

    /**
     * Global default playback speed, refreshed every time the user picks one.
     * A book keeps its own speed once listened to (see [ListeningProgress.speed]);
     * this is the value applied to books never opened before.
     */
    var playbackSpeed: Float
        get() = prefs.getFloat(KEY_SPEED, 1.0f)
        set(value) = prefs.edit().putFloat(KEY_SPEED, AudioSpeed.coerce(value)).apply()

    /**
     * The Android 13 notification-permission prompt was already shown once.
     * Re-asking on EVERY launch (old behaviour) nags users who dismissed it;
     * after the first prompt the system manages further grants itself.
     */
    var notificationPromptShown: Boolean
        get() = prefs.getBoolean(KEY_NOTIF_PROMPT, false)
        set(value) = prefs.edit().putBoolean(KEY_NOTIF_PROMPT, value).apply()

    private companion object {
        const val KEY_URL = "webdav_url"
        const val KEY_USER = "webdav_user"
        const val KEY_PASS = "webdav_password"
        const val KEY_DEMO = "demo_mode"
        const val KEY_DEVICE = "device_id"
        const val KEY_SPEED = "playback_speed"
        const val KEY_NOTIF_PROMPT = "notif_prompt_shown"
        const val KEY_C411_URL = "c411_url"
        const val KEY_C411_KEY = "c411_apikey"
        const val KEY_TR4KER_URL = "tr4ker_url"
        const val KEY_TR4KER_KEY = "tr4ker_apikey"
        const val DEFAULT_C411_URL = "https://c411.org"
        const val DEFAULT_TR4KER_URL = "https://tr4ker.net"

        /** Keeps a scheme, drops trailing slashes and any "/api" suffix. */
        fun normalizeBase(raw: String, fallback: String = DEFAULT_C411_URL): String {
            var v = raw.trim().trimEnd('/')
            if (v.isBlank()) return fallback
            if (!v.startsWith("http://") && !v.startsWith("https://")) v = "https://$v"
            while (v.endsWith("/api")) v = v.removeSuffix("/api")
            return v
        }
    }
}
