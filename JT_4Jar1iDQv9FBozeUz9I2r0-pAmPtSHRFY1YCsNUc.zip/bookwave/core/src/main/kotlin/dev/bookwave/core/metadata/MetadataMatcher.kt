package dev.bookwave.core.metadata

import java.text.Normalizer

/**
 * Scores Audible candidates against what Bookwave already knows about a book
 * (cleaned torrent name, guessed author/series, size-based duration estimate).
 *
 * Pure and side-effect free: the whole matching policy is unit-testable.
 * Weights: title 0.50, author 0.20, series+volume 0.15, runtime 0.15.
 * Unknown signals score 0.5 (neutral) so a missing author never sinks a
 * perfect title match, and never lifts a bad one to auto-apply. A KNOWN
 * language mismatch applies a final multiplicative penalty (0.80) — an
 * English edition must not auto-replace the French one it is a clone of.
 *
 * v5 additions (search overhaul):
 *  - title score blends token coverage with Dice, so Audible's longer
 *    official titles ("… à l'école des sorciers") no longer lose against a
 *    short torrent title just because the edition carries a subtitle;
 *  - the trailing volume number is ignored when the series index is known
 *    (the volume is already compared through the series signal);
 *  - ALL series pairs returned by Audible are compared (it lists the same
 *    book under "Harry Potter" and "Le Monde des sorciers", in random order);
 *  - series names are normalised ("(French Edition)", "Series" suffixes) and
 *    author initials are compared compactly ("J.K. Rowling" = "JK Rowling").
 */
object MetadataMatcher {

    /** At or above this score the match is applied without asking. */
    const val AUTO_THRESHOLD = 0.75

    /** Between the two thresholds the user picks among the top candidates. */
    const val SUGGEST_THRESHOLD = 0.50

    /** Verified language mismatch penalty (French edition vs English clone). */
    private const val LANGUAGE_PENALTY = 0.80

    /** What the library side knows before any lookup. */
    data class MatchInput(
        val title: String,
        val author: String? = null,
        val series: String? = null,
        val seriesIndex: Double? = null,
        val estimatedMs: Long = 0L,
        /** Preferred language, e.g. "french" (derived from the market). */
        val language: String? = null,
    )

    fun normalize(s: String): String {
        // French ligatures do not decompose under NFD: "Le Dernier Vœu" used
        // to become "dernier vo u" and never matched "Le Dernier voeu".
        val ligatures = s.lowercase()
            .replace("œ", "oe")
            .replace("æ", "ae")
            .replace("ß", "ss")
        val stripped = Normalizer.normalize(ligatures, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
        return stripped.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim()
    }

    fun tokens(s: String): List<String> = normalize(s).split(' ').filter { it.isNotEmpty() }

    /** Sørensen-Dice over token multisets, in [0, 1]. */
    fun dice(a: List<String>, b: List<String>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val bb = b.toMutableList()
        var hits = 0
        for (t in a) {
            if (bb.remove(t)) hits++
        }
        return 2.0 * hits / (a.size + b.size)
    }

    /** Share of [a] found in [b], in [0, 1]: how much of OUR title is covered. */
    fun coverage(a: List<String>, b: List<String>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val bb = b.toMutableList()
        var hits = 0
        for (t in a) if (bb.remove(t)) hits++
        return hits.toDouble() / a.size
    }

    /**
     * Part markers used by French publishers when a novel is split:
     * "Vent et vérité - Volume 2", "La Peur du Sage - Seconde partie",
     * "Dune - Livre troisième". Both sides are compared: "Dune 1" must not
     * pick "Dune - Livre troisième" just because the author and saga agree.
     */
    private val VOLUME_WORDS = setOf(
        "tome", "tomes", "volume", "volumes", "vol", "livre", "livres",
        "partie", "parties", "part", "book", "books", "saison", "season", "episode",
    )

    private val SUBTITLE_LABEL = Regex(
        "(?i)\\b(tome|tomes|volume|volumes|vol|livre|livres|partie|parties|book|books|saison|season|épisode|episode)\\b\\.?\\s*\\d",
    )

    private val ORDINALS = mapOf(
        "premier" to 1, "premiere" to 1, "first" to 1, "un" to 1,
        "second" to 2, "seconde" to 2, "deuxieme" to 2, "two" to 2, "deux" to 2,
        "troisieme" to 3, "third" to 3, "three" to 3, "trois" to 3,
        "quatrieme" to 4, "fourth" to 4, "quatre" to 4,
        "cinquieme" to 5, "fifth" to 5, "cinq" to 5,
    )

    /**
     * Part number of a title ("… 2", "… volume 2", "… troisième"), if any.
     * A title that names SEVERAL parts ("Dune - Livre premier et livre
     * second") is the complete work: no part can be inferred, so null.
     */
    fun partNumber(title: String): Int? {
        val t = tokens(title)
        val found = LinkedHashSet<Int>()
        for ((i, w) in t.withIndex()) {
            val volWord = i > 0 && t[i - 1] in VOLUME_WORDS
            val beforeVolWord = i + 1 < t.size && t[i + 1] in VOLUME_WORDS
            val n = when {
                // Two digits max: "1984" is a year, not a part.
                w.length <= 2 && w.all { c -> c.isDigit() } -> w.toIntOrNull()
                // An ordinal only counts next to a volume word: "L'alliance des
                // trois" (Autre-Monde 1) must not look like part 3.
                ORDINALS[w] != null && (volWord || beforeVolWord) -> ORDINALS[w]
                else -> null
            } ?: continue
            found += n
            if (found.size > 1) return null
        }
        return found.firstOrNull()
    }

    /** Both sides name a part and the numbers disagree. */
    fun partConflict(input: MatchInput, candidate: BookMetadata): Boolean {
        val mine = partNumber(input.title) ?: return false
        val theirs = partNumber(comparisonTitle(candidate)) ?: return false
        return mine != theirs
    }

    /**
     * Audible pads series names ("Solo Leveling (French Edition)", "Dune
     * Series", "L'Épée de Vérité - Série"). Those words are catalogue noise and
     * used to keep an exact saga match under the Dice floor.
     */
    fun normalizeSeries(s: String): String {
        // NOTE: Android compiles these with ICU, which rejects an UNESCAPED
        // closing brace ("U_REGEX_RULE_SYNTAX") where the JVM accepts it. All
        // patterns of the project are validated against ICU by
        // tools/check-regex-icu.sh — never assume the JVM behaviour.
        val withoutParens = s
            .replace(Regex("\\([^)]*\\)"), " ")
            .replace(Regex("\\[[^\\]]*\\]"), " ")
            .replace(Regex("\\{[^}]*\\}"), " ")
        val withoutSuffix = withoutParens.replace(
            Regex(
                "(?i)\\b(french|english|german|spanish|italian|edition|édition|series|série|serie|collection|integrale|intégrale|audiobook)\\b",
            ),
            " ",
        )
        return normalize(withoutSuffix)
    }

    /**
     * How much of the candidate's official title is INSIDE our folder name
     * (symmetric token coverage, 0..1). Used to pre-filter the results of an
     * author sweep: an author match alone must never decide a book.
     */
    /**
     * The candidate's title with its subtitle, EXCEPT when the subtitle is
     * really the saga name: Audible France fills `subtitle` with it
     * ("Chronique du Tueur de Roi" for every volume of Rothfuss). Comparing it
     * as title words cost a perfect match 0.05 to 0.10 (measured: 0.727
     * instead of 0.78 on "Le Nom du Vent").
     */
    fun comparisonTitle(candidate: BookMetadata): String {
        val sub = candidate.subtitle?.takeIf { it.isNotBlank() }
        val subNorm = sub?.let { normalize(it) }.orEmpty()
        val redundant = sub != null && (
            // "Chronique du Tueur de Roi" — the saga name itself.
            candidate.allSeries().any { normalizeSeries(it.name) == normalizeSeries(sub) } ||
                // "Dune 1" — Audible France fills `subtitle` with "Saga + tome".
                candidate.allSeries().any {
                    val n = normalizeSeries(it.name)
                    n.isNotBlank() && subNorm.startsWith(n) && subNorm.removePrefix(n).trim().split(' ').size <= 2
                } ||
                // "… (French Edition)" — the title already says it.
                normalize(candidate.title).contains(subNorm) ||
                // "The Witcher, Tome 1": a volume label is not a subtitle.
                SUBTITLE_LABEL.containsMatchIn(sub)
            )
        return if (sub != null && !redundant) "${candidate.title} $sub" else candidate.title
    }

    fun titleContainment(inputTitle: String, candidate: BookMetadata): Double {
        val theirs = tokens(comparisonTitle(candidate))
        val mine = tokens(inputTitle)
        if (mine.isEmpty() || theirs.size < 2) return 0.0
        return maxOf(coverage(mine, theirs), coverage(theirs, mine))
    }

    fun score(input: MatchInput, candidate: BookMetadata): Double {
        // v0.7.3 — "Brandon Sanderson L Ensoleille": the author's name is
        // written at the head of OUR string, so it is no more part of the
        // title than a dash is, and it proves the authorship.
        val prefixInTitle = authorPrefixInTitle(input, candidate)
        val titleScore = titleScore(input, candidate, prefixInTitle)
        val authorScore = if (input.author.isNullOrBlank() && prefixInTitle != null) {
            1.0
        } else {
            authorScore(input, candidate)
        }
        val series = bestSeries(input, candidate)
        val seriesScore = series.score
        val runtimeScore = runtimeScore(input.estimatedMs, candidate.runtimeMin)

        val base = 0.50 * titleScore +
            0.20 * authorScore +
            0.15 * seriesScore +
            0.15 * runtimeScore

        val factor = languageFactor(input, candidate) *
            // "Dune 1" must not resolve to "Les Hérétiques de Dune" (tome 5)
            // just because the author and the saga name agree.
            if (series.volumeConflict) 0.90 else 1.0
        val conflict = partConflict(input, candidate)

        // A confirmed series + exact volume IS the identity: the cleaned title
        // of a saga volume ("Harry Potter 1") matches its official title
        // ("Harry Potter à l'école des sorciers") poorly, so the weighted sum
        // alone stranded perfect saga matches in the suggestion band.
        val authorVeto = !input.author.isNullOrBlank() &&
            candidate.authors.isNotEmpty() && authorScore == 0.0
        val runtimeVeto = runtimeScore == 0.0
        // A named part that contradicts ours kills the identity, floor included
        // ("Dune 1" is not "Dune - Livre troisième").
        if (!conflict && (series.indexMatch || series.partialBook)) {
            val top = if (series.indexMatch) 0.85 else 0.80
            val floor = when {
                !authorVeto && !runtimeVeto -> maxOf(base, top)
                !authorVeto -> maxOf(base, 0.65)
                else -> base
            }
            return floor * factor
        }
        return base * factor
    }

    /** Best series pair of the candidate: (combined score, exact-volume flag). */
    private data class SeriesMatch(
        val score: Double,
        val indexMatch: Boolean,
        /** True when the candidate belongs to a DIFFERENT volume of the saga. */
        val volumeConflict: Boolean = false,
        /** Same volume, published in several parts Audible numbers "1.1", "1.2". */
        val partialBook: Boolean = false,
    )

    private fun bestSeries(input: MatchInput, candidate: BookMetadata): SeriesMatch {
        val mine = input.series?.takeIf { it.isNotBlank() }
        val theirs = candidate.allSeries()
        if (mine == null && theirs.isEmpty()) return SeriesMatch(0.5, false)
        if (mine == null || theirs.isEmpty()) return SeriesMatch(0.3, false)

        var bestScore = 0.0
        var identity = false
        var anyKnown = false
        var sameVolume = false
        for (entry in theirs) {
            val nameDice = dice(tokens(mine), tokens(normalizeSeries(entry.name)))
            val indexMatch = input.seriesIndex != null && entry.index != null &&
                Math.abs(input.seriesIndex - entry.index) < 0.01
            // Audible numbers split books as "1.1"/"1.2": the same integer
            // part is the same volume, published in two halves.
            val sameBook = input.seriesIndex != null && entry.index != null &&
                Math.floor(input.seriesIndex) == Math.floor(entry.index)
            val idx = when {
                input.seriesIndex == null || entry.index == null -> 0.6
                indexMatch -> 1.0
                sameBook -> 0.8
                else -> 0.3
            }
            bestScore = maxOf(bestScore, nameDice * 0.7 + idx * 0.3)
            if (nameDice >= 0.75 && indexMatch) identity = true
            if (entry.index != null) {
                anyKnown = true
                if (input.seriesIndex != null &&
                    Math.floor(input.seriesIndex) == Math.floor(entry.index)
                ) {
                    sameVolume = true
                }
            }
        }
        return SeriesMatch(
            bestScore,
            identity,
            volumeConflict = anyKnown && input.seriesIndex != null && !sameVolume,
            partialBook = sameVolume && !identity,
        )
    }

    /** Tokens of the candidate's author that open our title, if any. */
    private fun authorPrefixInTitle(input: MatchInput, candidate: BookMetadata): List<String>? {
        if (candidate.authors.isEmpty()) return null
        val mine = tokens(input.title)
        if (mine.size < 3) return null
        return candidate.authors
            .map { tokens(it) }
            .filter { it.isNotEmpty() && it.size < mine.size }
            .firstOrNull { mine.take(it.size) == it }
    }

    private fun titleScore(
        input: MatchInput,
        candidate: BookMetadata,
        prefixInTitle: List<String>? = null,
    ): Double {
        val candidateTitle = comparisonTitle(candidate)
        val theirs = tokens(candidateTitle)
        var mine = tokens(input.title)
        // v0.7.3 — a folder name can carry the author IN FRONT of the title with
        // no separator ("Brandon Sanderson L Ensoleille"). Once the candidate
        // says who wrote it, those tokens are not part of the title: measuring
        // them cost 0.42 of title score and stranded a perfect match in the
        // "nothing found" branch (measured 0.533 → 0.750 on L'Ensoleillé).
        if (prefixInTitle != null && mine.size - prefixInTitle.size >= 1) {
            mine = mine.drop(prefixInTitle.size)
        }
        // "Solo Leveling 1": the volume is compared by the series signal, and
        // leaving the digit in the title tokens cost ~20 points of Dice.
        val idx = input.seriesIndex
        if (idx != null && idx % 1.0 == 0.0 && mine.lastOrNull() == idx.toInt().toString()) {
            mine = mine.dropLast(1)
        }
        if (mine.isEmpty()) return 0.0
        // Coverage rewards "all our words are there" (short torrent title vs
        // official title + subtitle); Dice still punishes foreign words.
        //
        // v0.7.4 — the coverage is SYMMETRIC. A folder name often PREPENDS
        // noise ("les archives de roshar 05 vent et verite 2" for the official
        // "Vent et vérité - Volume 2"): measuring only what we cover gave
        // 0.44 and never reached the auto threshold, while measuring what the
        // OFFICIAL title covers in our string gives 0.80. When the candidate's
        // whole title is inside the folder name, that IS a match; Dice keeps
        // punishing the extra foreign words (0.57 here).
        val forward = coverage(mine, theirs)
        val backward = if (theirs.size >= 2) coverage(theirs, mine) else 0.0
        // With one or two words, "all our words are in theirs" is almost always
        // true ("Dune" is inside every Dune book): coverage only counts fully
        // from three words on, so Dice keeps the floor.
        val w = minOf(1.0, mine.size / 3.0)
        val raw = (0.6 * w * maxOf(forward, backward) + 0.4 * dice(mine, theirs)) / (0.6 * w + 0.4)
        // "Dune 1" is not "Dune - Livre troisième": when both sides name a
        // part and the numbers disagree, the title is not the same.
        return if (partConflict(input, candidate)) raw * 0.75 else raw
    }

    private fun authorScore(input: MatchInput, candidate: BookMetadata): Double {
        if (input.author.isNullOrBlank()) return 0.5
        if (candidate.authors.isEmpty()) return 0.0
        val mine = tokens(input.author)
        val compactMine = mine.joinToString("")
        return candidate.authors.maxOf { full ->
            val theirs = tokens(full)
            val compactTheirs = theirs.joinToString("")
            maxOf(
                dice(mine, theirs),
                // "J.K. Rowling" vs "JK Rowling": punctuation-blind initials.
                if (compactMine == compactTheirs) 1.0 else dice(listOf(compactMine), listOf(compactTheirs)),
            )
        }
    }

    private fun languageFactor(input: MatchInput, candidate: BookMetadata): Double {
        val want = input.language?.takeIf { it.isNotBlank() } ?: return 1.0
        val got = candidate.language?.takeIf { it.isNotBlank() } ?: return 1.0
        return if (normalize(want) == normalize(got)) 1.0 else LANGUAGE_PENALTY
    }

    private fun runtimeScore(estimatedMs: Long, runtimeMin: Int): Double {
        if (estimatedMs <= 0L || runtimeMin <= 0) return 0.5
        val ratio = (estimatedMs / 60_000.0) / runtimeMin
        return when {
            ratio in 0.8..1.25 -> 1.0
            ratio in 0.6..1.6 -> 0.5
            else -> 0.0
        }
    }

    /** Best first, with scores, for the "pick the edition" sheet. */
    fun rank(input: MatchInput, candidates: List<BookMetadata>): List<Pair<BookMetadata, Double>> =
        candidates.map { it to score(input, it) }.sortedByDescending { it.second }
}
