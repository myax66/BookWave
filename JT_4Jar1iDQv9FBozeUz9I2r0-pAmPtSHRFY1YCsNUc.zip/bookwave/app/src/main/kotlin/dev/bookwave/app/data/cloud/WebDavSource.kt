package dev.bookwave.app.data.cloud

import android.util.Base64
import dev.bookwave.app.util.Http
import dev.bookwave.app.util.HttpStatusException
import dev.bookwave.app.util.await
import dev.bookwave.app.util.withRetry
import dev.bookwave.core.util.Backoff
import dev.bookwave.core.cloud.CloudEntry
import dev.bookwave.core.cloud.CloudSource
import dev.bookwave.core.cloud.MediaKind
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.URLDecoder
import java.util.concurrent.TimeUnit
import javax.xml.parsers.DocumentBuilderFactory

/**
 * Minimal WebDAV/ownCloud/Nextcloud/AllDebrid source over OkHttp.
 *
 * PROPFIND lists entries; audio streams resolve to authenticated GET URLs.
 * Credentials live in app settings (never hardcoded in the binary — the legacy
 * app shipped Dropbox keys inside the DEX).
 *
 * Error policy: HTTP failures and unparseable responses THROW (IOException)
 * with a human-readable reason. Returning an empty list on failure made the
 * connection test report "OK — 0 élément" for ANY input — a false positive
 * that hid wrong URLs and rejected credentials.
 */
class WebDavSource(
    override val account: String,
    baseUrl: String,
    private val username: String,
    private val password: String,
) : CloudSource {

    override val provider: String = "webdav"

    private val baseUrl: String = normalizeBaseUrl(baseUrl)

    // Shares the app-wide connection pool (see dev.bookwave.app.util.Http).
    private val http = Http.shared.newBuilder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    /** Basic auth — omitted entirely when no username (URL-key servers accept it). */
    private val authHeader: String?
        get() = if (username.isBlank()) {
            null
        } else {
            "Basic " + Base64.encodeToString("$username:$password".toByteArray(), Base64.NO_WRAP)
        }

    override suspend fun list(path: String): List<CloudEntry> {
        // Collections MUST be addressed with a trailing slash: AllDebrid (and
        // some other servers) answer 404 to "PROPFIND /links" but 207 to
        // "PROPFIND /links/". Root "/" already ends with one.
        val target = join(baseUrl, path).let { if (it.endsWith("/")) it else "$it/" }
        val builder = Request.Builder()
            .url(target)
            .method("PROPFIND", PROPFIND_BODY.toRequestBody("application/xml; charset=utf-8".toMediaType()))
            .header("Depth", "1")
        authHeader?.let { builder.header("Authorization", it) }
        // await(): cancelling the coroutine cancels the request (execute() kept
        // a thread hostage for up to 60 s after the screen was gone).
        //
        // v0.8.0 — PROPFIND is a pure read: a 503/429 from a loaded Nextcloud
        // (or a Wi-Fi hiccup) is retried with jittered backoff instead of
        // emptying the library. A 401 is NOT retried: same answer every time.
        val request = builder.build()
        return withRetry(Backoff.READ) { _ ->
            http.newCall(request).await().use { response ->
                if (!response.isSuccessful) throw HttpStatusException(response.code, httpError(response.code))
                val body = response.body?.string().orEmpty()
                WebDavPropfind.parse(body, path)
            }
        }
    }

    override suspend fun stat(path: String): CloudEntry? = list(parentOf(path)).firstOrNull { it.path == path }

    override suspend fun streamUrl(path: String): String = join(baseUrl, path)

    companion object {
        private const val PROPFIND_BODY =
            """<?xml version="1.0" encoding="utf-8"?>
               <d:propfind xmlns:d="DAV:">
                 <d:prop>
                   <d:displayname/><d:getcontentlength/><d:getlastmodified/><d:resourcetype/>
                 </d:prop>
               </d:propfind>"""

        private fun normalizeBaseUrl(url: String): String {
            var u = url.trim()
            if (u.startsWith("davs://")) u = "https://" + u.removePrefix("davs://")
            return u.trimEnd('/')
        }

        private fun join(base: String, path: String): String =
            base.trimEnd('/') + "/" + path.trimStart('/')

        private fun parentOf(path: String): String =
            path.substringBeforeLast('/', missingDelimiterValue = "/")

        /** Human-readable French reason per HTTP status. */
        fun httpError(code: Int): String = when (code) {
            401 -> "401 — identifiants refusés (vérifiez l'identifiant et le mot de passe / la clé API)"
            403 -> "403 — accès refusé par le serveur"
            404 -> "404 — adresse introuvable (vérifiez l'URL)"
            405 -> "405 — méthode refusée (ce serveur n'est peut-être pas WebDAV)"
            507 -> "507 — espace insuffisant sur le serveur"
            in 500..599 -> "Erreur serveur $code"
            else -> "Erreur HTTP $code"
        }
    }
}

/**
 * PROPFIND response parser. Tolerant to any namespace prefix (D:, d:, ns0:,
 * default, or none) by stripping prefixes before DOM parsing — servers differ
 * here and a rigid "<d:response>" split silently found 0 entries on some of
 * them (AllDebrid included).
 */
object WebDavPropfind {
    fun parse(xml: String, requestedPath: String): List<CloudEntry> {
        if (xml.isBlank()) throw IOException("Réponse vide du serveur")
        // <d:response> / </d:response> → <response> / </response> (drop prefixes).
        val stripped = PREFIX_REGEX.replace(xml) { m -> "<" + m.groupValues[1] }
        val doc = runCatching {
            DocumentBuilderFactory.newInstance()
                .apply {
                    isNamespaceAware = false
                    // XXE hardening: a hostile WebDAV server must not be able to
                    // smuggle DOCTYPE/external entities into the parser.
                    runCatching { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
                    runCatching { setFeature(javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING, true) }
                    // Android's XMLConstants does not expose these property
                    // names — use the literal JAXP URIs.
                    runCatching { setAttribute("http://javax.xml.XMLConstants/property/accessExternalDTD", "") }
                    runCatching { setAttribute("http://javax.xml.XMLConstants/property/accessExternalSchema", "") }
                }
                .newDocumentBuilder()
                .parse(stripped.byteInputStream())
        }.getOrElse {
            throw IOException("Réponse illisible — ce serveur répond-il bien en WebDAV ?")
        }

        val responses = doc.getElementsByTagName("response")
        val entries = mutableListOf<CloudEntry>()
        for (i in 0 until responses.length) {
            val el = responses.item(i) as org.w3c.dom.Element
            val href = firstText(el, "href") ?: continue
            // The request path MUST come from the server's href (not displayname):
            // names can differ from paths and unencoded names 404.
            val hrefPath = hrefToPath(href)
            if (hrefPath == "/" || hrefPath == requestedPath.trimEnd('/')) continue // the collection itself
            val name = firstText(el, "displayname")
                ?: hrefPath.trimEnd('/').substringAfterLast('/')
            if (name.isBlank()) continue
            val isDir = el.getElementsByTagName("collection").length > 0
            val size = firstText(el, "getcontentlength")?.toLongOrNull() ?: 0L
            val modified = firstText(el, "getlastmodified")?.let { parseHttpDate(it) } ?: 0L
            entries += CloudEntry(
                path = hrefPath,
                name = name,
                isDirectory = isDir,
                sizeBytes = size,
                modifiedEpochMs = modified,
                mediaKind = if (isDir) MediaKind.OTHER else MediaKind.of(name),
            )
        }
        return entries
    }

    /** `<d:response>` / `</d:response>` → `<response>` / `</response>` (group 1 = optional slash). */
    private val PREFIX_REGEX = Regex("<(/?)([A-Za-z_][\\w.-]*):")

    /** href (absolute path or full URL, percent-encoded) → decoded app path like "/links/Livre". */
    private fun hrefToPath(href: String): String {
        val rawPath = runCatching { java.net.URI(href).path }
            .getOrNull()?.takeIf { it.isNotBlank() } ?: href
        val decoded = runCatching { URLDecoder.decode(rawPath, "UTF-8") }.getOrDefault(rawPath)
        return "/" + decoded.trim('/')
    }

    private fun firstText(el: org.w3c.dom.Element, tag: String): String? {
        val nodes = el.getElementsByTagName(tag)
        for (i in 0 until nodes.length) {
            val text = nodes.item(i).textContent?.trim()
            if (!text.isNullOrEmpty()) return text
        }
        return null
    }

    private fun parseHttpDate(value: String): Long = runCatching {
        java.text.SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", java.util.Locale.US)
            .parse(value)?.time ?: 0L
    }.getOrDefault(0L)
}
