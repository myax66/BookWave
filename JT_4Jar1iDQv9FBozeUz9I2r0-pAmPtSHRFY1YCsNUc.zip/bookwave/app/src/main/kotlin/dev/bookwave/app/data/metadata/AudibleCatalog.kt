package dev.bookwave.app.data.metadata

import dev.bookwave.app.util.Http
import dev.bookwave.app.util.HttpStatusException
import dev.bookwave.app.util.await
import dev.bookwave.app.util.withRetry
import dev.bookwave.core.util.Backoff
import dev.bookwave.core.metadata.AudibleQueries
import dev.bookwave.core.metadata.BookMetadata
import dev.bookwave.core.metadata.SeriesRef
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.Request
import org.json.JSONObject
import java.util.Collections
import java.util.Locale

/**
 * Audible's public catalogue endpoint (undocumented but stable, used by the
 * whole self-hosted audiobook ecosystem). No API key, one host per market:
 * api.audible.fr for French storefronts — ASINs are market-scoped, so the
 * wrong host returns empty stubs.
 *
 * v0.7.0 — measured against the live API:
 *  - `title=` is a strict matcher (full cleaned names return 0) while
 *    `keywords=` is tolerant: both modes are exposed, the query ladder in
 *    [AudibleQueries] decides which one to use;
 *  - `author=` is a hard AND filter: a single wrong author guess returned 0
 *    results no matter the keywords, so the caller must be able to retry
 *    without it (done by [MetadataEnricher]);
 *  - the catalogue mixes ebook stubs (no author, no narrator, no runtime) and
 *    other-language editions into the results: both are filtered/penalised;
 *  - products come back in a relevance order that changes between queries, so
 *    results from several queries are pooled and ranked locally;
 *  - identical searches are replayed constantly (every volume of a saga asks
 *    the same saga name): a bounded in-memory LRU answers without network.
 */
class AudibleCatalog(val market: String) {

    private val host = "https://api.audible.$market"

    companion object {
        private const val RESPONSE_GROUPS =
            "contributors,product_attrs,media,series,product_desc,rating,product_extended_attrs"
        private const val NUM_RESULTS = 20

        /** The catalogue caps `num_results` at 50 (100 returns an empty body). */
        private const val SWEEP_PAGE_SIZE = 50

        /** Bounded LRU: (market|mode|query|author) → products. */
        private val cache: MutableMap<String, List<BookMetadata>> = Collections.synchronizedMap(
            object : LinkedHashMap<String, List<BookMetadata>>(32, 0.75f, true) {
                override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, List<BookMetadata>>) =
                    size > 96
            },
        )

        fun clearCache() {
            cache.clear()
        }
    }

    suspend fun search(query: AudibleQueries.Query, author: String?): List<BookMetadata> {
        val key = "$market|${query.mode}|${query.text.lowercase(Locale.ROOT)}|${author?.lowercase(Locale.ROOT).orEmpty()}"
        cache[key]?.let { return it }
        val found = request { url ->
            when (query.mode) {
                AudibleQueries.Mode.TITLE -> url.addQueryParameter("title", query.text)
                AudibleQueries.Mode.KEYWORDS -> url.addQueryParameter("keywords", query.text)
            }
            if (!author.isNullOrBlank()) url.addQueryParameter("author", author)
        }
        cache[key] = found
        return found
    }

    /**
     * v0.7.4 — the WHOLE catalogue behind one query, paged.
     *
     * The catalogue endpoint ANDs every keyword, so a long folder name can
     * never be sent as-is. Asking for an author (or a saga) returns his books
     * page after page and the local scorer picks the right one: measured, two
     * pages of `keywords=brandon sanderson` hold 100 titles including editions
     * whose official name shares nothing with the folder (`Vent et vérité -
     * Volume 2` for "Les Archives de Roshar 05 Vent et verite 2").
     */
    suspend fun sweep(text: String, pages: Int = 2): List<BookMetadata> {
        val key = "sweep|$market|${text.lowercase(Locale.ROOT)}|$pages"
        cache[key]?.let { return it }
        val all = LinkedHashMap<String, BookMetadata>()
        for (page in 1..pages.coerceIn(1, 3)) {
            val found = request(perPage = SWEEP_PAGE_SIZE) { url ->
                url.addQueryParameter("keywords", text)
                url.addQueryParameter("page", page.toString())
            }
            found.forEach { all.putIfAbsent(it.asin, it) }
            if (found.size < SWEEP_PAGE_SIZE) break
        }
        val out = all.values.toList()
        cache[key] = out
        return out
    }

    /** Direct ASIN lookup — used when the user pastes an Audible identifier. */
    suspend fun byAsin(asin: String): BookMetadata? {
        val key = "$market|asin|$asin"
        cache[key]?.let { return it.firstOrNull() }
        val found = request { url -> url.addQueryParameter("asins", asin) }
        cache[key] = found
        return found.firstOrNull()
    }

    private suspend fun request(
        perPage: Int = NUM_RESULTS,
        build: (HttpUrl.Builder) -> Unit,
    ): List<BookMetadata> =
        withContext(Dispatchers.IO) {
            val url = "$host/1.0/catalog/products".toHttpUrl().newBuilder()
                .addQueryParameter("num_results", perPage.toString())
                .addQueryParameter("response_groups", RESPONSE_GROUPS)
                .also(build)
                .build()
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Bookwave/0.7 (audiobook library)")
                .build()
            // v0.8.0 — a 502/503 from the catalogue is transient; retrying it
            // costs 350 ms and saves a whole book from being ledgered as a miss.
            withRetry(Backoff.CATALOG) { _ ->
                Http.shared.newCall(request).await().use { resp ->
                    if (!resp.isSuccessful) {
                        throw HttpStatusException(resp.code, "Audible HTTP ${resp.code}")
                    }
                    parse(JSONObject(resp.body?.string().orEmpty()))
                }
            }
        }

    private fun parse(root: JSONObject): List<BookMetadata> {
        val products = root.optJSONArray("products") ?: return emptyList()
        return (0 until products.length()).mapNotNull { i ->
            runCatching { toMetadata(products.getJSONObject(i)) }.getOrNull()
        }.filter { it.looksLikeAudiobook }
    }

    private fun toMetadata(p: JSONObject): BookMetadata? {
        val asin = p.optString("asin")
        val title = p.optString("title")
        if (asin.isBlank() || title.isBlank()) return null
        val series = p.optJSONArray("series").let { array ->
            if (array == null) emptyList() else (0 until array.length()).mapNotNull { i ->
                val o = array.optJSONObject(i) ?: return@mapNotNull null
                val name = o.optString("title").takeIf { it.isNotBlank() } ?: return@mapNotNull null
                SeriesRef(name, o.optString("sequence").replace(',', '.').toDoubleOrNull())
            }
        }
        return BookMetadata(
            asin = asin,
            market = market,
            title = title,
            subtitle = p.optString("subtitle").takeIf { it.isNotBlank() },
            authors = names(p, "authors"),
            narrators = names(p, "narrators"),
            seriesName = series.firstOrNull()?.name,
            seriesIndex = series.firstOrNull()?.index,
            seriesEntries = series,
            runtimeMin = p.optInt("runtime_length_min", 0),
            publisher = p.optString("publisher_name").takeIf { it.isNotBlank() },
            releaseYear = p.optString("release_date").take(4).toIntOrNull() ?: 0,
            summary = p.optString("merchandising_summary").takeIf { it.isNotBlank() }?.let(::stripHtml),
            coverUrl = p.optJSONObject("product_images")?.optString("500")?.takeIf { it.isNotBlank() },
            rating = p.optJSONObject("rating")?.optDouble("average_rating", 0.0) ?: 0.0,
            language = p.optString("language").takeIf { it.isNotBlank() && !it.equals("null", true) },
        )
    }

    private fun names(p: JSONObject, field: String): List<String> {
        val array = p.optJSONArray(field) ?: return emptyList()
        return (0 until array.length()).mapNotNull { i ->
            array.optJSONObject(i)?.optString("name")?.takeIf { it.isNotBlank() }
        }
    }

    private fun stripHtml(s: String): String =
        s.replace(Regex("<[^>]+>"), "")
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace(Regex("\\s{2,}"), " ")
            .trim()
}
