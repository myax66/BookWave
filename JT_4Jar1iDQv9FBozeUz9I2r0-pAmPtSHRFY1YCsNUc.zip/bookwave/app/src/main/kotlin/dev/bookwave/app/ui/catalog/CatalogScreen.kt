package dev.bookwave.app.ui.catalog

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.bookwave.app.data.AppSettings
import dev.bookwave.app.data.alldebrid.AllDebridApi
import dev.bookwave.app.data.torznab.TorznabApi
import dev.bookwave.app.data.torznab.TrackerProfile
import dev.bookwave.app.util.suspendRunCatching
import dev.bookwave.core.library.TitleCleaner
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch

/** What the result list currently shows. */
private enum class ListMode { LATEST, SEARCH }

/**
 * Audiobook catalogue browser over every configured Torznab tracker (C411,
 * TR4KER). Opening the screen loads each tracker's newest releases — the same
 * RSS-style feed Prowlarr polls — and a typed query switches to a free-text
 * search across the selected trackers.
 *
 * Trackers are queried in parallel and results are merged, each row tagged with
 * its source. A tracker that fails (bad key, offline) is reported without
 * hiding the results of the others.
 *
 * One tap then downloads that release's .torrent with the member's API key and
 * uploads it to AllDebrid; the transfer screen tracks it until the files land
 * in /links/.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CatalogScreen(
    onOpenTransfers: () -> Unit,
    onOpenSettings: () -> Unit,
    onBack: (() -> Unit)? = null,
) {
    val context = LocalContext.current
    val settings = remember { AppSettings(context) }
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current

    val allDebridKey = settings.webdavUser

    // One client per tracker per configuration, so ETag caches survive calls.
    val trackers = remember(
        settings.c411Url, settings.c411ApiKey,
        settings.tr4kerUrl, settings.tr4kerApiKey,
    ) {
        buildList {
            if (settings.c411ApiKey.isNotBlank()) {
                add(TorznabApi(TrackerProfile.C411, settings.c411Url, settings.c411ApiKey))
            }
            if (settings.tr4kerApiKey.isNotBlank()) {
                add(TorznabApi(TrackerProfile.TR4KER, settings.tr4kerUrl, settings.tr4kerApiKey))
            }
        }
    }

    // The send-to-AllDebrid button needs an AllDebrid ACCOUNT, not just any
    // non-blank WebDAV login: Nextcloud users used to see an enabled button
    // that always failed with an auth error.
    val canSendAllDebrid = settings.webdavUser.isNotBlank() &&
        AllDebridApi.isAllDebridAccount(settings.webdavUrl)

    /** null = every configured tracker. */
    var selectedId by rememberSaveable { mutableStateOf<String?>(null) }
    val active = trackers.filter { selectedId == null || it.profile.id == selectedId }

    // rememberSaveable: query, results and mode survive rotation (Release is
    // Serializable so the list stores in the saved-state bundle).
    var query by rememberSaveable { mutableStateOf("") }
    var results by rememberSaveable { mutableStateOf<List<TorznabApi.Release>>(emptyList()) }
    var mode by rememberSaveable { mutableStateOf(ListMode.LATEST) }
    var searchedQuery by rememberSaveable { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    var warning by remember { mutableStateOf<String?>(null) }
    var notice by rememberSaveable { mutableStateOf<String?>(null) }
    var busyKeys by remember { mutableStateOf<Set<String>>(emptySet()) }
    var addedIds by remember { mutableStateOf<Map<String, Long>>(emptyMap()) }

    /** Fans a call out to the selected trackers, merging what answers. */
    suspend fun collect(
        block: suspend (TorznabApi) -> List<TorznabApi.Release>,
        sort: Boolean,
    ) {
        val outcomes = active.map { api ->
            // suspendRunCatching: leaving the screen cancels the queries for
            // real instead of reporting every tracker as "failed".
            scope.async { api.label to suspendRunCatching { block(api) } }
        }.awaitAll()

        val merged = ArrayList<TorznabApi.Release>()
        val failures = ArrayList<String>()
        for ((label, outcome) in outcomes) {
            outcome.onSuccess { merged += it }
                .onFailure { e -> failures += "$label : ${e.message ?: "erreur"}" }
        }

        results = if (sort) {
            merged.sortedByDescending { it.dateMillis }
        } else {
            merged
        }
        warning = if (merged.isNotEmpty() && failures.isNotEmpty()) failures.joinToString("\n") else null
        error = if (merged.isEmpty() && failures.isNotEmpty()) failures.joinToString("\n") else null
    }

    fun loadLatest() {
        if (active.isEmpty()) return
        loading = true
        error = null
        warning = null
        notice = null
        scope.launch {
            suspendRunCatching { collect({ it.latest() }, sort = true) }
                .onFailure { e -> error = e.message ?: "Erreur inconnue" }
            mode = ListMode.LATEST
            searchedQuery = null
            loading = false
        }
    }

    fun runSearch(raw: String) {
        val q = raw.trim()
        if (active.isEmpty()) return
        if (q.isEmpty()) {
            loadLatest()
            return
        }
        loading = true
        error = null
        warning = null
        notice = null
        scope.launch {
            suspendRunCatching { collect({ it.search(q) }, sort = false) }
                .onFailure { e -> error = e.message ?: "Erreur inconnue" }
            mode = ListMode.SEARCH
            searchedQuery = q
            loading = false
        }
    }

    fun sendToAllDebrid(release: TorznabApi.Release) {
        val api = trackers.firstOrNull { it.label == release.source } ?: return
        val key = release.key
        busyKeys = busyKeys + key
        notice = null
        scope.launch {
            suspendRunCatching {
                val (fileName, bytes) = api.downloadTorrent(release.enclosureUrl, release.title)
                AllDebridApi(allDebridKey).uploadTorrentFile(fileName, bytes)
            }
                .onSuccess { transferId ->
                    addedIds = addedIds + (key to transferId)
                    notice = "✅ « ${TitleCleaner.clean(release.title).title} » envoyé à AllDebrid " +
                        "(transfert #$transferId)"
                }
                .onFailure { e -> notice = "❌ ${e.message}" }
            busyKeys = busyKeys - key
        }
    }

    // Newest additions load as soon as the screen opens. After a rotation the
    // saved state (results/mode/query) is restored instead of re-fetching.
    LaunchedEffect(trackers, selectedId) {
        if (results.isEmpty() && !loading) {
            if (mode == ListMode.SEARCH && !searchedQuery.isNullOrBlank()) {
                runSearch(searchedQuery!!)
            } else {
                loadLatest()
            }
        }
    }

    Scaffold(
        // Insets are handled by the TopAppBar and the outer tab Scaffold:
        // adding them here again doubled the bottom gap above the tab bar.
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            TopAppBar(
                title = { Text("Catalogue livres audio") },
                navigationIcon = {
                    if (onBack != null) {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            keyboard?.hide()
                            if (mode == ListMode.SEARCH && searchedQuery != null) {
                                runSearch(searchedQuery!!)
                            } else {
                                loadLatest()
                            }
                        },
                        enabled = !loading && active.isNotEmpty(),
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Actualiser")
                    }
                },
            )
        },
    ) { padding ->

        if (trackers.isEmpty()) {
            NoKeyContent(padding = padding, onOpenSettings = onOpenSettings, onBack = onBack)

            return@Scaffold
        }

        // Everything scrolls together — search, filters and results in one list.
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item(key = "search-field") {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Rechercher un livre audio") },
                    placeholder = { Text("titre, auteur, série…") },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(
                        onSearch = {
                            keyboard?.hide()
                            runSearch(query)
                        },
                    ),
                )
            }

            if (trackers.size > 1) {
                item(key = "tracker-chips") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = selectedId == null,
                            onClick = { selectedId = null },
                            label = { Text("Tous") },
                        )
                        trackers.forEach { api ->
                            FilterChip(
                                selected = selectedId == api.profile.id,
                                onClick = { selectedId = api.profile.id },
                                label = { Text(api.label) },
                            )
                        }
                    }
                }
            }

            item(key = "search-actions") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Button(
                        onClick = {
                            keyboard?.hide()
                            runSearch(query)
                        },
                        enabled = query.isNotBlank() && !loading,
                        modifier = Modifier.weight(1f),
                    ) { Text(if (loading && mode == ListMode.SEARCH) "Recherche…" else "Rechercher") }

                    if (mode == ListMode.SEARCH) {
                        FilterChip(
                            selected = false,
                            onClick = {
                                keyboard?.hide()
                                query = ""
                                loadLatest()
                            },
                            label = { Text("Derniers ajouts") },
                        )
                    }
                }
            }

            item(key = "status-row") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    val sources = active.joinToString(" + ") { it.label }
                    Text(
                        when {
                            loading && results.isEmpty() -> "Chargement depuis $sources…"
                            mode == ListMode.SEARCH -> "Résultats pour « $searchedQuery » · ${results.size}"
                            else -> "Derniers ajouts · $sources · ${results.size}"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (loading) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                }
            }

            error?.let { msg ->
                item(key = "error-card") {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer,
                        ),
                    ) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(msg, style = MaterialTheme.typography.bodyMedium)
                            OutlinedButton(onClick = { loadLatest() }) { Text("Réessayer") }
                        }
                    }
                }
            }

            warning?.let { msg ->
                item(key = "warning-card") {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        ),
                    ) {
                        Text(
                            "Un tracker n'a pas répondu :\n$msg",
                            Modifier.padding(12.dp),
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }

            notice?.let { msg ->
                item(key = "notice-card") {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer,
                        ),
                    ) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(msg, style = MaterialTheme.typography.bodyMedium)
                            OutlinedButton(
                                onClick = onOpenTransfers,
                                modifier = Modifier.fillMaxWidth(),
                            ) { Text("Suivre les transferts") }
                        }
                    }
                }
            }

            if (!loading && results.isEmpty() && error == null) {
                item(key = "empty-msg") {
                    Text(
                        if (mode == ListMode.SEARCH) {
                            "Aucun livre audio trouvé pour « $searchedQuery »."
                        } else {
                            "Aucune nouveauté renvoyée pour le moment."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                }
            }

            items(results, key = { it.key }) { release ->
                ReleaseRow(
                    release = release,
                    isBusy = release.key in busyKeys,
                    transferId = addedIds[release.key],
                    canSend = canSendAllDebrid,
                    showDate = mode == ListMode.LATEST,
                    showSource = trackers.size > 1,
                    onAdd = { sendToAllDebrid(release) },
                )
            }
        }
    }
}

@Composable
private fun ReleaseRow(
    release: TorznabApi.Release,
    isBusy: Boolean,
    transferId: Long?,
    canSend: Boolean,
    showDate: Boolean,
    showSource: Boolean,
    onAdd: () -> Unit,
) {
    val cleaned = remember(release.title) { TitleCleaner.clean(release.title) }
    val age = remember(release.dateMillis) { TorznabApi.relativeDate(release.dateMillis) }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    cleaned.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                if (showSource) {
                    Spacer(Modifier.width(8.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = MaterialTheme.shapes.extraSmall,
                    ) {
                        Text(
                            release.source,
                            Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                }
            }
            cleaned.author?.takeIf { it.isNotBlank() }?.let {
                Text(
                    it,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            if (release.title != cleaned.title) {
                Text(
                    release.title,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Text(release.sizeLabel, style = MaterialTheme.typography.labelMedium)
                Text("·", style = MaterialTheme.typography.labelMedium)
                Text(
                    when (release.seeders) {
                        null -> "seeders n.c."
                        0 -> "aucun seeder"
                        else -> "${release.seeders} seeders"
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = if (release.seeders == 0) {
                        MaterialTheme.colorScheme.error
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                )
                if (showDate && age.isNotBlank()) {
                    Text("·", style = MaterialTheme.typography.labelMedium)
                    Text(
                        age,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (release.isFreeleech) {
                    Surface(
                        color = MaterialTheme.colorScheme.tertiaryContainer,
                        shape = MaterialTheme.shapes.extraSmall,
                    ) {
                        Text(
                            "FREELEECH",
                            Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                }
            }

            Button(
                onClick = onAdd,
                enabled = !isBusy && transferId == null && canSend,
                modifier = Modifier.fillMaxWidth(),
            ) {
                if (isBusy) {
                    CircularProgressIndicator(
                        Modifier.size(14.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary,
                    )
                } else {
                    Icon(
                        Icons.Default.Bolt,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                    )
                }
                Spacer(Modifier.width(8.dp))
                Text(
                    when {
                        transferId != null -> "Ajouté (transfert #$transferId)"
                        !canSend -> "Clé AllDebrid manquante"
                        isBusy -> "Envoi en cours…"
                        else -> "Ajouter à AllDebrid"
                    },
                )
            }
        }
    }
}

@Composable
private fun NoKeyContent(
    padding: PaddingValues,
    onOpenSettings: () -> Unit,
    onBack: (() -> Unit)? = null,
) {
    Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
        Card(Modifier.padding(24.dp).fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Aucun tracker configuré",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                )
                Text(
                    "Le catalogue passe par l'API Torznab officielle de chaque site. Renseigne au " +
                        "moins une clé dans les réglages de Bookwave :",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Text(
                    "• C411 — c411.org → ton profil → Clés API (page « Integrations »)\n" +
                        "• TR4KER — tr4ker.net → Mon compte → Paramètres → « Clé API »",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Text(
                    "Ces clés sont distinctes de ta clé AllDebrid et restent stockées uniquement " +
                        "sur ton téléphone.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(4.dp))
                Button(onClick = onOpenSettings, modifier = Modifier.fillMaxWidth()) {
                    Text("Ouvrir les réglages")
                }
                if (onBack != null) {
                    OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
                        Text("Retour à la bibliothèque")
                    }
                }
            }
        }
    }
}
