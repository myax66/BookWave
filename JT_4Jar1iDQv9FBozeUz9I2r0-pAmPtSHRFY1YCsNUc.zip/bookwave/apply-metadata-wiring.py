"""Re-applies the Audible-metadata wiring to LibraryScreen/PlayerScreen.
These two large files keep reverting to their v0.5.3 state between sandbox
snapshots; run this script (idempotent guards inside) then rebuild."""
import pathlib, sys

ROOT = pathlib.Path(__file__).resolve().parent
LS = ROOT / "app/src/main/kotlin/dev/bookwave/app/ui/library/LibraryScreen.kt"
PS = ROOT / "app/src/main/kotlin/dev/bookwave/app/ui/player/PlayerScreen.kt"
SS = ROOT / "app/src/main/kotlin/dev/bookwave/app/ui/settings/SettingsScreen.kt"
GR = ROOT / "app/build.gradle.kts"

def add_imports(path, imports):
    s = path.read_text()
    add = [i for i in imports if f"import {i}" not in s]
    if add:
        lines = s.splitlines()
        idx = max(i for i, l in enumerate(lines) if l.startswith("import "))
        lines[idx:idx] = [f"import {i}" for i in add]
        s = "\n".join(lines) + "\n"
        path.write_text(s)
    return add

def rep(path, old, new):
    s = path.read_text()
    if old not in s:
        if new.split("\n")[0] in s:
            print(f"  (already applied) {path.name}: {old[:60]!r}")
            return
        raise SystemExit(f"NOT FOUND in {path}: {old[:100]!r}")
    path.write_text(s.replace(old, new, 1))

# ---------------- LibraryScreen ----------------
add_imports(LS, [
    "androidx.compose.foundation.ExperimentalFoundationApi",
    "androidx.compose.foundation.combinedClickable",
    "androidx.compose.foundation.layout.Spacer",
    "androidx.compose.foundation.rememberScrollState",
    "androidx.compose.foundation.verticalScroll",
    "androidx.compose.material3.AlertDialog",
    "androidx.compose.material3.HorizontalDivider",
    "androidx.compose.material3.TextButton",
    "dev.bookwave.app.data.metadata.EnrichResult",
    "dev.bookwave.app.data.metadata.MetadataEnricher",
    "dev.bookwave.app.data.metadata.MetadataStore",
    "dev.bookwave.core.metadata.BookMetadata",
    "kotlinx.coroutines.CancellationException",
    "kotlinx.coroutines.delay",
    "kotlinx.coroutines.flow.first",
    "kotlinx.coroutines.launch",
])

rep(LS, """    private val refreshTick = MutableStateFlow(RefreshRequest())
    private val configuredState = MutableStateFlow(repository.isConfigured())""",
"""    private val refreshTick = MutableStateFlow(RefreshRequest())
    private val configuredState = MutableStateFlow(repository.isConfigured())

    /** Official Audible metadata, merged over torrent-cleaned fields. */
    val metadata: MetadataStore = repository.metadata

    private val enricher = MetadataEnricher(
        metadata,
        when (repository.settings.enrichMarket) {
            "fr" -> listOf("fr")
            "com" -> listOf("com")
            else -> listOf("fr", "com")
        },
    )

    /** What the library sheet shows: candidate editions, book fiche, or a note. */
    sealed interface LibraryDialog {
        data class Candidates(val bookId: String, val options: List<Pair<BookMetadata, Double>>) : LibraryDialog
        data class Fiche(val bookId: String) : LibraryDialog
        data class Message(val text: String) : LibraryDialog
    }

    private val _dialog = MutableStateFlow<LibraryDialog?>(null)
    val dialog: StateFlow<LibraryDialog?> = _dialog

    /** User-visible outcome of the last background identification pass. */
    private val _report = MutableStateFlow<String?>(null)
    val report: StateFlow<String?> = _report
    fun dismissReport() {
        _report.value = null
    }""")

rep(LS, """    val state: StateFlow<LibraryUiState> =
        refreshTick
            .flatMapLatest { req -> snapshots(req) }
            .combine(progressStore.progress) { snap, saved ->
                val books = snap.books
                when {
                    books == null && snap.error != null -> LibraryUiState.Failed(snap.error)
                    books == null -> LibraryUiState.Loading
                    else -> LibraryUiState.Loaded(
                        books = books.map { book -> book to saved.firstOrNull { it.bookId == book.id } },
                        refreshing = snap.refreshing,
                        error = snap.error,
                        note = snap.note,
                    )
                }
            }""",
"""    val state: StateFlow<LibraryUiState> =
        refreshTick
            .flatMapLatest { req -> snapshots(req) }
            .combine(progressStore.progress) { snap, saved -> snap to saved }
            // metadata.version: re-merge (titles/covers/runtime) as soon as an
            // enrichment lands, without rescanning the WebDAV.
            .combine(metadata.version) { (snap, saved), _ ->
                val books = snap.books
                when {
                    books == null && snap.error != null -> LibraryUiState.Failed(snap.error)
                    books == null -> LibraryUiState.Loading
                    else -> LibraryUiState.Loaded(
                        books = books.map { book ->
                            metadata.merge(book) to saved.firstOrNull { it.bookId == book.id }
                        },
                        refreshing = snap.refreshing,
                        error = snap.error,
                        note = snap.note,
                    )
                }
            }""")

rep(LS, """    /** Screen resume: serves the cache instantly (no network on a busy WebDAV). */
    fun refresh() {
        configuredState.value = repository.isConfigured()
        refreshTick.value = RefreshRequest(refreshTick.value.seq + 1, force = false)
    }""",
"""    /** Screen resume: serves the cache instantly (no network on a busy WebDAV). */
    fun refresh() {
        configuredState.value = repository.isConfigured()
        refreshTick.value = RefreshRequest(refreshTick.value.seq + 1, force = false)
        if (repository.settings.consumeEnrichPassRequest() && repository.settings.enrichEnabled) {
            runEnrichPass(30)
        }
    }""")

rep(LS, """    /** Manual "reload" button / retry: always refetches. */
    fun forceRefresh() {
        configuredState.value = repository.isConfigured()
        refreshTick.value = RefreshRequest(refreshTick.value.seq + 1, force = true)
    }
}""",
"""    /** Manual "reload" button / retry: always refetches. */
    fun forceRefresh() {
        configuredState.value = repository.isConfigured()
        refreshTick.value = RefreshRequest(refreshTick.value.seq + 1, force = true)
    }

    fun metadataOf(bookId: String): BookMetadata? = metadata.of(bookId)

    fun dismissDialog() {
        _dialog.value = null
    }

    fun confirmMatch(bookId: String, meta: BookMetadata) {
        metadata.put(bookId, meta)
        _dialog.value = null
    }

    fun removeMetadata(bookId: String) {
        metadata.remove(bookId)
        _dialog.value = null
    }

    /** Long press: fiche if enriched, Audible matching otherwise. */
    fun onBookLongPress(book: Audiobook) {
        viewModelScope.launch {
            if (metadata.of(book.id) != null) {
                _dialog.value = LibraryDialog.Fiche(book.id)
            } else {
                // Explicit user intent: bypass the 7-day miss ledger.
                runEnrich(book, force = true)
            }
        }
    }

    fun chooseOtherEdition(bookId: String) {
        viewModelScope.launch {
            val book = (state.value as? LibraryUiState.Loaded)?.books
                ?.firstOrNull { it.first.id == bookId }?.first ?: return@launch
            runEnrich(book, force = true)
        }
    }

    private suspend fun runEnrich(book: Audiobook, force: Boolean) {
        val result: EnrichResult = try {
            enricher.enrich(book, force)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            _dialog.value = LibraryDialog.Message(
                "Recherche Audible impossible : ${e.message ?: e.javaClass.simpleName}",
            )
            return
        }
        when (result) {
            // Applied: metadata.version bumps and the state re-merges itself.
            is EnrichResult.Applied -> Unit
            is EnrichResult.Suggest -> _dialog.value = LibraryDialog.Candidates(book.id, result.options)
            EnrichResult.None -> _dialog.value = LibraryDialog.Message(
                "Aucune correspondance Audible trouvée pour « ${book.title} ».",
            )
            is EnrichResult.Failed -> _dialog.value = LibraryDialog.Message(
                "Recherche Audible impossible : ${result.message}",
            )
        }
    }

    init {
        if (repository.settings.enrichEnabled) runEnrichPass(15)
    }

    /**
     * One background identification pass with a USER-VISIBLE report: silent
     * passes are how v0.6.0/0.6.1 shipped "nothing happened" twice.
     * Listening books first; true misses ledgered 7 days; network errors
     * never ledgered and stop the pass.
     */
    private fun runEnrichPass(budget: Int) {
        viewModelScope.launch {
            state.first { it is LibraryUiState.Loaded }
            val loaded = state.value as? LibraryUiState.Loaded ?: return@launch
            var applied = 0
            var suggest = 0
            var none = 0
            var failed = 0
            val targets = (loaded.books.filter { it.second?.isFinished == false }.map { it.first } +
                loaded.books.map { it.first })
                .distinctBy { it.id }
                .filter { metadata.of(it.id) == null && !metadata.triedRecently(it.id) }
                .take(budget)
            for (book in targets) {
                val r = try {
                    enricher.enrich(book)
                } catch (e: CancellationException) {
                    return@launch
                } catch (e: Exception) {
                    EnrichResult.Failed(e.message ?: e.javaClass.simpleName)
                }
                when (r) {
                    is EnrichResult.Applied -> applied++
                    is EnrichResult.Suggest -> suggest++
                    EnrichResult.None -> none++
                    is EnrichResult.Failed -> {
                        failed++
                        break
                    }
                }
                delay(800)
            }
            _report.value = "Enrichissement Audible : $applied appliqués" +
                (if (suggest > 0) ", $suggest à départager (appui long)" else "") +
                (if (none > 0) ", $none introuvables" else "") +
                (if (failed > 0) ", $failed en erreur (réseau ?)" else "")
        }
    }
}""")

rep(LS, """    val configured by viewModel.configured.collectAsStateWithLifecycle()
""",
"""    val configured by viewModel.configured.collectAsStateWithLifecycle()
    val dialog by viewModel.dialog.collectAsStateWithLifecycle()
    val report by viewModel.report.collectAsStateWithLifecycle()

    when (val d = dialog) {
        is LibraryViewModel.LibraryDialog.Candidates -> MatchCandidatesDialog(
            options = d.options,
            onPick = { viewModel.confirmMatch(d.bookId, it) },
            onDismiss = viewModel::dismissDialog,
        )
        is LibraryViewModel.LibraryDialog.Fiche -> {
            val meta = viewModel.metadataOf(d.bookId)
            if (meta != null) {
                BookFicheDialog(
                    meta = meta,
                    onOther = { viewModel.chooseOtherEdition(d.bookId) },
                    onRemove = { viewModel.removeMetadata(d.bookId) },
                    onDismiss = viewModel::dismissDialog,
                )
            }
        }
        is LibraryViewModel.LibraryDialog.Message -> AlertDialog(
            onDismissRequest = viewModel::dismissDialog,
            text = { Text(d.text) },
            confirmButton = { TextButton(onClick = viewModel::dismissDialog) { Text("OK") } },
        )
        null -> Unit
    }
""")

rep(LS, """                        s.error?.let { msg ->""",
"""                        report?.let { msg ->
                            item(span = { GridItemSpan(maxLineSpan) }, key = "enrich-report") {
                                Surface(
                                    color = MaterialTheme.colorScheme.secondaryContainer,
                                    shape = MaterialTheme.shapes.medium,
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    Row(
                                        Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        Text(
                                            msg,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                                            modifier = Modifier.weight(1f),
                                        )
                                        TextButton(onClick = viewModel::dismissReport) { Text("OK") }
                                    }
                                }
                            }
                        }
                        s.error?.let { msg ->""")

rep(LS, """                                        BookGridItem(
                                            book = book,
                                            progress = progress,
                                            onClick = {
                                                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                                onBookClick(book.id, book.title, book.author)
                                            },
                                        )""",
"""                                        BookGridItem(
                                            book = book,
                                            progress = progress,
                                            onClick = {
                                                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                                onBookClick(book.id, book.title, book.author)
                                            },
                                            onLongClick = {
                                                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                                viewModel.onBookLongPress(book)
                                            },
                                            hasRealDuration = (viewModel.metadataOf(book.id)?.runtimeMin ?: 0) > 0,
                                        )""")

rep(LS, """private fun BookGridItem(
    book: Audiobook,
    progress: ListeningProgress?,
    onClick: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),""",
"""@OptIn(ExperimentalFoundationApi::class)
private fun BookGridItem(
    book: Audiobook,
    progress: ListeningProgress?,
    onClick: () -> Unit,
    onLongClick: () -> Unit = {},
    hasRealDuration: Boolean = false,
) {
    Card(
        modifier = Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLongClick),""")

rep(LS, """                        // Size-based estimate (assumes ~128 kbps): shown as
                        // approximate, honest about VBR/FLAC deviations.
                        "~ " + TimeFmt.formatCoarse(book.durationMs),""",
"""                        // Size-based estimate (assumes ~128 kbps): shown as
                        // approximate — unless Audible provided the real runtime.
                        (if (hasRealDuration) "" else "~ ") + TimeFmt.formatCoarse(book.durationMs),""")

s = LS.read_text()
if "private fun MatchCandidatesDialog(" not in s:
    s += '''

/** "Pick the edition" sheet: scored Audible candidates for one book. */
@Composable
private fun MatchCandidatesDialog(
    options: List<Pair<BookMetadata, Double>>,
    onPick: (BookMetadata) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choisir l'édition") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    "Plusieurs éditions Audible correspondent : touchez la bonne.",
                    style = MaterialTheme.typography.bodySmall,
                )
                options.forEach { (meta, score) ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPick(meta) }
                            .padding(vertical = 10.dp),
                    ) {
                        Text(meta.title, style = MaterialTheme.typography.titleSmall)
                        Text(
                            buildString {
                                append(meta.authors.joinToString(", ").ifBlank { "auteur inconnu" })
                                meta.narrators.firstOrNull()?.let { append(" — lu par $it") }
                                if (meta.releaseYear > 0) append(" · ${meta.releaseYear}")
                                if (meta.runtimeMin > 0) append(" · ${meta.runtimeMin / 60} h ${meta.runtimeMin % 60}")
                                append(" · confiance ${(score * 100).toInt()} %")
                            },
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    HorizontalDivider()
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}

/** Book fiche: everything Audible told us about this book. */
@Composable
private fun BookFicheDialog(
    meta: BookMetadata,
    onOther: () -> Unit,
    onRemove: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(meta.title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (meta.authors.isNotEmpty()) Text(meta.authors.joinToString(", "), style = MaterialTheme.typography.titleSmall)
                if (meta.narrators.isNotEmpty()) Text("Lu par ${meta.narrators.joinToString(", ")}", style = MaterialTheme.typography.bodySmall)
                Text(
                    buildString {
                        append("Source : Audible.${meta.market}")
                        if (meta.releaseYear > 0) append(" · ${meta.releaseYear}")
                        if (meta.runtimeMin > 0) append(" · ${meta.runtimeMin / 60} h ${meta.runtimeMin % 60}")
                        if (meta.rating > 0) append(" · note %.1f/5".format(meta.rating))
                        meta.publisher?.let { append(" · $it") }
                        meta.seriesName?.let { append(" · $it") }
                    },
                    style = MaterialTheme.typography.bodySmall,
                )
                meta.summary?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, style = MaterialTheme.typography.bodyMedium)
                }
            }
        },
        confirmButton = {
            Row {
                TextButton(onClick = onOther) { Text("Autre édition") }
                TextButton(onClick = onRemove) { Text("Retirer") }
                TextButton(onClick = onDismiss) { Text("Fermer") }
            }
        },
    )
}
'''
    LS.write_text(s)
    print("dialogs appended")

# ---------------- PlayerScreen ----------------
add_imports(PS, ["dev.bookwave.app.data.metadata.MetadataStore"])
rep(PS, """private suspend fun resolveBook(context: Context, bookId: String): ResolvedBook {
    val settings = AppSettings(context)
    var coverUrl: String? = null""",
"""private suspend fun resolveBook(context: Context, bookId: String): ResolvedBook {
    val settings = AppSettings(context)
    // Official Audible cover wins over the folder scan (tracker banners…).
    val meta = MetadataStore(context).of(bookId)
    var coverUrl: String? = meta?.coverUrl""")
rep(PS, """            val children = source.list(path)
            coverUrl = children.firstOrNull { it.mediaKind == MediaKind.COVER }
                ?.let { runCatching { source.streamUrl(it.path) }.getOrNull() }""",
"""            val children = source.list(path)
            coverUrl = meta?.coverUrl ?: children.firstOrNull { it.mediaKind == MediaKind.COVER }
                ?.let { runCatching { source.streamUrl(it.path) }.getOrNull() }""")

# ---------------- SettingsScreen button ----------------
rep(SS, """                    Text(
                        "Appliqué seul en cas de confiance élevée ; sinon choix parmi les éditions. " +
                            "Appui long sur un livre : fiche, autre édition, retrait.",
                        style = MaterialTheme.typography.bodySmall,
                    )""",
"""                    Text(
                        "Appliqué seul en cas de confiance élevée ; sinon choix parmi les éditions. " +
                            "Appui long sur un livre : fiche, autre édition, retrait.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Button(
                        onClick = {
                            dev.bookwave.app.data.metadata.MetadataStore(context).clearTried()
                            settings.enrichPassRequested = true
                            testResult = "Registre effacé : rouvrez la bibliothèque pour relancer l'identification."
                        },
                    ) { Text("Relancer l'identification maintenant") }""")

print("WIRING APPLIED")
