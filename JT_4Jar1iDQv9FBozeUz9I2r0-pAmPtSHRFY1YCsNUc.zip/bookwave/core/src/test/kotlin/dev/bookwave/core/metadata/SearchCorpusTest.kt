package dev.bookwave.core.metadata

import dev.bookwave.core.library.TitleCleaner
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

/**
 * v0.7.4 — the "solution générale" corpus.
 *
 * Every case below is a real folder name that returned "aucune édition
 * trouvée" in the field. They are grouped here so the parsing/scoring rules
 * that fixed them cannot silently regress.
 */
class SearchCorpusTest {

    private fun clean(raw: String) = TitleCleaner.clean(raw)

    // ---------------- parsing ----------------

    @Test
    fun `author in front and volume in the middle of a long name`() {
        val c = clean("Brandon Sanderson Les Archives de Roshar 05 Vent et verite 2")
        assertEquals("Brandon Sanderson", c.author)
        assertEquals("Les Archives de Roshar", c.series)
        assertEquals(5.0, c.seriesIndex)
        assertTrue(c.title.contains("Vent et verite"), "got ${c.title}")
        assertTrue("Brandon" !in c.title, "author leaked: ${c.title}")
    }

    @Test
    fun `one word author before a volume is split`() {
        val c = clean("Chugong - Solo Leveling 3")
        assertEquals("Chugong", c.author)
        assertEquals("Solo Leveling", c.series)
        assertEquals(3.0, c.seriesIndex)
    }

    @Test
    fun `one word author before a determiner opens the saga`() {
        val c = clean("Tolkien - Le Seigneur des Anneaux 1 La Communaute de l Anneau")
        assertEquals("Tolkien", c.author)
        assertEquals("Le Seigneur des Anneaux", c.series)
        assertEquals(1.0, c.seriesIndex)
    }

    @Test
    fun `an author followed by a bare year keeps the year as the title`() {
        val c = clean("George Orwell - 1984")
        assertEquals("George Orwell", c.author)
        assertEquals("1984", c.title)
    }

    @Test
    fun `a short title after an author is not swallowed`() {
        val c = clean("Victor Hugo - Les Miserables")
        assertEquals("Victor Hugo", c.author)
        assertEquals("Les Miserables", c.title)
    }

    @Test
    fun `a volume marker is never mistaken for a title`() {
        val c = clean("Harry Potter - Tome 1")
        assertEquals(null, c.author)
        assertEquals(1.0, c.seriesIndex)
    }

    // ---------------- query plan ----------------

    @Test
    fun `the plan sends segments never the whole folder name`() {
        val c = clean("Brandon Sanderson Les Archives de Roshar 05 Vent et verite 2")
        val plan = AudibleQueries.plan(c.title, c.series, c.seriesIndex, "Sanderson")
        val texts = plan.map { it.text }
        assertEquals("Les Archives de Roshar 5", plan.first().text)
        assertTrue("Vent et verite 2" in texts, "got $texts")
        assertTrue("Vent et verite" in texts, "subtitle without its part number: $texts")
        assertTrue(
            plan.none { q -> q.text.split(' ').size > 8 },
            "no query may exceed 8 tokens: $texts",
        )
        assertTrue(
            plan.filter { it.mode == AudibleQueries.Mode.KEYWORDS }.all { it.text.split(' ').size <= 6 },
            "keyword queries are AND-ed, they must stay short: $texts",
        )
    }

    @Test
    fun `a long title keeps its ending when clipped`() {
        val plan = AudibleQueries.plan("un deux trois quatre cinq six sept huit neuf dix onze")
        val titles = plan.filter { it.mode == AudibleQueries.Mode.TITLE }.map { it.text }
        assertTrue(titles.all { it.split(' ').size <= 8 }, "got $titles")
        assertEquals("huit neuf dix onze", titles.first())
    }

    @Test
    fun `a trailing part number is stripped for one of the queries`() {
        assertEquals("Vent et verite", AudibleQueries.withoutTrailingPart("Vent et verite 2"))
        assertEquals(null, AudibleQueries.withoutTrailingPart("Dune"))
        // A three-word title still yields a useful shorter query.
        assertEquals("Solo Leveling", AudibleQueries.withoutTrailingPart("Solo Leveling 3"))
    }

    // ---------------- scoring ----------------

    private fun candidate(
        asin: String,
        title: String,
        authors: List<String>,
        series: List<Pair<String, Double?>> = emptyList(),
        subtitle: String? = null,
        language: String = "french",
    ) = BookMetadata(
        asin = asin,
        market = "fr",
        title = title,
        subtitle = subtitle,
        authors = authors,
        narrators = listOf("Narrateur"),
        seriesName = series.firstOrNull()?.first,
        seriesIndex = series.firstOrNull()?.second,
        seriesEntries = series.map { SeriesRef(it.first, it.second) },
        runtimeMin = 600,
        language = language,
    )

    @Test
    fun `the official title inside a messy folder name is a match`() {
        val input = MetadataMatcher.MatchInput(
            title = "Les Archives de Roshar 5 - Vent et verite 2",
            author = "Brandon Sanderson",
            series = "Les Archives de Roshar",
            seriesIndex = 5.0,
            language = "french",
        )
        val cand = candidate(
            "B0GZ3V824M", "Vent et vérité - Volume 2", listOf("Brandon Sanderson"),
            listOf("Les Archives de Roshar" to 5.0),
        )
        assertTrue(MetadataMatcher.score(input, cand) >= MetadataMatcher.AUTO_THRESHOLD)
    }

    @Test
    fun `an author written in front of the title is not a title word`() {
        val raw = MetadataMatcher.MatchInput(title = "Brandon Sanderson L Ensoleille", language = "french")
        val cand = candidate("B0D63GMF39", "L'Ensoleillé", listOf("Brandon Sanderson"))
        assertTrue(MetadataMatcher.score(raw, cand) >= MetadataMatcher.AUTO_THRESHOLD)
    }

    @Test
    fun `a subtitle that repeats the saga is ignored`() {
        val input = MetadataMatcher.MatchInput(title = "Le Nom du Vent", author = "Patrick Rothfuss")
        val cand = candidate(
            "2374343022", "Le Nom du Vent 1", listOf("Patrick Rothfuss"),
            listOf("Chronique du Tueur de Roi" to 1.1),
            subtitle = "Chronique du Tueur de Roi",
        )
        assertTrue(MetadataMatcher.score(input, cand) >= MetadataMatcher.AUTO_THRESHOLD)
    }

    @Test
    fun `a subtitle that is only a volume label is ignored`() {
        val input = MetadataMatcher.MatchInput(title = "Le Dernier Voeu", author = "Andrzej Sapkowski")
        val cand = candidate(
            "B0FT86M3CC", "Le Dernier voeu", listOf("Andrzej Sapkowski"),
            listOf("The Witcher - Le Sorceleur" to 1.0),
            subtitle = "The Witcher, Tome 1",
        )
        assertTrue(MetadataMatcher.score(input, cand) >= MetadataMatcher.AUTO_THRESHOLD)
    }

    @Test
    fun `french ligatures do not break the comparison`() {
        assertEquals(MetadataMatcher.tokens("voeu"), MetadataMatcher.tokens("vœu"))
        assertEquals(MetadataMatcher.tokens("soeur"), MetadataMatcher.tokens("sœur"))
    }

    @Test
    fun `a different part of the same book is rejected`() {
        val input = MetadataMatcher.MatchInput(
            title = "Dune 1", author = "Frank Herbert", series = "Dune", seriesIndex = 1.0,
        )
        val third = candidate("B07R6TPKCG", "Dune - Livre troisième", listOf("Frank Herbert"), listOf("Dune" to 1.2))
        val complete = candidate("B07Q44JYLF", "Dune - Livre premier et livre second", listOf("Frank Herbert"), listOf("Dune" to 1.1))
        assertTrue(
            MetadataMatcher.score(input, third) < MetadataMatcher.score(input, complete),
            "the third part must rank below the complete edition",
        )
        assertTrue(MetadataMatcher.score(input, complete) >= MetadataMatcher.AUTO_THRESHOLD)
    }

    @Test
    fun `a number inside a title is not a part number`() {
        val input = MetadataMatcher.MatchInput(
            title = "Autre Monde 1", author = "Maxime Chattam", series = "Autre Monde", seriesIndex = 1.0,
        )
        // "L'alliance des trois": "trois" is in the title, not a part marker.
        val cand = candidate("B00DUU7C9E", "L'alliance des trois", listOf("Maxime Chattam"), listOf("Autre-Monde" to 1.0))
        assertTrue(MetadataMatcher.score(input, cand) >= MetadataMatcher.AUTO_THRESHOLD)
    }

    @Test
    fun `a split volume shares the identity of the whole book`() {
        val input = MetadataMatcher.MatchInput(
            title = "La Peur du Sage 2", author = "Patrick Rothfuss", series = "La Peur du Sage", seriesIndex = 2.0,
        )
        val part2 = candidate("2374342891", "La Peur du Sage - Seconde partie", listOf("Patrick Rothfuss"), listOf("Chronique du Tueur de Roi" to 2.2))
        val part1 = candidate("2374342859", "La Peur du Sage - Première partie", listOf("Patrick Rothfuss"), listOf("Chronique du Tueur de Roi" to 2.1))
        assertTrue(MetadataMatcher.score(input, part2) > MetadataMatcher.score(input, part1))
    }
}
