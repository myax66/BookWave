package dev.bookwave.core.metadata

/**
 * One series the album belongs to, as Audible lists it.
 *
 * Audible frequently returns SEVERAL series for a single title ("Harry Potter"
 * and "Le Monde des sorciers", "(French Edition)" suffixed variants…), in no
 * stable order. Keeping them all is what lets the matcher recognise a volume
 * whichever naming the uploader used.
 */
data class SeriesRef(
    val name: String,
    val index: Double? = null,
)

/**
 * Official book metadata resolved from an audiobook database (Audible
 * catalogue today). Cached on disk by the app and merged over the
 * torrent-name-derived fields: real title, author, narrator, runtime, cover.
 */
data class BookMetadata(
    val asin: String,
    val market: String = "fr",
    val title: String,
    val subtitle: String? = null,
    val authors: List<String> = emptyList(),
    val narrators: List<String> = emptyList(),
    val seriesName: String? = null,
    val seriesIndex: Double? = null,
    val seriesEntries: List<SeriesRef> = emptyList(),
    val runtimeMin: Int = 0,
    val publisher: String? = null,
    val releaseYear: Int = 0,
    val summary: String? = null,
    val coverUrl: String? = null,
    val rating: Double = 0.0,
    val language: String? = null,
    val savedAt: Long = 0L,
) {

    /**
     * Every series pair known for this edition, primary first. Falls back to
     * the legacy [seriesName]/[seriesIndex] pair when the API only gave one.
     */
    fun allSeries(): List<SeriesRef> {
        if (seriesEntries.isNotEmpty()) return seriesEntries
        val name = seriesName?.takeIf { it.isNotBlank() } ?: return emptyList()
        return listOf(SeriesRef(name, seriesIndex))
    }

    /** Human label of the primary series ("Harry Potter · tome 3"). */
    val seriesLabel: String?
        get() {
            val primary = allSeries().firstOrNull() ?: return null
            return if (primary.index != null && primary.index % 1.0 == 0.0) {
                "${primary.name} · tome ${primary.index.toInt()}"
            } else {
                primary.name
            }
        }

    /** True when no author, narrator nor runtime: an ebook stub, not an audiobook. */
    val looksLikeAudiobook: Boolean
        get() = authors.isNotEmpty() || narrators.isNotEmpty() || runtimeMin > 0
}
