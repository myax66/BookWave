package dev.bookwave.core.util

import kotlin.test.Test
import kotlin.test.assertEquals

class NaturalOrderTest {

    @Test
    fun `numeric tracks sort by value not lexicographically`() {
        val files = listOf("10 - Final.mp3", "2 - Milieu.mp3", "1 - Début.mp3")
        assertEquals(
            listOf("1 - Début.mp3", "2 - Milieu.mp3", "10 - Final.mp3"),
            files.sortedWith(NaturalOrder),
        )
    }

    @Test
    fun `mixed padded and unpadded numbers stay in order`() {
        val files = listOf("track12.mp3", "track9.mp3", "track100.mp3", "track01.mp3")
        assertEquals(
            listOf("track01.mp3", "track9.mp3", "track12.mp3", "track100.mp3"),
            files.sortedWith(NaturalOrder),
        )
    }

    @Test
    fun `alphabetic names fall back to case insensitive order`() {
        val files = listOf("beta", "Alpha", "gamma")
        assertEquals(listOf("Alpha", "beta", "gamma"), files.sortedWith(NaturalOrder))
    }

    @Test
    fun `chapter titles with numbers keep reading order`() {
        val files = listOf("Chapitre 20.ogg", "Chapitre 3.ogg", "Chapitre 100.ogg")
        assertEquals(
            listOf("Chapitre 3.ogg", "Chapitre 20.ogg", "Chapitre 100.ogg"),
            files.sortedWith(NaturalOrder),
        )
    }
}
