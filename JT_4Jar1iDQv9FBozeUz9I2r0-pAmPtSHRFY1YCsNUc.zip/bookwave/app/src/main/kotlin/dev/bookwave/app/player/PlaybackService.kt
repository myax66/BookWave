package dev.bookwave.app.player

import android.content.Intent
import android.util.Base64
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import dev.bookwave.app.data.AppSettings
import dev.bookwave.core.model.ListeningProgress
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Audio playback foreground service, audiobook-tuned:
 *
 *  - [C.CONTENT_TYPE_SPEECH] audio attributes (better volume shaping on some devices)
 *  - silence skipping DISABLED: reading pauses are part of the narration and must
 *    be heard at their real length
 *  - [C.WAKE_MODE_NETWORK]: the books stream from a remote WebDAV — the local
 *    wake mode let Wi-Fi/CPU doze mid-sentence, cutting background playback
 *  - progress is saved HERE (every 10 s while playing, on pause, on stop, on
 *    error, on task removal): background listening survives the process death
 *    that used to wipe everything saved since the player screen was closed
 *  - fatal stream errors clear the mini-bar and stop the service instead of
 *    leaving a phantom "now playing" that can never resume
 *
 * The service is NOT exported (see manifest): only MediaSessionService glue
 * talks to it, plus the in-app controller.
 */
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private val settings: AppSettings by lazy { AppSettings(this) }

    /** Loop scope for the periodic save; cancelled in onDestroy. */
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var saveJob: Job? = null

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) startPeriodicSave() else {
                stopPeriodicSave()
                saveNow()
            }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_IDLE || playbackState == Player.STATE_ENDED) saveNow()
        }

        override fun onPlayerError(error: PlaybackException) {
            // Persist where the listener got to, drop the phantom now-playing,
            // and let the service die — the next open rebuilds it with the
            // current settings (and the player screen shows the real error).
            saveNow()
            PlaybackBus.nowPlaying.value = null
            stopSelf()
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        // Authenticated streaming: every media item of the current account is
        // fetched with the WebDAV Basic credentials (files answer 401 without).
        // NOTE: read ONCE here — when the user edits their credentials,
        // [handleCredentialsChanged] stops the service so it rebuilds fresh.
        val httpFactory = DefaultHttpDataSource.Factory()
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(60_000)
            .apply {
                if (settings.webdavUser.isNotBlank()) {
                    setDefaultRequestProperties(
                        mapOf(
                            "Authorization" to "Basic " + Base64.encodeToString(
                                "${settings.webdavUser}:${settings.webdavPassword}".toByteArray(),
                                Base64.NO_WRAP,
                            ),
                        ),
                    )
                }
            }
        val mediaSourceFactory = DefaultMediaSourceFactory(this)
            .setDataSourceFactory(DefaultDataSource.Factory(this, httpFactory))

        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(mediaSourceFactory)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.CONTENT_TYPE_SPEECH)
                    .build(),
                /* handleAudioFocus = */ true,
            )
            // Normal playback. Media3's SilenceSkippingAudioProcessor replaces any
            // quiet run with 10 ms of padding; audiobook recordings sit low enough
            // that it swallows the pauses between sentences and the book races
            // ahead. Deliberately off (it is also the Media3 default).
            .setSkipSilenceEnabled(false)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
        player.addListener(listener)

        mediaSession = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? =
        mediaSession

    override fun onTaskRemoved(rootIntent: Intent?) {
        saveNow()
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        // Best-effort final save on a scope that OUTLIVES this service (its own
        // scopes are dead by the time onDestroy runs).
        currentEntry()?.let { entry ->
            appScope.launch { ProgressSaver.save(applicationContext, entry) }
        }
        saveJob?.cancel()
        serviceScope.cancel()
        mediaSession?.run {
            player.removeListener(listener)
            player.release()
            release()
        }
        mediaSession = null
        instance = null
        super.onDestroy()
    }

    // ---- background progress persistence -----------------------------------

    private fun startPeriodicSave() {
        if (saveJob?.isActive == true) return
        saveJob = serviceScope.launch {
            while (true) {
                delay(SAVE_INTERVAL_MS)
                saveNow()
            }
        }
    }

    private fun stopPeriodicSave() {
        saveJob?.cancel()
        saveJob = null
    }

    private fun saveNow() {
        val entry = currentEntry() ?: return
        appScope.launch { ProgressSaver.save(applicationContext, entry) }
    }

    /** Player position → progress record, or null when nothing identifiable plays. */
    private fun currentEntry(): ListeningProgress? {
        val player = mediaSession?.player ?: return null
        val np = PlaybackBus.nowPlaying.value ?: return null
        return ProgressSaver.snapshot(
            bookId = np.bookId,
            chapterCount = np.chapterCount,
            chapterIndex = player.currentMediaItemIndex,
            positionInChapterMs = player.currentPosition.coerceAtLeast(0L),
            chapterDurationMs = player.duration,
            speed = player.playbackParameters.speed,
            deviceId = settings.deviceId,
        )
    }

    companion object {
        private const val SAVE_INTERVAL_MS = 10_000L

        /** Survives service destruction for the final progress write. */
        private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        @Volatile
        private var instance: PlaybackService? = null

        /**
         * WebDAV credentials changed: a running service streams with the OLD
         * ones (its data source is built in onCreate and never refreshed —
         * requests then fail with silent 401s). Save the position, clear the
         * mini-bar and stop; the next playback recreates the service and reads
         * the new settings.
         */
        fun handleCredentialsChanged() {
            val svc = instance ?: return
            val player = svc.mediaSession?.player ?: return
            svc.saveNow()
            if (player.isPlaying) player.pause()
            PlaybackBus.nowPlaying.value = null
            svc.stopSelf()
        }
    }
}

/** Small helper so UI code can apply audiobook speed presets uniformly. */
fun Player.applySpeed(speed: Float) {
    setPlaybackSpeed(speed)
}
