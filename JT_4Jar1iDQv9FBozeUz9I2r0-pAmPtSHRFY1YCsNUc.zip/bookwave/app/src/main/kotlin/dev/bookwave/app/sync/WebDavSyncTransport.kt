package dev.bookwave.app.sync

import android.content.Context
import android.util.Base64
import dev.bookwave.app.data.AppSettings
import dev.bookwave.app.util.Http
import dev.bookwave.app.util.await
import dev.bookwave.core.sync.SyncPayload
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

/**
 * Sync transport that stores a single JSON file next to the library on the
 * user's WebDAV/Nextcloud account — no backend required.
 *
 * Remote wins nothing by itself: [SyncEngine] merges both sides, and this
 * transport only carries bytes. Concurrent writers are fine (last upload wins
 * at the byte level) because every payload contains full state.
 *
 * Failure policy (data safety): a DOWNLOAD that cannot be distinguished from
 * "no remote state yet" would let the merge erase the other device's progress,
 * so anything but a clean 404 THROWS; uploads verify the HTTP status instead of
 * silently dropping the payload.
 */
class WebDavSyncTransport(context: Context) : SyncTransport {

    private val settings = AppSettings(context)
    private val http = Http.shared

    private val fileUrl: String
        get() = settings.webdavUrl.trimEnd('/') + "/.bookwave-progress.json"

    private val authHeader: String
        get() = "Basic " + Base64.encodeToString(
            "${settings.webdavUser}:${settings.webdavPassword}".toByteArray(),
            Base64.NO_WRAP,
        )

    override suspend fun download(): SyncPayload {
        val request = Request.Builder()
            .url(fileUrl)
            .header("Authorization", authHeader)
            .get()
            .build()
        http.newCall(request).await().use { response ->
            // 404 = the sidecar does not exist yet: a genuinely empty remote.
            if (response.code == 404) return SyncPayload("none", 0, emptyList())
            if (!response.isSuccessful) {
                throw IOException("Téléchargement de la sync refusé (HTTP ${response.code})")
            }
            val body = response.body?.string()
                ?: throw IOException("Réponse vide du serveur de sync")
            return runCatching { SyncCodec.decode(body) }
                .getOrElse { throw IOException("Fichier de sync illisible") }
        }
    }

    override suspend fun upload(payload: SyncPayload) {
        val body = SyncCodec.encode(payload).toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url(fileUrl)
            .header("Authorization", authHeader)
            .put(body)
            .build()
        http.newCall(request).await().use { response ->
            if (!response.isSuccessful) {
                throw IOException("Envoi de la sync refusé (HTTP ${response.code})")
            }
        }
    }
}
