# Audit — recherche Audible de Bookwave

**Version auditée :** v0.6.4 (versionCode 25) → **version livrée :** v0.7.0 (versionCode 26)
**Date :** 22 octobre 2026
**Périmètre :** tout le pipeline de métadonnées — `AudibleCatalog`, `MetadataEnricher`,
`MetadataStore`, `MetadataMatcher`, l'UI d'enrichissement de `LibraryScreen` — plus
les interactions avec `CoverCache` (pochettes Audible) et les Réglages.
**Méthode :** lecture intégrale des 6 fichiers concernés, **interrogation directe de
`api.audible.fr` / `api.audible.com`** (≈ 40 requêtes, 22/10/2026), portage Python des
deux moteurs de scoring pour mesurer avant/après sur la même API, puis compilation et
tests réels (`:core:test` **67 verts**, `:app:assembleDebug` **OK**, APK vc26 signé
`ba7966a8…`).

---

## 1. Ce que faisait la recherche en v0.6.4

`MetadataEnricher.enrich()` construisait jusqu'à **7 variantes de requête** (saga,
titre nettoyé, titre sans article, titre sans tome, titre brut, prénom+nom…), les
essayait **dans l'ordre**, marché par marché (`fr` puis `com`), et **s'arrêtait à la
première requête qui renvoyait au moins un produit**. Les produits étaient ensuite
scorés par `MetadataMatcher` (titre 0,50 · auteur 0,20 · série+tome 0,15 · durée 0,15)
puis appliqués au-delà de 0,75.

## 2. Défauts constatés

### 🔴 A1 — `author` est un filtre **strict** : une mauvaise déduction met la recherche à zéro
`AudibleCatalog.search()` transmettait `author=cleaned.author` **à chaque requête**.
Mesuré sur l'API :

| Requête | total_results |
|---|---|
| `keywords=harry potter ecole des sorciers` | **16** |
| idem + `&author=J.K. Rowling` | 15 |
| idem + `&author=Tolkien` | **0** |

Un nom d'auteur mal extrait du nom de torrent (traducteur, prénom seul, coquille)
suffisait donc à rendre **toutes** les requêtes muettes. C'est exactement le symptôme
« aucun livre n'est trouvé » qui avait déjà valu deux correctifs en v0.6.1/0.6.2.

### 🔴 A2 — « premier résultat non vide » : un produit parasite masque la bonne édition
La boucle `break` sur le premier marché/requête non vide. Or Audible renvoie des
produits hétérogènes dans un ordre de pertinence instable. Mesuré :
`title=solo leveling 1` renvoie l'édition française, **l'édition anglaise** et un
« Introduction to Ebook Summary Solo Leveling » (sans auteur, runtime 0). Selon la
requête qui tombe en premier, le pool mélange ou non les bonnes éditions — et le
classement final ne voit que le premier lot.

### 🔴 A3 — Une seule série exploitée, alors qu'Audible en renvoie plusieurs
`seriesName = p.optJSONArray("series").optJSONObject(0)` : **le premier élément
uniquement**. Mesuré sur Harry Potter : le tome 1 renvoie
`[("Harry Potter", 1), ("Le Monde des sorciers", 1)]` et le tome 4 l'ordre **inverse**
`[("Le Monde des sorciers", 4), ("Harry Potter", 4)]`. Selon le livre, le scoring
comparait donc la série détectée à la mauvaise entrée, cassant le « plancher
série+tome » (0,85) prévu précisément pour les sagas.

### 🟠 A4 — Les noms de sagas suffixés par Audible cassent le plancher série
`solo leveling` → série Audible **« Solo Leveling (French Edition) »**. Dice
« solo leveling » vs « solo leveling french edition » = 0,67 < 0,75 : le plancher
n'était jamais atteint. Mesuré : score **0,665 → suggestion au lieu d'application**
(v0.7.0 : **0,850, appliqué**).

### 🟠 A5 — Le paramètre `title=` n'était jamais utilisé
Audible expose deux modes de recherche très différents, mesuré le 22/10 :

| Requête | Résultat |
|---|---|
| `title=harry potter ecole des sorciers` | **1** produit, le bon |
| `keywords=harry potter ecole des sorciers` | 16 produits (le bon en tête) |
| `title=harry potter 1 a l ecole des sorciers` | **0** (titre trop long) |

`title=` est un matcher de **phrase courte** : excellent pour « saga + tome », inutile
pour un nom de torrent complet. L'app n'exploitait que `keywords=`, perdant la
requête la plus précise.

### 🟠 A6 — Aucune notion de langue ; les stubs ebook sont retenus
Le repli `fr → com` peut ramener l'édition **anglaise** du même livre, qui gagnait
au score. Et les produits sans auteur/narrateur/durée (résumés ebook, goodies) étaient
scorés comme des livres audio.

### 🟠 A7 — Coût réseau : jusqu'à 14 requêtes par livre, sans cache
7 requêtes × 2 marchés, séquentielles, plus la pause de 800 ms entre livres. Aucune
mémoire : les tomes d'une même saga (dont le nom de saga est identique) rejouent
**les mêmes requêtes** à chaque passe.

### 🟠 A8 — Aucun recours manuel pour un faux négatif
En cas d'échec, l'app affichait « Aucune correspondance » puis rien : impossible de
taper soi-même « Dune » ou de coller un ASIN. Or c'est précisément le cas des livres
au nom de torrent exotique.

### 🟠 A9 — Sécurité : identifiants WebDAV envoyés à Amazon
`CoverCache.client()` ajoutait l'en-tête `Authorization: Basic …` **à toutes** les
requêtes d'image, sans contrôle d'hôte. Depuis l'arrivée des pochettes Audible
(v0.6.x), chaque `m.media-amazon.com/…jpg` recevait donc l'identifiant et le mot de
passe WebDAV de l'utilisateur.

### 🟡 A10 — Divers
Trace d'échec affichée brute (`fr «…» → 0, com …`) ; pas de recherche par ASIN ;
`num_results=8` un peu court quand 20 produits coûtent la même requête ; les
`response_groups` n'incluaient pas `product_extended_attrs`.

---

## 3. Correctifs livrés en v0.7.0

### `core/metadata/AudibleQueries.kt` (nouveau, pur, 10 tests)
Échelle de requêtes issue des mesures :
1. `TITLE` « saga + tome » (« harry potter 1 ») — l'identité ;
2. `TITLE` le sous-titre seul (« a l ecole des sorciers ») ;
3. `TITLE` le titre sans son numéro de tome ;
4. `KEYWORDS` le titre complet, puis sans le tome, puis sans article initial ;
5. `KEYWORDS` la saga seule ;
6. `KEYWORDS` nom + titre (auteur d'un seul mot).
Plus : `stripReleaseTags()` (tags `m4b-k`…), `removeVolume()`, `subtitleOf()`, et
`manual()` pour la saisie libre (dont l'ajout du tome connu quand l'utilisateur tape
la saga seule). Les `TITLE` sont tronqués à 8 mots (au-delà, l'API renvoie 0).

### `core/metadata/MetadataMatcher.kt` (v5, +6 tests)
- score de titre = **0,6 × couverture + 0,4 × Dice** : les sous-titres officiels
  n'écrasent plus un titre court de torrent ;
- le **numéro de tome en fin de titre est ignoré** quand l'index de série est connu ;
- comparaison de **toutes** les séries Audible (`seriesEntries`) ;
- `normalizeSeries()` retire « (French Edition) », « Series », « Série »… ;
- initiales compactes (« J.K. Rowling » ≡ « JK Rowling ») ;
- **pénalité ×0,80** quand la langue de l'édition diffère de la langue préférée
  (une édition anglaise ne remplace plus l'originale française).

### `app/data/metadata/AudibleCatalog.kt`
- les deux modes (`title` / `keywords`) + `num_results=20` + `product_extended_attrs` ;
- `language` et **toutes** les séries sont parsées (`seriesEntries`) ;
- les **stubs ebook** (ni auteur, ni narrateur, ni durée) sont écartés ;
- **cache LRU mémoire** (96 entrées, clé marché+mode+requête+auteur) : les tomes
  d'une saga ne repayent plus la même requête ;
- `byAsin()` pour les recherches par identifiant.

### `app/data/metadata/MetadataEnricher.kt` (MATCHING_VERSION = 5)
- **pool** de candidats sur toute l'échelle (plus de « premier non vide gagne ») ;
- **retry sans `author`** dès qu'une requête renvoie 0 (corrige A1) ;
- **sortie anticipée** dès qu'un candidat dépasse 0,75 → 1 à 2 requêtes par livre en
  moyenne au lieu de 14 ;
- filtre de langue (`preferLanguage`) avant classement ;
- plafond dur de 5 requêtes par marché (retries compris) ;
- distinction propre erreur réseau / vraie absence (le registre anti-redite n'est
  jamais pollué par un échec réseau) ;
- `search()` : moteur manuel (mêmes requêtes, sans seuil ni registre, ASIN direct).

### `app/data/metadata/MetadataStore.kt`
Sérialisation de `language` et `seriesEntries` ; les caches existants restent lisibles
(champs optionnels).

### `app/ui/library/LibraryScreen.kt`
- nouvelle feuille **« Rechercher sur Audible »** : champ titre/saga/ASIN + auteur,
  résultats classés (auteur, narrateur, année, durée, saga, langue, marché, confiance),
  un tap applique l'édition ;
- accessible depuis le message d'échec (« Chercher sur Audible »), depuis la fiche
  (« Rechercher ») et via le pavé d'enrichissement ;
- rapport de passe : `v0.7.0 · Enrichissement Audible : …`.

### `app/ui/common/CoverImage.kt`
- l'en-tête `Authorization` n'est plus ajouté que si **l'hôte de la requête est celui
  du WebDAV configuré** (corrige A9).

### Versions
`versionCode 26`, `versionName "0.7.0"`, réglages : « Bookwave v0.7.0 (vc26) · moteur
de métadonnées v5 ». Le passage à v5 **purge le registre des échecs** : tous les livres
« introuvables » sont réévalués à la première ouverture.

---

## 4. Mesure avant / après (même API, même jour)

Harnais `measure_search.py` : portage Python fidèle des deux moteurs, 5 livres types
issus du nettoyeur de titres, `api.audible.fr`.

| Livre (après nettoyage) | v0.6.4 | v0.7.0 | Requêtes v4 → v5 |
|---|---|---|---|
| Harry Potter 1 - A l'ecole des sorciers | 0,850 auto ✅ | 0,878 auto ✅ | 1 → 1 |
| Chugong - Solo Leveling 3 | **0,665 suggestion ❌** | **0,850 auto ✅** | 1 → 1 |
| L'Ensorceleuse (absent du catalogue) | 0,378 rien | 0,496 rien | 1 → 2 |
| Elantris 1 - Chute | 1,000 auto ✅ | 1,000 auto ✅ | 1 → 1 |
| Le Sang des 7 Rois 1 | 0,850 auto ✅ | 0,867 auto ✅ | 1 → 2 |

Lecture : la régression nulle sur les cas déjà bons, **un faux négatif corrigé**
(Solo Leveling, cas « (French Edition) »), et le meilleur score partout ailleurs.
Budget réseau : identique ou meilleur sur ces cas ; sur une bibliothèque réelle
(beaucoup de sagas), le cache et la sortie anticipée suppriment la majorité des
requêtes répétées.

Faits API mesurés qui fondent les choix (22/10/2026) :
- `author=` est un **ET strict** (0 résultat avec Tolkien sur une requête Harry Potter) ;
- `title=` renvoie 1 produit quand `keywords=` en renvoie 16, mais 0 dès que le titre
  dépasse ~10 mots ou contient un numéro de tome dans le désordre ;
- un même livre expose **plusieurs séries** dans un ordre variable ;
- les ASIN sont **propres au marché** (`.fr` ≠ `.com`).

---

## 5. Tests & build

- `:core:test` → **67 tests, 0 échec** (54 existants + 10 `AudibleQueriesTest`
  + 6 nouveaux `MetadataMatcherTest` : séries multiples, suffixe « (French Edition) »,
  pénalité de langue, sous-titre, initiales, numéro de tome).
- `:app:assembleDebug` → **BUILD SUCCESSFUL**, APK 23,8 Mo, `versionCode 26`,
  signature **inchangée** (`CN=Bookwave Debug`, SHA-256 `ba7966a8…`).

## 6. Assumé / non fait

- `AudibleCatalog.clearCache()` n'est pas encore branché sur un bouton des Réglages
  (le cache est borné et se vide avec le processus).
- Pas de pagination au-delà de 20 produits (le classement local suffit sur les cas
  mesurés ; à revoir si une recherche manuelle très large devient nécessaire).
- La recherche manuelle ne propose pas encore la pochette dans la liste (texte seul).
- Toujours en attente de la feuille de route : chapitres réels Audnexus, probing des
  durées, téléchargements hors-ligne, chapitres m4b.

## 7. Risques

- API Audible non documentée : les parseurs restent défensifs (`optXxx`, aucun champ
  obligatoire sauf `asin`), les erreurs réseau ne sont jamais enregistrées comme des
  absences.
- `title=` peut changer de tolérance ; l'échelle garde deux `KEYWORDS` de repli, donc
  une casse de `title=` dégrade la précision sans rendre la recherche muette.
- La pénalité de langue s'appuie sur le champ `language` : absent, elle est neutre.

---

# v0.7.1 (versionCode 27) — correctif du terrain

Retour d'écran du 22/10 : **« Recherche Audible impossible : Syntax error in regexp
pattern near index 8 — \{[^}]*} »** sur chaque appui long, et titres affichés
« Brandon Sanderson / L Ensoleille M4B-K… ».

## 1. Cause du crash : JVM ≠ ICU

`MetadataMatcher.normalizeSeries()` utilisait `.replace(Regex("\\{[^}]*}"), " ")`.
OpenJDK accepte un `}` non échappé ; **ICU, le moteur de `android.util.regex`,
le refuse** (`U_REGEX_RULE_SYNTAX`). L'exception partait au premier `rank()`, donc
**chaque** recherche Audible échouait, quel que soit le livre — y compris la fiche
et « Autre édition ». Les 67 tests étaient verts car ils tournent sur la JVM.

- Correctif : `Regex("\\{[^}]*\\}")` (et `\\[[^\\]]*\\]` par prudence).
- **Outillage** : `tools/check-regex-icu.sh` compile les 45 motifs du projet avec
  la vraie bibliothèque ICU (gcc + libicu-dev) et échoue si l'un est invalide.
  Résultat : **45 motifs, 0 invalide**. À lancer avant chaque livraison.

## 2. Titres affichés : `M4B-K` restait visible

`JUNK_TOKENS` ne connaît que des tokens entiers ; `M4B-K` est un seul token
hyphéné. Nouveau `isReleaseTag()` : un token `xxx-yyy` est du bruit s'il contient
un chiffre (`m4b-k`, `mp3-320`) ou s'il est en capitales (`WEB-DL`) — « science-
fiction » et « va-t'en » survivent. 2 tests.

## 3. « Auteur - Titre » sans numéro de tome : le vrai frein de matching

Dossier `Brandon Sanderson - L Ensoleille M4B-K` → le nettoyeur ne détecte ni
auteur ni saga (son motif exige un numéro de tome), donc le nom de l'auteur reste
**dans le titre**. Le score plafonnait à **0,41** (« brandon sanderson l
ensoleille » vs « l ensoleille ») : sous tous les seuils, jamais appliqué.

- `TitleCleaner.authorPrefix()` : découpe « Prénom Nom - Titre » (nom = 2-3 mots
  capitalisés, pas de mot-outil) — **pour la recherche uniquement**, le titre
  affiché n'est jamais réécrit (sinon « Harry Potter » deviendrait un auteur).
- `TitleCleaner.stripAuthorPrefix()` : retire un préfixe auteur connu d'un titre
  ou d'une clé de saga (`Brandon Sanderson - Les Archives de Roshar` →
  `Les Archives de Roshar`).
- **Ordre des requêtes** : quand un préfixe auteur a été découpé, le nom de
  dossier complet part **en premier** en `keywords` — mesuré :
  `keywords=l ensoleille` → **0 résultat**, `keywords=brandon sanderson
  l ensoleille` → **1 résultat** (le bon).
- Correctif connexe : l'heuristique « après le premier tiret = saga » ne se
  déclenche plus que si ce segment **finit par un numéro** (elle inventait une
  saga « L Ensoleille »).

## 4. Vérification bout en bout sur les livres des captures

Pipeline complet (échelle de requêtes réelle + scoring v6), API live :

| Livre (dossier) | Résultat | Édition retenue |
|---|---|---|
| `Brandon Sanderson - L Ensoleille M4B-K` | **0,850 appliqué** (1 requête) | L'Ensoleillé — B0D63GMF39, `french` |
| `Brandon Sanderson - Les Archives de Roshar 2 - Le Livre des radieux` | **0,914 appliqué** (1 requête) | Le Livre des radieux — B0BYNWFWCF/B0C2PVLWDH, saga vol. 2 |
| `Chugong - Solo Leveling 3` | **0,850 appliqué** (1 requête) | Solo Leveling — B0H95GR62X, `french` (l'édition anglaise : 0,680) |

Les trois livres des captures remontent donc leur fiche au premier essai, en une
seule requête chacun.

## 5. Tests & build

- `:core:test` → **74 tests, 0 échec** (+7 : 3 `authorPrefix`, 2 `stripAuthorPrefix`,
  2 tags de release).
- `tools/check-regex-icu.sh` → 45 motifs, 0 invalide.
- `:app:assembleDebug` → OK, APK 23,8 Mo, **vc27**, signature `ba7966a8…` inchangée.
- `MATCHING_VERSION = 6` : le registre des échecs est purgé, donc les livres
  marqués « introuvables » par la v0.7.0 sont réévalués.

## 6. Assumé

- « Le Livre des radieux » existe en deux parties toutes deux numérotées vol. 2
  chez Audible : le score est identique (0,914) ; l'app retient la première, et
  « Autre édition » / « Rechercher » permet de trancher.
- Le découpage auteur ne s'applique qu'aux noms de 2-3 mots capitalisés : un
  auteur d'un seul mot (`Chugong - …`) reste dans le titre, ce qui n'empêche pas
  le matching (0,850 mesuré).


---

# v0.7.2 (versionCode 28) — « L'Âge de la Folie »

Retour d'écran : *Aucune correspondance Audible pour « L'Âge de la Folie 03 La
Sagesse des Foules - Joe Abercrombie »*, avec 6 requêtes longues toutes à 0.

## Ce que la mesure a montré

Le livre **existe** : `B0D7HWY631 — La Sagesses des foules, Joe Abercrombie,
saga « L'Âge de la folie » tome 3 (french)`. Deux formes de nommage échappaient
au nettoyeur :

| Dossier | Problème | Conséquence |
|---|---|---|
| `… - Joe Abercrombie` | l'auteur est **après** le titre | son nom restait dans toutes les requêtes |
| `L'Âge de la Folie 03 La Sagesse…` | le tome est **au milieu** | aucune détection de saga ni de tome → pas de requête « saga + tome » |

Les 6 requêtes générées étaient donc des `keywords` longs (8-10 tokens) que
l'API AND-ait jusqu'à zéro. Mesures : `title=la sagesse des foules` → **1**
résultat (le bon) ; requête longue du dossier → **0**.

## Correctifs

- `TitleCleaner.TRAILING_AUTHOR` : « Titre - Prénom Nom » → auteur séparé (refusé
  quand le segment commence par un article : « Harry Potter - Le Monde des
  sorciers » reste intact).
- `TitleCleaner.SERIES_EMBEDDED` : « Saga **03** Sous-titre » → saga + tome +
  sous-titre, avec garde-fous (tête ≥ 2 mots sans chiffre, queue ≥ 2 mots **sans
  chiffre** — sinon « Le Sang des 7 Rois 1 » se découpait sur son 7).
- `AudibleQueries` : quand aucune saga n'est détectée et que le titre est long,
  une requête `title=` sur les **4 derniers mots** est tentée en premier.
- Message d'échec reformulé (plus de trace technique à l'écran).

## Vérification (API live, pipeline complet)

| Livre | Score | Requêtes | Édition |
|---|---|---|---|
| L'Âge de la Folie 03 La Sagesse des Foules | **0,884 appliqué** | 2 | La Sagesse des foules (B0D7HWY631) |
| L'Ensoleillé (non-régression) | 0,850 | 1 | B0D63GMF39 |
| Les Archives de Roshar 2 (non-régression) | 0,914 | 1 | Le Livre des radieux |
| Solo Leveling 3 (non-régression) | 0,850 | 1 | B0H95GR62X |

Tests : **80 verts** (+4). ICU : 48 motifs, 0 invalide.

---

# v0.7.3 (versionCode 29) — « Brandon Sanderson L Ensoleille »

## Le symptôme

Capture du 22/10 9:37 : *« Aucune édition trouvée pour « Brandon Sanderson L
Ensoleille ». 2 requête(s) de titre et de mots-clés sur Audible.fr — sans
résultat. »* — alors que le livre existe (`B0D63GMF39`).

## Ce que l'API répond vraiment (mesuré)

| Requête | Résultat |
|---|---|
| `keywords=brandon sanderson l ensoleille` | **1** → `B0D63GMF39` |
| idem avec `author=Brandon Sanderson` | **1** |
| idem avec l'accent (`l ensoleillé`) | **1** |
| `keywords=brandon sanderson l ensoleille m4b k` | 0 (un tag de release tue tout) |
| `keywords=sanderson l ensoleille` | 0 (l'ordre des mots compte) |
| `keywords=l ensoleille` | 0 (l'élision seule ne matche pas) |
| `keywords=ensoleille` | 10 (dont le bon) |
| `title=…` (toutes variantes) | 0 |

L'API et le réseau ne sont donc pas en cause : la fiche revient avec
`language=french`, `runtime_length_min=909`, auteurs
`[Brandon Sanderson, Mélanie Fazi - traducteur]`, **aucune série**. Le filtre
`looksLikeAudiobook` la laisse passer. Ni le `User-Agent` de l'app ni
`Accept-Language` ne changent la réponse.

## La vraie cause : le nom était resté dans le titre

Le dossier s'appelle **« Brandon Sanderson L Ensoleille »**, sans tiret.
`authorPrefix()` exigeait `[-–—]` : aucun découpage, donc

- requête utile = `title=` + `keywords=` sur les **4 mots entiers** ;
- et surtout **score 0,533** contre « L'Ensoleillé » (couverture 2/4, Dice 2/6),
  soit la bande « suggestion »… ou rien du tout. Le titre et l'auteur étaient
  comptés deux fois dans une seule chaîne.

La sonde JVM l'a confirmé avant correction :

```
RAW=« Brandon Sanderson L Ensoleille »
   cleaned=« Brandon Sanderson L Ensoleille » author=null
   plan=T« … » | K« … »          (2 requêtes)
   score = 0,533
```

## Correctifs

1. **`TitleCleaner.authorPrefix` sans tiret** — un nom de 2-3 mots capitalisés
   n'est accepté que si le mot suivant **ouvre** un titre (`L`, `Les`, `Un`…).
   « Brandon Sanderson L Ensoleille » → auteur + « L Ensoleille ».
   « Le Seigneur des Anneaux » et « Harry Potter et le prisonnier… » restent
   intacts (article initial, ou pas d'ouvreur après le nom).
2. **`stripAuthorPrefix` sans tiret** — ne retire le nom que s'il reste ≥ 2 mots.
3. **`MetadataMatcher`** — quand le nom de l'auteur du candidat ouvre notre
   titre, il est retiré des jetons de titre **et** vaut preuve d'auteur.
   Filet de sécurité indépendant du nettoyeur : même un titre non découpé
   passe de 0,533 à **0,850**.
4. **Espaces exotiques** (`\u00A0`, `\u202F`, BOM) normalisés dans `clean()`.
5. **Message d'échec honnête et diagnostique** : il liste désormais les
   requêtes réellement envoyées avec leur nombre de résultats, et distingue
   « 0 résultat » de « N résultat(s), aucun assez proche ».

## Vérification (API live, pipeline complet)

| Livre | Score | Requêtes | Édition |
|---|---|---|---|
| **Brandon Sanderson L Ensoleille** (sans tiret) | **0,850 appliqué** | **1** | L'Ensoleillé (B0D63GMF39) |
| idem, titre brut non découpé (filet score) | **0,850 appliqué** | 1 | B0D63GMF39 |
| L'Âge de la Folie 03 (non-régression) | 0,884 | 2 | B0D7HWY631 |
| Les Archives de Roshar 2 | 0,914 | 1 | Le Livre des radieux |
| Solo Leveling 3 | 0,850 | 1 | B0H95GR62X |

Tests : **85 verts** (+5). ICU : **49 motifs, 0 invalide**.
`MATCHING_VERSION = 8` (registre des échecs purgé → tous les livres réévalués).
APK vc29, 23 817 951 o, certificat `ba7966a8…` inchangé.

---

# v0.7.4 (versionCode 30) — la solution générale

## Ce que la capture du 12:15 a montré

*« Aucune édition trouvée pour « Brandon Sanderson Les Archives de Roshar 05
Vent et verite 2 ». 10 requête(s) sur Audible.fr puis Audible.com — 0 résultat. »*

Quatre correctifs successifs (v0.7.1 → v0.7.3) avaient chacun réglé **un** nom de
dossier. Ce n'était pas la bonne méthode : le problème n'était pas le nettoyage
d'un cas particulier, c'était **l'architecture des requêtes**.

## Mesures qui ont tout décidé

| Requête | Résultats |
|---|---|
| `title=«les archives de roshar 05 vent et verite»` (ce que l'app envoyait) | **0** |
| `title=«vent et verite 2»` | **1** — le bon livre |
| `title=«vent et verite»` | 4 |
| `title=«les archives de roshar 5»` | 2 — les deux volumes |
| `keywords=«brandon sanderson»`, pages 1+2 | **100** livres de l'auteur |

Le catalogue Audible est un **moteur de catalogue**, pas un moteur de recherche :
`keywords` est un ET strict, chaque mot en trop rapproche du zéro. `num_results`
plafonne à 50 (100 → réponse vide) mais la pagination fonctionne.

## Les cinq changements de fond

1. **L'échelle de requêtes est construite à partir de SEGMENTS**, jamais du nom
   de dossier : saga + tome, sous-titre, sous-titre sans numéro de partie,
   mots-clés du sous-titre, saga seule, puis seulement le nom complet en
   `keywords`. Un `keywords` est plafonné à **6 mots**, un `title` à **8** — et
   la troncature garde la **fin** de la chaîne (« … la sagesse des foules »).
2. **Le filtre `author=` n'est plus envoyé.** L'API l'applique en ET : une
   mauvaise hypothèse (« Mélanie Fazi - traducteur ») annulait une requête
   parfaite, et chaque échec coûtait une seconde requête. La désambiguïsation se
   fait localement.
3. **Balayage de l'auteur en dernier recours** : si l'échelle échoue, l'app
   demande les 2 pages du catalogue de l'auteur (100 titres) et note localement.
   Un best-seller ne peut plus être « introuvable », quel que soit le nom du
   dossier. Les résultats sont pré-filtrés sur la contenance du titre : un
   auteur qui correspond ne suffit jamais à décider d'un livre.
4. **Le score compare dans les deux sens** (couverture symétrique) : quand le
   titre officiel est entièrement contenu dans le nom du dossier, c'est une
   correspondance — même si le dossier commence par la saga ou l'auteur.
5. **Le parseur apprend l'auteur en tête dès `TitleCleaner`**, y compris sans
   tiret et avec un prénom unique (« Tolkien - », « Chugong - »), et refuse les
   marqueurs de tome (« Harry Potter - Tome 1 » n'a pas d'auteur).

## Parasites d'Audible corrigés (mesurés)

- `subtitle` contient parfois **le nom de la saga** (« Chronique du Tueur de
  Roi ») ou **le label saga+tome** (« Dune 1 », « The Witcher, Tome 1 ») → il est
  écarté du calcul. Sur « Le Nom du Vent », +0,05 ; sur « Le Dernier Vœu », +0,08.
- **Ligatures** : « vœu » n'était pas décomposé par NFD (« vo u ») → « Le Dernier
  Vœu » ne matchait jamais « Le Dernier voeu ». `œ→oe`, `æ→ae`, `ß→ss`.
- **Tomes découpés en parties** : Audible numérote « 1.1 », « 1.2 ». La même
  partie entière = le même livre (plancher 0,80), et un numéro de partie
  contradictoire tue l'identité (« Dune 1 » ≠ « Dune - Livre troisième »).
- **Titres courts** : la couverture ne pèse plein que dès 3 mots, sinon « Dune »
  est « contenu » dans tous les livres de Dune.

## Validation : un corpus, pas un cas

18 noms de dossiers réels (dont les 3 échecs précédents), plan de requêtes
produit par le **vrai** `AudibleQueries`, exécuté sur l'API live :

| # | Dossier | Score | Édition trouvée |
|---|---|---|---|
| 1 | Brandon Sanderson Les Archives de Roshar 05 Vent et verite 2 | 0,850 | Vent et vérité - Volume 2 |
| 2 | … Roshar 2 - Le Livre des radieux | 0,868 | Le Livre des radieux 2 |
| 3 | L'Âge de la Folie 03 La Sagesse des Foules | 0,850 | La Sagesse des foules |
| 4 | Chugong - Solo Leveling 3 | 0,925 | Solo Leveling (t.3) |
| 5-6 | Brandon Sanderson L Ensoleille (+ M4B-K) | 0,850 | L'Ensoleillé |
| 7 | Harry Potter 1 A l ecole des sorciers | 0,912 | HP à l'École des Sorciers |
| 8 | Le Nom du Vent - Patrick Rothfuss | 0,798 | Le Nom du Vent 1 |
| 9 | Patrick Rothfuss - La Peur du Sage 2 | 0,800 | La Peur du Sage - Seconde partie |
| 10 | Frank Herbert - Dune 1 | 0,800 | Dune - Livre premier et livre second |
| 11 | Robin Hobb - L Assassin royal 1 | 0,850 | L'apprenti assassin |
| 12 | Pierre Bottero La Quete d Ewilan 1 | 0,850 | D'un monde à l'autre |
| 13-14 | HP 2 · Tolkien - Le Seigneur des Anneaux 1 | 0,854 / 0,850 | La Chambre des Secrets · La Fraternité de l'Anneau |
| 15-18 | Le Dernier Vœu · Les Misérables · 1984 · Autre Monde 1 | 0,820 → 0,850 | toutes correctes |

**18/18 auto-appliqués avec la bonne édition** (v0.7.3 : 15/18, et 1 faux
positif). Coût moyen : **1,5 requête par livre** (contre 10 dans la capture).

Tests : **103 verts** (+18). ICU : 53 motifs, 0 invalide.
`MATCHING_VERSION = 10`.
