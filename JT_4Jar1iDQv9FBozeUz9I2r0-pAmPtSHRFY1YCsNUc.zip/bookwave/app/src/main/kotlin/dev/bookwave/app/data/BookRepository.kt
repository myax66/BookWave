package dev.bookwave.app.data

import android.content.Context
import dev.bookwave.app.data.cloud.WebDavSource
import dev.bookwave.app.data.metadata.MetadataStore
import dev.bookwave.app.util.suspendRunCatching
import dev.bookwave.core.cloud.CloudSource
import dev.bookwave.core.cloud.MediaKind
import dev.bookwave.core.library.CoverPicker
import dev.bookwave.core.library.TitleCleaner
import dev.bookwave.core.model.Audiobook
import dev.bookwave.core.model.SourceRef
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

/** Safety cap on folder scans per level — keeps slow servers (AllDebrid) responsive. */
private const val MAX_FOLDERS = 1_500

/** Global PROPFIND budget per library refresh — a busy WebDAV stays responsive. */
private const val MAX_SCAN_REQUESTS = 4_000

/** How deep books may live below the root (root folders = depth 1). */
private const val MAX_SCAN_DEPTH = 5

/** Concurrent PROPFINDs per wave — big accounts load in a fraction of the time. */
private const val SCAN_PARALLEL = 6

/** Directories that never contain audiobooks but bloat scans on loaded accounts. */
private fun isJunkName(name: String): Boolean =
    name.startsWith(".") || name.startsWith("@") || name == "#recycle" || name == "lost+found"

/**
 * Aggregates cloud sources into the audiobook library.
 *
 * A "book" is either a folder of audio files (one chapter per file) or a
 * single container file (.m4b) — the common audiobook layouts. Demo mode
 * prepends offline sample books so the app works with zero configuration.
 */
class BookRepository(private val context: Context) {

    val settings = AppSettings(context)

    private val diskCache = LibraryCache(context)

    /** Official Audible metadata, merged over torrent-cleaned fields. */
    val metadata = MetadataStore(context)

    @Volatile
    private var cached: List<Audiobook>? = null

    /** Set when a scan hit its request/folder caps: some books may be missing. */
    @Volatile
    var lastScanNote: String? = null
        private set

    /** Cache identity: changing source or demo mode must not serve stale books. */
    private val cacheKey: String
        get() = "${settings.webdavUrl}|${settings.webdavUser}|${settings.demoMode}"

    companion object {
        /** Invalidated when sources change (settings save) so the next reload refetches. */
        @Volatile
        private var cacheValid = false

        /**
         * Set when new content landed server-side (a torrent just finished on
         * AllDebrid): forces the next library load to rescan even if the disk
         * cache is still "fresh".
         */
        @Volatile
        private var rescanRequested = false

        fun invalidateCache() {
            cacheValid = false
        }

        fun requestRescan() {
            cacheValid = false
            rescanRequested = true
        }
    }

    fun isConfigured(): Boolean = settings.isConfigured

    /**
     * Last known library from disk — served INSTANTLY on cold start so the user
     * sees their books (and what they were listening to) while the real scan
     * runs in the background. Null on a first ever launch or after a source
     * change.
     */
    suspend fun cachedBooks(): List<Audiobook>? = kotlinx.coroutines.withContext(Dispatchers.IO) {
        cached ?: diskCache.load(cacheKey)?.books?.also { cached = it }
    }

    /** True when the disk cache is recent enough to skip a network scan. */
    private fun cacheIsFresh(): Boolean {
        val entry = diskCache.load(cacheKey) ?: return false
        return diskCache.isFresh(entry)
    }

    /**
     * Library as a cold flow. Serves the in-memory cache unless [force] is set
     * or the cache was invalidated — a "very busy" WebDAV must not be rescanned
     * every time a screen resumes.
     */
    fun library(force: Boolean = false): Flow<List<Audiobook>> = flow {
        val hit = cached
        if (!force && cacheValid && hit != null) {
            emit(hit)
            return@flow
        }
        if (!force && !rescanRequested && cacheIsFresh()) {
            val fresh = diskCache.load(cacheKey)?.books ?: emptyList()
            cached = fresh
            cacheValid = true
            emit(fresh)
            return@flow
        }
        val demo = if (settings.demoMode) DemoLibrary.books() else emptyList()
        val cloud = if (settings.webdavUrl.isNotBlank()) fetchFromCloud() else emptyList()
        val books = (demo + cloud).sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.title })
        cached = books
        cacheValid = true
        rescanRequested = false
        diskCache.save(books, cacheKey)
        emit(books)
    }.flowOn(Dispatchers.IO)

    private suspend fun fetchFromCloud(): List<Audiobook> {
        val source: CloudSource = WebDavSource(
            account = settings.webdavUser.ifBlank { "mon-compte" },
            baseUrl = settings.webdavUrl,
            username = settings.webdavUser,
            password = settings.webdavPassword,
        )
        return booksFrom(source)
    }

    suspend fun booksFrom(source: CloudSource): List<Audiobook> {
        val root = source.list("/")
        val books = mutableListOf<Audiobook>()

        // Folder books. Scanned two levels deep: AllDebrid exposes media under
        // /links/<name>/, Nextcloud users often use /Audiobooks/<name>/ — a
        // single-level scan found nothing on both. Each folder whose children
        // include audio files is one book. A failing folder is skipped instead
        // of killing the whole library (one 404 must not empty the screen).
        val pending = ArrayDeque<Triple<String, Int, String>>() // path, depth, display name
        val failures = mutableListOf<String>()
        var budget = MAX_SCAN_REQUESTS // a busy WebDAV must not be hammered
        root.filter { it.isDirectory && !isJunkName(it.name) }.take(MAX_FOLDERS)
            .forEach { pending += Triple(it.path, 1, it.name) }
        while (pending.isNotEmpty() && budget > 0) {
            // List a wave of folders CONCURRENTLY: a loaded WebDAV answers one
            // request at a time otherwise and a big account takes minutes.
            val wave = mutableListOf<Triple<String, Int, String>>()
            while (pending.isNotEmpty() && wave.size < SCAN_PARALLEL && budget > 0) {
                wave += pending.removeFirst()
                budget--
            }
            val results = coroutineScope {
                // suspendRunCatching: a cancelled scan must propagate its
                // cancellation instead of turning every folder into a "failure".
                wave.map { item -> async { item to suspendRunCatching { source.list(item.first) } } }.awaitAll()
            }
            for ((item, outcome) in results) {
                val (path, depth, name) = item
                val children = outcome.getOrElse { e ->
                    failures += "$name (${e.message ?: "erreur"})"
                    emptyList()
                }
                val audios = children.filter { it.mediaKind == MediaKind.AUDIO }
                if (audios.isNotEmpty()) {
                    // Tracker banners/logos often sit FIRST in the folder:
                    // score names instead of trusting directory order.
                    val cover = CoverPicker.choose(
                        children.filter { it.mediaKind == MediaKind.COVER },
                        name,
                    )
                    // Torrent/scene names ("Book.FRENCH.AUDIOBOOK.MP3.128kbps-GRP")
                    // are cleaned into a readable title + series.
                    val cleaned = TitleCleaner.clean(name.ifBlank { path.trimEnd('/').substringAfterLast('/') })
                    books += Audiobook(
                        id = "${source.provider}:dir:$path",
                        title = cleaned.title,
                        author = cleaned.author,
                        series = cleaned.series,
                        seriesIndex = cleaned.seriesIndex,
                        // Size-based estimate assuming ~128 kbps; the library
                        // shows it prefixed with "~" because VBR/FLAC deviate.
                        durationMs = audios.sumOf { it.sizeBytes / 16_000 },
                        // No fake chapters: with unknown per-file durations the
                        // old fallback produced 1 ms spans (garbage metadata in
                        // the cache). The player builds REAL chapters from the
                        // live folder listing when the book is opened.
                        chapters = emptyList(),
                        source = SourceRef(
                            provider = source.provider,
                            account = source.account,
                            path = path,
                            contentUrl = null,
                        ),
                        sizeBytes = audios.sumOf { it.sizeBytes },
                        // No image file in the folder? Point at the first audio
                        // file: covers are usually EMBEDDED in the mp3/m4b and
                        // extracted client-side (that is what the notification
                        // artwork already does).
                        coverUrl = cover?.let { runCatching { source.streamUrl(it.path) }.getOrNull() }
                            ?: runCatching { source.streamUrl(audios.first().path) }.getOrNull(),
                    )
                } else if (depth < MAX_SCAN_DEPTH) {
                    children.filter { it.isDirectory && !isJunkName(it.name) }.take(MAX_FOLDERS)
                        .forEach { pending += Triple(it.path, depth + 1, it.name) }
                }
            }
        }

        // Single-file books (m4b etc.)
        root.filter { !it.isDirectory && it.mediaKind == MediaKind.AUDIO }.forEach { file ->
            val cleaned = TitleCleaner.clean(file.name)
            books += Audiobook(
                id = "${source.provider}:file:${file.path}",
                title = cleaned.title,
                author = cleaned.author,
                series = cleaned.series,
                seriesIndex = cleaned.seriesIndex,
                durationMs = file.sizeBytes / 16_000,
                source = SourceRef(
                    provider = source.provider,
                    account = source.account,
                    path = file.path,
                    contentUrl = runCatching { source.streamUrl(file.path) }.getOrNull(),
                ),
                sizeBytes = file.sizeBytes,
                coverUrl = runCatching { source.streamUrl(file.path) }.getOrNull(),
            )
        }
        // Tell the user when the scan stopped early instead of silently
        // showing an incomplete library.
        lastScanNote = when {
            budget <= 0 && pending.isNotEmpty() ->
                "Scan incomplet : limite de $MAX_SCAN_REQUESTS requêtes atteinte " +
                    "(${pending.size} dossiers non explorés). Touchez 🔄 pour continuer."
            root.count { it.isDirectory } >= MAX_FOLDERS ->
                "Scan incomplet : trop de dossiers à la racine (limite $MAX_FOLDERS)."
            else -> null
        }
        // Everything failed → surface a real error instead of an empty screen.
        if (books.isEmpty() && failures.isNotEmpty()) {
            throw java.io.IOException("Dossiers illisibles : ${failures.joinToString(", ").take(200)}")
        }
        return books
    }
}
