package dev.bookwave.app.sync

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import dev.bookwave.app.data.AppSettings
import dev.bookwave.app.data.ProgressStore
import dev.bookwave.core.sync.SyncEngine
import dev.bookwave.core.sync.SyncPayload
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.util.concurrent.TimeUnit

/**
 * Orchestrates multi-device progress sync using the deterministic
 * [SyncEngine] merge. Transport is pluggable: the skeleton syncs through a
 * JSON file on the same WebDAV account that hosts the library, so there is no
 * backend to run.
 */
class SyncCoordinator(
    private val progressStore: ProgressStore,
    private val transport: SyncTransport,
    /** STABLE install id (AppSettings.deviceId) — the same one progress records
     *  are written with, so ProgressMerge tie-breaking stays symmetric. The old
     *  per-process random UUID broke convergence guarantees. */
    val deviceId: String,
) {

    /**
     * One sync round. Data safety: if [SyncTransport.download] THROWS (network
     * down, auth refused, corrupt file), nothing is merged and nothing is
     * uploaded — the local state is left untouched and the worker retries later.
     */
    suspend fun syncNow(): Int {
        val local = SyncPayload(deviceId, progressStore.revision(), currentEntries())
        val remote = transport.download()
        val result = SyncEngine.mergeAll(local, remote)
        progressStore.replaceAll(result.merged)
        transport.upload(SyncPayload(deviceId, progressStore.revision(), result.merged))
        return result.conflictsResolved
    }

    private suspend fun currentEntries(): List<dev.bookwave.core.model.ListeningProgress> =
        progressStore.progress.first()
}

/** Pluggable remote side of the sync (WebDAV file, Dropbox file, backend API…). */
interface SyncTransport {
    suspend fun download(): SyncPayload
    suspend fun upload(payload: SyncPayload)
}

/** JSON codec for sync payloads (stable schema — version field for migrations). */
object SyncCodec {
    fun encode(payload: SyncPayload): String {
        val entries = JSONArray()
        payload.entries.forEach { e ->
            entries.put(
                JSONObject()
                    .put("bookId", e.bookId)
                    .put("positionMs", e.positionMs)
                    .put("durationMs", e.durationMs)
                    .put("speed", e.speed.toDouble())
                    .put("completed", e.completed)
                    .put("updatedAt", e.updatedAt.toString())
                    .put("deviceId", e.deviceId),
            )
        }
        return JSONObject()
            .put("version", 1)
            .put("deviceId", payload.deviceId)
            .put("revision", payload.revision)
            .put("entries", entries)
            .toString()
    }

    fun decode(json: String): SyncPayload {
        val o = JSONObject(json)
        val entries = o.getJSONArray("entries")
        return SyncPayload(
            deviceId = o.getString("deviceId"),
            revision = o.getLong("revision"),
            entries = buildList {
                for (i in 0 until entries.length()) {
                    val e = entries.getJSONObject(i)
                    add(
                        dev.bookwave.core.model.ListeningProgress(
                            bookId = e.getString("bookId"),
                            positionMs = e.getLong("positionMs"),
                            durationMs = e.getLong("durationMs"),
                            speed = e.getDouble("speed").toFloat(),
                            completed = e.getBoolean("completed"),
                            updatedAt = Instant.parse(e.getString("updatedAt")),
                            deviceId = e.getString("deviceId"),
                        ),
                    )
                }
            },
        )
    }
}

/** Periodic background sync while on a network. */
class ProgressSyncWorker(
    context: Context,
    params: WorkerParameters,
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val settings = AppSettings(applicationContext)
        // No WebDAV account → nowhere to sync to; success (not retry) so the
        // periodic work stays quiet until a source is configured.
        if (settings.webdavUrl.isBlank()) return Result.success()
        return try {
        // DataStore is a process-wide singleton (preferencesDataStore delegate),
        // so building the store here is cheap and avoids a service-locator lookup.
        val progressStore = ProgressStore(applicationContext)
        val transport: SyncTransport = WebDavSyncTransport(applicationContext)
        SyncCoordinator(progressStore, transport, settings.deviceId).syncNow()
        Result.success()
        } catch (cancellation: CancellationException) {
            // Worker stopped by the system: propagate, do NOT report a retry.
            throw cancellation
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        private const val WORK_NAME = "bookwave-progress-sync"

        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<ProgressSyncWorker>(30, TimeUnit.MINUTES)
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build(),
                )
                .build()
            WorkManager.getInstance(context)
                .enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
        }
    }
}
