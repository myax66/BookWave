"""
Mesure « avant / après » du moteur de recherche Audible de Bookwave.

- old_* reproduit la logique v0.6.4 (MetadataEnricher v4) : 7 requêtes max,
  on s'arrête à la PREMIÈRE qui renvoie quelque chose, `author` toujours
  transmis, num_results=8, matching v4 (dice simple, 1 seule série).
- new_* reproduit la logique v0.7.0 : échelle de requêtes mesurée, résultats
  POOLÉS, retry sans auteur, sortie anticipée à 0.75, num_results=20,
  matching v5 (couverture+dice, toutes les séries, pénalité de langue).

Usage : python3 measure_search.py
"""
import json, re, sys, time, unicodedata, urllib.parse, urllib.request
from dataclasses import dataclass, field

RG = "contributors,product_attrs,media,series,product_desc,rating"

def norm(s):
    s = (s or "").lower().replace("œ", "oe").replace("æ", "ae").replace("ß", "ss")
    s = unicodedata.normalize("NFD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    return re.sub(r"[^a-z0-9]+", " ", s.lower()).strip()

def toks(s):
    return [t for t in norm(s).split(" ") if t]

def dice(a, b):
    if not a or not b: return 0.0
    bb = list(b); hits = 0
    for t in a:
        if t in bb:
            bb.remove(t); hits += 1
    return 2.0 * hits / (len(a) + len(b))

def coverage(a, b):
    if not a or not b: return 0.0
    bb = list(b); hits = 0
    for t in a:
        if t in bb:
            bb.remove(t); hits += 1
    return hits / len(a)

ARTICLES = {"l","le","la","les","un","une","the","a","an","el","der","die","das"}
def dearticle(s):
    ws = s.split(" ")
    while ws and ws[0].lower() in ARTICLES: ws = ws[1:]
    return " ".join(ws) or s

def norm_series(s):
    s = re.sub(r"\([^)]*\)|\[[^]]*\]|\{[^}]*\}", " ", s or "")
    s = re.sub(r"(?i)\b(french|english|german|spanish|italian|edition|édition|series|série|serie|collection|integrale|intégrale|audiobook)\b", " ", s)
    return norm(s)

@dataclass
class Book:
    key: str
    title: str
    series: str = None
    idx: float = None
    author: str = None
    est_min: int = 0

@dataclass
class Cand:
    asin: str; title: str; subtitle: str = None
    authors: list = field(default_factory=list)
    narrators: list = field(default_factory=list)
    series: list = field(default_factory=list)   # [(name, index|None)]
    runtime: int = 0
    language: str = None
    market: str = "fr"
    def title_full(self):
        return self.title + ((" " + self.subtitle) if self.subtitle else "")

# ---------- scoring v4 (v0.6.4) ----------
def old_score(b: Book, c: Cand):
    title = dice(toks(b.title), toks(c.title_full()))
    if b.author is None: a = 0.5
    elif not c.authors: a = 0.0
    else: a = max(dice(toks(b.author), toks(x)) for x in c.authors)
    mine, theirs = b.series, (c.series[0][0] if c.series else None)
    if mine is None and theirs is None: s = 0.5
    elif mine is None or theirs is None: s = 0.3
    else:
        nd = dice(toks(mine), toks(theirs))
        ci = c.series[0][1] if c.series else None
        i = 0.6 if (b.idx is None or ci is None) else (1.0 if abs(b.idx - ci) < 0.01 else 0.3)
        s = nd * 0.7 + i * 0.3
    if b.est_min <= 0 or c.runtime <= 0: r = 0.5
    else:
        ratio = b.est_min / c.runtime
        r = 1.0 if 0.8 <= ratio <= 1.25 else (0.5 if 0.6 <= ratio <= 1.6 else 0.0)
    base = 0.5*title + 0.2*a + 0.15*s + 0.15*r
    sd = 0.0 if (not mine or not theirs) else dice(toks(mine), toks(theirs))
    im = b.idx is not None and c.series and c.series[0][1] is not None and abs(b.idx - c.series[0][1]) < 0.01
    if sd >= 0.75 and im:
        veto_a = b.author is not None and c.authors and a == 0.0
        veto_r = r == 0.0
        if not veto_a and not veto_r: return max(base, 0.85)
        if not veto_a: return max(base, 0.65)
    return base

# ---------- scoring v5 (v0.7.0) ----------
def new_score(b: Book, c: Cand):
    theirs = toks(c.title_full())
    mine = toks(b.title)
    if b.idx is not None and b.idx == int(b.idx) and mine and mine[-1] == str(int(b.idx)):
        mine = mine[:-1]
    title = 0.6*coverage(mine, theirs) + 0.4*dice(mine, theirs) if mine else 0.0
    if b.author is None: a = 0.5
    elif not c.authors: a = 0.0
    else:
        def asc(x):
            tx = toks(x)
            return max(dice(toks(b.author), tx), 1.0 if "".join(toks(b.author)) == "".join(tx) else dice(["".join(toks(b.author))], ["".join(tx)]))
        a = max(asc(x) for x in c.authors)
    series_list = c.series or []
    mine_s = b.series
    if mine_s is None and not series_list: s, identity = 0.5, False
    elif mine_s is None or not series_list: s, identity = 0.3, False
    else:
        s, identity = 0.0, False
        for (name, idx) in series_list:
            nd = dice(toks(mine_s), toks(norm_series(name)))
            im = b.idx is not None and idx is not None and abs(b.idx - idx) < 0.01
            iv = 0.6 if (b.idx is None or idx is None) else (1.0 if im else 0.3)
            s = max(s, nd*0.7 + iv*0.3)
            if nd >= 0.75 and im: identity = True
    if b.est_min <= 0 or c.runtime <= 0: r = 0.5
    else:
        ratio = b.est_min / c.runtime
        r = 1.0 if 0.8 <= ratio <= 1.25 else (0.5 if 0.6 <= ratio <= 1.6 else 0.0)
    base = 0.5*title + 0.2*a + 0.15*s + 0.15*r
    factor = 1.0 if (not c.language) else (1.0 if norm(c.language) == "french" else 0.80)
    if identity:
        veto_a = b.author is not None and c.authors and a == 0.0
        floor = max(base, 0.85) if not veto_a and r != 0.0 else (max(base, 0.65) if not veto_a else base)
        return floor * factor
    return base * factor

# ---------- API ----------
def fetch(params):
    url = "https://api.audible.fr/1.0/catalog/products?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": "Bookwave-measure/0.7"})
    with urllib.request.urlopen(req, timeout=25) as r:
        d = json.load(r)
    out = []
    for p in (d.get("products") or []):
        if not p.get("asin") or not p.get("title"): continue
        authors = [a.get("name") for a in (p.get("authors") or []) if a.get("name")]
        narr = [a.get("name") for a in (p.get("narrators") or []) if a.get("name")]
        series = []
        for s in (p.get("series") or []):
            idx = s.get("sequence") or None
            try: idx = float(idx) if idx not in (None, "") else None
            except ValueError: idx = None
            if s.get("title"): series.append((s["title"], idx))
        c = Cand(p["asin"], p["title"], p.get("subtitle"), authors, narr, series,
                 p.get("runtime_length_min") or 0, p.get("language"))
        if not (c.authors or c.narrators or c.runtime):   # stub ebook
            continue
        out.append(c)
    return out

def old_queries(b: Book):
    bare = re.sub(r"\s+\d{1,3}$", "", b.title)
    q = []
    for x in [b.series, b.title, dearticle(b.title), bare, dearticle(bare), b.title]:
        if x and x not in q: q.append(x)
    return q[:7]

def new_queries(b: Book):
    """Port de AudibleQueries.plan (mode, texte)."""
    t = b.title
    vol = None
    if b.idx is not None:
        m = re.search(r"\s+(\d{1,3})$", t)
        vol = m.group(1) if m else None
    without = re.sub(r"\s+\d{1,3}$", "", t) if vol else t
    out = []
    def add(mode, text):
        if not text: return
        text = " ".join(text.split())
        if mode == "TITLE": text = " ".join(text.split(" ")[:8])
        if (mode, text.lower()) not in [(m, x.lower()) for m, x in out]: out.append((mode, text))
    if b.series and b.idx is not None:
        add("TITLE", f"{b.series} {int(b.idx) if b.idx == int(b.idx) else b.idx}")
    add("TITLE", t)
    add("TITLE", without)
    add("KEYWORDS", t)
    add("KEYWORDS", without)
    add("KEYWORDS", dearticle(without))
    add("KEYWORDS", b.series)
    return out[:6]

def rank(fn, b, cands):
    return sorted(((fn(b, c), c) for c in cands), key=lambda x: -x[0])

def run_old(b):
    calls = 0; found = []
    for q in old_queries(b):
        calls += 1; time.sleep(0.7)
        try: found = fetch({"keywords": q, "author": b.author or "", "num_results": 8, "response_groups": RG})
        except Exception: found = []
        if found: break
    ranked = rank(old_score, b, found)
    return ranked, calls

def run_new(b):
    calls = 0; pool = {}
    for q in new_queries(b):
        mode, text = q
        key = "title" if mode == "TITLE" else "keywords"
        params = {key: text, "num_results": 20, "response_groups": RG + ",product_extended_attrs"}
        if b.author: params["author"] = b.author
        calls += 1; time.sleep(0.7)
        try: found = fetch(params)
        except Exception: found = []
        if not found and b.author:
            params.pop("author"); calls += 1; time.sleep(0.7)
            try: found = fetch(params)
            except Exception: found = []
        for c in found: pool.setdefault((c.market, c.asin), c)
        if pool:
            ranked = rank(new_score, b, list(pool.values()))
            if ranked[0][0] >= 0.75: break
    cands = [c for c in pool.values() if not c.language or norm(c.language) == "french"]
    ranked = rank(new_score, b, cands)
    return ranked, calls

BOOKS = [
    Book("Harry Potter 1", "Harry Potter 1 - A l'ecole des sorciers", "Harry Potter", 1.0, None, 501),
    Book("Solo Leveling 3", "Chugong - Solo Leveling 3", "Solo Leveling", 3.0, None, 518),
    Book("L'Ensorceleuse", "L'Ensorceleuse", None, None, None, 550),
    Book("Elantris 1", "Elantris 1 - Chute", "Elantris", 1.0, "Brandon Sanderson", 600),
    Book("Le Sang des 7 Rois 1", "Le Sang des 7 Rois 1", "Le Sang des 7 Rois", 1.0, None, 700),
]

def show(tag, b, ranked, calls):
    if not ranked:
        print(f"{tag:<4} {b.key:<22} calls={calls:<2} AUCUN RÉSULTAT")
        return
    s, c = ranked[0]
    print(f"{tag:<4} {b.key:<22} calls={calls:<2} score={s:.3f} auto={'OUI' if s>=0.75 else 'non'}"
          f" | {c.asin} | {c.title[:42]:<42} | {c.language} | ser={c.series[:2]}")

if __name__ == "__main__":
    only = sys.argv[1] if len(sys.argv) > 1 else None
    for b in BOOKS:
        if only and only.lower() not in b.key.lower(): continue
        ro, co = run_old(b)
        rn, cn = run_new(b)
        show("v4", b, ro, co)
        show("v5", b, rn, cn)
        print()
