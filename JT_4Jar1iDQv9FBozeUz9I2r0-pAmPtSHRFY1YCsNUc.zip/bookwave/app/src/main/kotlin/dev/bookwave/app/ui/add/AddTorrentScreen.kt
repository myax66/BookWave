package dev.bookwave.app.ui.add

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.TextButton
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.bookwave.app.data.AppSettings
import dev.bookwave.app.data.BookRepository
import dev.bookwave.app.data.alldebrid.AllDebridApi
import dev.bookwave.app.data.alldebrid.PendingTorrent
import dev.bookwave.app.data.torznab.TorznabApi
import dev.bookwave.app.util.suspendRunCatching
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Adds a torrent straight to the user's AllDebrid account — magnet link pasted
 * or shared in, or a local .torrent file — then follows the transfer until the
 * files land in the WebDAV `/links/` folder the library reads.
 *
 * No extra credential: the account API key is the one already stored as the
 * WebDAV username.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTorrentScreen(
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings = remember { AppSettings(context) }
    val apiKey = settings.webdavUser
    val api = remember(apiKey) { AllDebridApi(apiKey) }

    // rememberSaveable: a shared magnet survived rotation before only by
    // luck; the field and picked file now do (ByteArray is bundle-safe).
    var magnetText by rememberSaveable { mutableStateOf("") }
    var torrentName by rememberSaveable { mutableStateOf<String?>(null) }
    var torrentBytes by rememberSaveable { mutableStateOf<ByteArray?>(null) }
    var magnets by rememberSaveable { mutableStateOf<List<AllDebridApi.Magnet>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var message by rememberSaveable { mutableStateOf<String?>(null) }
    /** Transfer awaiting delete confirmation (was deleted on a single tap). */
    var pendingDelete by remember { mutableStateOf<AllDebridApi.Magnet?>(null) }

    // Consuming the shared torrent is a SIDE EFFECT: in a LaunchedEffect, not
    // in the remember initializer (a discarded composition used to eat it).
    LaunchedEffect(Unit) {
        if (magnetText.isEmpty()) {
            PendingTorrent.consume()?.let { magnetText = it }
        }
    }

    fun refreshList() {
        if (apiKey.isBlank()) return
        scope.launch {
            suspendRunCatching { api.listMagnets() }
                .onSuccess { magnets = it }
                .onFailure { e -> message = "❌ ${e.message}" }
        }
    }

    // Loads the account transfers, then keeps polling while one is in flight.
    LaunchedEffect(apiKey) {
        if (apiKey.isBlank()) return@LaunchedEffect
        suspendRunCatching { api.listMagnets() }
            .onSuccess { magnets = it }
            .onFailure { e -> message = "❌ ${e.message}" }
        while (true) {
            delay(10_000)
            if (magnets.any { !it.isReady && !it.isError }) {
                suspendRunCatching { api.listMagnets() }.onSuccess { magnets = it }
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val loaded = withContext(Dispatchers.IO) { readTorrent(context, uri) }
                if (loaded == null) {
                    message = "❌ Impossible de lire ce fichier"
                } else {
                    torrentName = loaded.first
                    torrentBytes = loaded.second
                    message = null
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Ajouter un torrent") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                actions = {
                    IconButton(onClick = { refreshList() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Actualiser")
                    }
                },
            )
        },
    ) { padding ->
        if (apiKey.isBlank()) {
            Column(
                Modifier.fillMaxSize().padding(padding).padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    "Aucune clé API AllDebrid enregistrée.\n\n" +
                        "Configurez d'abord votre source (☁️ en haut de la bibliothèque) : " +
                        "l'identifiant WebDAV est votre clé API, c'est elle qui sert ici.",
                    style = MaterialTheme.typography.bodyLarge,
                )
                Button(onClick = onBack, modifier = Modifier.padding(top = 16.dp)) { Text("Retour") }
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(key = "magnet") {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Lien magnet", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = magnetText,
                            onValueChange = { magnetText = it },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2,
                            placeholder = { Text("magnet:?xt=urn:btih:… ou un hash") },
                            leadingIcon = { Icon(Icons.Default.Link, contentDescription = null) },
                        )
                        Button(
                            onClick = {
                                val text = magnetText.trim()
                                if (text.isEmpty()) {
                                    message = "Collez d'abord un lien magnet"
                                    return@Button
                                }
                                busy = true
                                message = null
                                scope.launch {
                                    suspendRunCatching { api.uploadMagnet(text) }
                                        .onSuccess {
                                            message = "✅ Torrent ajouté à AllDebrid (transfert #$it)"
                                            magnetText = ""
                                            refreshList()
                                        }
                                        .onFailure { e -> message = "❌ ${e.message}" }
                                    busy = false
                                }
                            },
                            enabled = !busy,
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("Ajouter à AllDebrid") }
                    }
                }
            }

            item(key = "file") {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Fichier .torrent", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !busy) {
                                Icon(Icons.Default.FolderOpen, contentDescription = null)
                                Text(" Choisir un fichier", modifier = Modifier.padding(start = 6.dp))
                            }
                            torrentName?.let {
                                Text(
                                    it,
                                    style = MaterialTheme.typography.bodyMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f),
                                )
                            }
                        }
                        val bytes = torrentBytes
                        if (bytes != null) {
                            Button(
                                onClick = {
                                    busy = true
                                    message = null
                                    scope.launch {
                                        suspendRunCatching { api.uploadTorrentFile(torrentName ?: "torrent.torrent", bytes) }
                                            .onSuccess {
                                                message = "✅ Fichier .torrent envoyé (transfert #$it)"
                                                torrentName = null
                                                torrentBytes = null
                                                refreshList()
                                            }
                                            .onFailure { e -> message = "❌ ${e.message}" }
                                        busy = false
                                    }
                                },
                                enabled = !busy,
                                modifier = Modifier.fillMaxWidth(),
                            ) { Text("Envoyer ce .torrent") }
                        }
                    }
                }
            }

            if (busy) {
                item(key = "busy") {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        Text("Envoi en cours…", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            message?.let { msg ->
                item(key = "message") {
                    Text(
                        msg,
                        style = MaterialTheme.typography.bodyLarge,
                        color = if (msg.startsWith("✅")) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.error,
                    )
                }
            }

            // A finished transfer means new books on the WebDAV: offer a rescan.
            if (magnets.any { it.isReady }) {
                item(key = "rescan") {
                    Button(
                        onClick = {
                            BookRepository.requestRescan()
                            onBack()
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Actualiser ma bibliothèque") }
                }
            }

            item(key = "list-header") {
                Text(
                    "Mes transferts AllDebrid (${magnets.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }

            items(magnets, key = { it.id }) { magnet ->
                MagnetRow(
                    magnet = magnet,
                    onDelete = { pendingDelete = magnet },
                )
            }
        }

        // Deleting a transfer also deletes its FILES on AllDebrid: confirm.
        pendingDelete?.let { target ->
            AlertDialog(
                onDismissRequest = { pendingDelete = null },
                title = { Text("Supprimer ce transfert ?") },
                text = {
                    Text(
                        "« ${target.filename} » sera définitivement supprimé de votre " +
                            "espace AllDebrid, fichiers audio inclus.",
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            pendingDelete = null
                            scope.launch {
                                suspendRunCatching { api.deleteMagnet(target.id) }
                                    .onSuccess { magnets = magnets.filterNot { it.id == target.id } }
                                    .onFailure { e -> message = "❌ ${e.message}" }
                            }
                        },
                    ) { Text("Supprimer") }
                },
                dismissButton = {
                    TextButton(onClick = { pendingDelete = null }) { Text("Annuler") }
                },
            )
        }
    }
}

@Composable
private fun MagnetRow(magnet: AllDebridApi.Magnet, onDelete: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    magnet.filename,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Supprimer")
                }
            }
            val progress = magnet.progress
            if (progress >= 0f && !magnet.isReady) {
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
            } else if (magnet.isReady) {
                LinearProgressIndicator(progress = { 1f }, modifier = Modifier.fillMaxWidth())
            }
            Text(
                buildString {
                    append(if (magnet.isReady) "✅ " else if (magnet.isError) "❌ " else "")
                    append(magnet.label)
                    if (progress in 0f..1f && !magnet.isReady) append(" — ${(progress * 100).toInt()} %")
                    if (magnet.sizeBytes > 0) append(" · ${TorznabApi.humanSize(magnet.sizeBytes)}")
                    if (!magnet.isReady && !magnet.isError && magnet.seeders > 0) append(" · ${magnet.seeders} seeders")
                },
                style = MaterialTheme.typography.bodySmall,
                color = when {
                    magnet.isReady -> MaterialTheme.colorScheme.primary
                    magnet.isError -> MaterialTheme.colorScheme.error
                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                },
            )
        }
    }
}

// humanSize: TorznabApi.humanSize is the ONE implementation (the local copy
// formatted with the default locale and diverged from the catalogue's).

/** Reads a picked .torrent: display name + raw bytes. */
private fun readTorrent(context: Context, uri: Uri): Pair<String, ByteArray>? = runCatching {
    val name = context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
        val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
    } ?: "torrent.torrent"
    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
    if (bytes.isEmpty()) return null
    name to bytes
}.getOrNull()
