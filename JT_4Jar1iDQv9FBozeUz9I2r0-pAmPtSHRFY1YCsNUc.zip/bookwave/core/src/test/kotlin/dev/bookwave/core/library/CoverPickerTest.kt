package dev.bookwave.core.library

import dev.bookwave.core.cloud.CloudEntry
import dev.bookwave.core.cloud.MediaKind
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class CoverPickerTest {

    private fun img(name: String, size: Long = 100_000) =
        CloudEntry("/b/$name", name, false, size, 0L, MediaKind.COVER)

    @Test
    fun `tracker banner listed first loses to the real cover`() {
        val covers = listOf(img("c411-logo.png", 40_000), img("cover.jpg", 300_000))
        assertEquals("cover.jpg", CoverPicker.choose(covers, "Mon Livre")?.name)
    }

    @Test
    fun `banner wins only when nothing better exists`() {
        val covers = listOf(img("banner.jpg", 40_000))
        assertEquals("banner.jpg", CoverPicker.choose(covers, "Mon Livre")?.name)
    }

    @Test
    fun `folder-named scan beats a generic image`() {
        val covers = listOf(img("scan.jpg", 500_000), img("mon_livre_001.jpg", 200_000))
        assertEquals("mon_livre_001.jpg", CoverPicker.choose(covers, "mon_livre")?.name)
    }

    @Test
    fun `equal names fall back to the largest file`() {
        val covers = listOf(img("img01.jpg", 10_000), img("img02.jpg", 900_000))
        assertEquals("img02.jpg", CoverPicker.choose(covers, "ZZZ autre")?.name)
    }

    @Test
    fun `empty folder has no cover`() {
        assertNull(CoverPicker.choose(emptyList(), "X"))
    }
}
