package dev.bookwave.app.ui.library

import android.content.ComponentName
import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FabPosition
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import dev.bookwave.app.data.BookRepository
import dev.bookwave.app.data.AppSettings
import dev.bookwave.app.data.alldebrid.AllDebridApi
import dev.bookwave.app.data.ProgressStore
import dev.bookwave.app.player.PlaybackBus
import dev.bookwave.app.player.PlaybackService
import dev.bookwave.app.ui.common.CoverImage
import dev.bookwave.core.model.Audiobook
import dev.bookwave.core.model.ListeningProgress
import dev.bookwave.core.util.TimeFmt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.stateIn
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextField
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.TextButton
import dev.bookwave.app.data.metadata.EnrichResult
import dev.bookwave.app.data.metadata.MetadataEnricher
import dev.bookwave.app.data.metadata.MetadataStore
import dev.bookwave.core.library.TitleCleaner
import dev.bookwave.core.metadata.BookMetadata
import dev.bookwave.core.metadata.MetadataMatcher
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.koin.core.context.GlobalContext
import java.util.Locale

/** Listening-status filter chips. */
private enum class StatusFilter(val label: String) {
    ALL("Tous"),
    ONGOING("En cours"),
    UNSTARTED("Non commencés"),
    FINISHED("Terminés"),
}

/** Sort + grouping modes; TITLE and SERIES also add section headers. */
private enum class SortMode(val label: String) {
    TITLE("Titre A→Z"),
    SERIES("Par série"),
    RECENT("Écoutés récemment"),
    PROGRESS("Progression"),
}

/** Explicit screen states: an endless spinner was hiding empty/error results. */
sealed interface LibraryUiState {
    data object Loading : LibraryUiState

    /**
     * @param refreshing a background scan is running (cached books already shown)
     * @param error banner text; the cached books stay visible underneath
     * @param note scan completeness note (caps reached)
     */
    data class Loaded(
        val books: List<Pair<Audiobook, ListeningProgress?>>,
        val refreshing: Boolean = false,
        val error: String? = null,
        val note: String? = null,
    ) : LibraryUiState

    data class Failed(val message: String) : LibraryUiState
}

private data class RefreshRequest(val seq: Int = 0, val force: Boolean = false)

/** A pass stops only after this many failures IN A ROW (network really down). */
private const val MAX_CONSECUTIVE_FAILURES = 3

/** Internal step: null books = nothing cached yet. */
private data class Snapshot(val books: List<Audiobook>?, val refreshing: Boolean, val error: String?, val note: String?)

@OptIn(ExperimentalCoroutinesApi::class)
class LibraryViewModel(
    private val repository: BookRepository,
    private val progressStore: ProgressStore,
) : ViewModel() {

    private val refreshTick = MutableStateFlow(RefreshRequest())
    private val configuredState = MutableStateFlow(repository.isConfigured())

    /** Official Audible metadata, merged over torrent-cleaned fields. */
    val metadata: MetadataStore = repository.metadata

    private val enrichMarkets = when (repository.settings.enrichMarket) {
        "fr" -> listOf("fr")
        "com" -> listOf("com")
        else -> listOf("fr", "com")
    }
    private val enrichLanguage = MetadataEnricher.languageOf(enrichMarkets)

    private val enricher = MetadataEnricher(metadata, enrichMarkets, enrichLanguage)

    /** What the library sheet shows: candidate editions, book fiche, or a note. */
    sealed interface LibraryDialog {
        data class Candidates(val bookId: String, val options: List<Pair<BookMetadata, Double>>) : LibraryDialog
        data class Fiche(val bookId: String) : LibraryDialog

        /** [bookId] set when the note can offer a manual Audible search. */
        data class Message(val text: String, val bookId: String? = null) : LibraryDialog

        /** Manual "Rechercher sur Audible" sheet (v0.7.0). */
        data class Search(
            val bookId: String,
            val query: String,
            val author: String,
            val results: List<Pair<BookMetadata, Double>> = emptyList(),
            val busy: Boolean = true,
            val error: String? = null,
        ) : LibraryDialog
    }

    private val _dialog = MutableStateFlow<LibraryDialog?>(null)
    val dialog: StateFlow<LibraryDialog?> = _dialog

    /** User-visible outcome of the last background identification pass. */
    private val _report = MutableStateFlow<String?>(null)
    val report: StateFlow<String?> = _report
    fun dismissReport() {
        _report.value = null
    }

    val configured: StateFlow<Boolean> = configuredState

    val state: StateFlow<LibraryUiState> =
        refreshTick
            .flatMapLatest { req -> snapshots(req) }
            .combine(progressStore.progress) { snap, saved -> snap to saved }
            // metadata.version: re-merge (titles/covers/runtime) as soon as an
            // enrichment lands, without rescanning the WebDAV.
            .combine(metadata.version) { (snap, saved), _ ->
                val byBook = saved.associateBy { it.bookId }
                val books = snap.books
                when {
                    books == null && snap.error != null -> LibraryUiState.Failed(snap.error)
                    books == null -> LibraryUiState.Loading
                    else -> LibraryUiState.Loaded(
                        // v0.8.0 — was O(n²): one linear scan of `saved` PER
                        // book, on every metadata bump. A loaded account with
                        // 2 000 books did 4 million comparisons each time a
                        // single cover resolved.
                        books = books.map { book ->
                            metadata.merge(book) to byBook[book.id]
                        },
                        refreshing = snap.refreshing,
                        error = snap.error,
                        note = snap.note,
                    )
                }
            }
            .catch { e -> emit(LibraryUiState.Failed(e.message ?: e.javaClass.simpleName)) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), LibraryUiState.Loading)

    /**
     * Cached books FIRST (instant, from disk), then the live scan. A relaunch
     * never shows a blank spinner while a huge WebDAV is walked again.
     */
    private fun snapshots(req: RefreshRequest): Flow<Snapshot> = flow {
        val disk = repository.cachedBooks()
        emit(Snapshot(disk, refreshing = true, error = null, note = null))
        try {
            repository.library(force = req.force).collect { fresh ->
                emit(Snapshot(fresh, refreshing = false, error = null, note = repository.lastScanNote))
            }
        } catch (e: Exception) {
            val msg = e.message ?: e.javaClass.simpleName
            emit(Snapshot(disk, refreshing = false, error = msg, note = repository.lastScanNote))
        }
    }.flowOn(Dispatchers.IO)

    /** Screen resume: serves the cache instantly (no network on a busy WebDAV). */
    fun refresh() {
        configuredState.value = repository.isConfigured()
        refreshTick.value = RefreshRequest(refreshTick.value.seq + 1, force = false)
        if (repository.settings.consumeEnrichPassRequest() && repository.settings.enrichEnabled) {
            runEnrichPass(30)
        }
    }

    /** Manual "reload" button / retry: always refetches. */
    fun forceRefresh() {
        configuredState.value = repository.isConfigured()
        refreshTick.value = RefreshRequest(refreshTick.value.seq + 1, force = true)
    }

    fun metadataOf(bookId: String): BookMetadata? = metadata.of(bookId)

    fun dismissDialog() {
        _dialog.value = null
    }

    fun confirmMatch(bookId: String, meta: BookMetadata) {
        metadata.put(bookId, meta)
        _dialog.value = null
    }

    fun removeMetadata(bookId: String) {
        metadata.remove(bookId)
        _dialog.value = null
    }

    /**
     * Manual search: the automatic ladder failed (or the user wants another
     * edition) — open a sheet pre-filled with the cleaned title and guessed
     * author, and run one search immediately so it is never an empty page.
     */
    fun openSearch(bookId: String) {
        val book = bookOf(bookId) ?: return
        val raw = book.source.path.trimEnd('/').substringAfterLast('/')
        val guess = TitleCleaner.clean(raw.ifBlank { book.title })
        val query = guess.title.ifBlank { book.title }
        val author = (guess.author ?: book.author).orEmpty()
        _dialog.value = LibraryDialog.Search(bookId, query, author)
        runSearch(bookId, query, author)
    }

    fun runSearch(bookId: String, query: String, author: String) {
        val current = _dialog.value as? LibraryDialog.Search ?: return
        _dialog.value = current.copy(query = query, author = author, busy = true, error = null)
        viewModelScope.launch {
            val book = bookOf(bookId)
            if (book == null) {
                updateSearch(bookId) { it.copy(busy = false, error = "Livre introuvable dans la bibliothèque.") }
                return@launch
            }
            val input = MetadataMatcher.MatchInput(
                title = book.title,
                author = book.author,
                series = book.series,
                seriesIndex = book.seriesIndex,
                estimatedMs = book.durationMs,
                language = enrichLanguage,
            )
            val results = try {
                enricher.search(input, query, author.ifBlank { null })
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                updateSearch(bookId) {
                    it.copy(busy = false, error = "Recherche impossible : ${e.message ?: e.javaClass.simpleName}")
                }
                return@launch
            }
            updateSearch(bookId) {
                it.copy(
                    results = results,
                    busy = false,
                    error = if (results.isEmpty()) {
                        "Aucune édition trouvée. Essayez le titre officiel, le nom de la saga, ou un ASIN Audible."
                    } else {
                        null
                    },
                )
            }
        }
    }

    private fun updateSearch(bookId: String, transform: (LibraryDialog.Search) -> LibraryDialog.Search) {
        val current = _dialog.value as? LibraryDialog.Search ?: return
        if (current.bookId == bookId) _dialog.value = transform(current)
    }

    /**
     * The raw trace ("fr:T«…»→0, com:K«…»→0") is developer noise in a dialog.
     * Summarise it: how many queries ran, on which markets, and what to do next.
     */
    private fun failureMessage(title: String, trace: String): String {
        data class Tried(val mode: String, val text: String, val count: Int?)

        val parts = trace.split(", ").map { it.trim() }.filter { it.isNotEmpty() && ("→" in it || "erreur" in it) }
        val markets = parts.mapNotNull { it.substringBefore(':').takeIf { m -> m == "fr" || m == "com" } }.distinct()
        val marketLabel = when {
            markets.isEmpty() -> "Audible"
            markets.size == 1 -> if (markets[0] == "fr") "Audible.fr" else "Audible.com"
            else -> "Audible.fr puis Audible.com"
        }
        val tried = parts.mapNotNull { part ->
            val mode = when {
                ":T«" in part -> "titre"
                ":K«" in part -> "mots-clés"
                else -> return@mapNotNull null
            }
            val text = part.substringAfter('«', "").substringBefore('»', "")
            if (text.isBlank()) return@mapNotNull null
            Tried(mode, text, part.substringAfterLast('→', "").toIntOrNull())
        }
        val total = tried.sumOf { it.count ?: 0 }
        val errors = tried.count { it.count == null }
        return buildString {
            append("Aucune édition trouvée pour « ").append(title).append(" ».\n")
            if (tried.isEmpty()) {
                append("Aucune requête n'a pu aboutir.")
            } else {
                append(tried.size).append(" requête(s) sur ").append(marketLabel)
                when {
                    errors == tried.size -> append(" — aucune réponse.")
                    total == 0 -> append(" — 0 résultat.")
                    else -> append(" — ").append(total).append(" résultat(s), aucun assez proche.")
                }
                // v0.7.3: the dialog used to hide WHICH words were searched, so
                // a bad folder name looked identical to a dead API. Show them.
                tried.take(4).forEach { t ->
                    append('\n').append("· ").append(t.mode).append(" « ").append(t.text).append(" » → ")
                    append(t.count ?: "erreur réseau")
                }
            }
            append("\nEssaie le titre officiel, le nom de la saga, ou un ASIN Audible.")
        }
    }

    private fun bookOf(bookId: String): Audiobook? =
        (state.value as? LibraryUiState.Loaded)?.books?.firstOrNull { it.first.id == bookId }?.first

    /** Long press: fiche if enriched, Audible matching otherwise. */
    fun onBookLongPress(book: Audiobook) {
        viewModelScope.launch {
            if (metadata.of(book.id) != null) {
                _dialog.value = LibraryDialog.Fiche(book.id)
            } else {
                // Explicit user intent: bypass the 7-day miss ledger.
                runEnrich(book, force = true)
            }
        }
    }

    fun chooseOtherEdition(bookId: String) {
        viewModelScope.launch {
            val book = (state.value as? LibraryUiState.Loaded)?.books
                ?.firstOrNull { it.first.id == bookId }?.first ?: return@launch
            runEnrich(book, force = true)
        }
    }

    private suspend fun runEnrich(book: Audiobook, force: Boolean) {
        val result: EnrichResult = try {
            enricher.enrich(book, force)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            _dialog.value = LibraryDialog.Message(
                "Recherche Audible impossible : ${e.message ?: e.javaClass.simpleName}",
            )
            return
        }
        when (result) {
            // Applied: metadata.version bumps and the state re-merges itself.
            is EnrichResult.Applied -> Unit
            is EnrichResult.Suggest -> _dialog.value = LibraryDialog.Candidates(book.id, result.options)
            is EnrichResult.None -> _dialog.value = LibraryDialog.Message(
                failureMessage(book.title, result.trace),
                bookId = book.id,
            )
            is EnrichResult.Failed -> _dialog.value = LibraryDialog.Message(
                "Recherche Audible impossible : ${result.message}",
            )
        }
    }

    init {
        if (!repository.settings.enrichLedgerV2Done) {
            // v0.6.1 pollué : des erreurs réseau avaient été enregistrées
            // comme « introuvables » pour 7 jours → tout était gelé.
            metadata.clearTried()
            repository.settings.enrichLedgerV2Done = true
        }
        // Toute mise à jour réévalue les échecs : le matching s'améliore
        // version après version (v0.6.3 : requêtes reconstruites), un vieux
        // registre ne doit jamais les geler.
        if (repository.settings.enrichLedgerVersion != MetadataEnricher.MATCHING_VERSION) {
            metadata.clearTried()
            repository.settings.enrichLedgerVersion = MetadataEnricher.MATCHING_VERSION
        }
        if (repository.settings.enrichEnabled) runEnrichPass(60)
    }

    /**
     * One background identification pass with a USER-VISIBLE report: silent
     * passes are how v0.6.0/0.6.1 shipped "nothing happened" twice.
     * Listening books first; true misses ledgered 7 days; network errors
     * never ledgered.
     *
     * v0.8.0 — three field fixes:
     *  - it waits for the library scan to settle (20 s max) instead of
     *    competing with it for the OkHttp dispatcher on a cold start;
     *  - ONE network failure no longer aborts the pass: the book is retried,
     *    and only three failures in a row (network really gone) stop it;
     *  - metadata writes are batched: one disk write for the whole pass
     *    instead of one full-file rewrite per resolved book.
     */
    private fun runEnrichPass(budget: Int) {
        viewModelScope.launch {
            withTimeoutOrNull(20_000L) {
                state.first { it is LibraryUiState.Loaded && !it.refreshing }
            }
            val loaded = state.value as? LibraryUiState.Loaded ?: return@launch
            var applied = 0
            var suggest = 0
            var none = 0
            var failed = 0
            var consecutive = 0
            metadata.beginBatch()
            try {
                val targets = (loaded.books.filter { it.second?.isFinished == false }.map { it.first } +
                    loaded.books.map { it.first })
                    .distinctBy { it.id }
                    .filter { metadata.of(it.id) == null && !metadata.triedRecently(it.id) }
                    .take(budget)
                for (book in targets) {
                    val r = try {
                        enricher.enrich(book)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        EnrichResult.Failed(e.message ?: e.javaClass.simpleName)
                    }
                    when (r) {
                        is EnrichResult.Applied -> {
                            applied++
                            consecutive = 0
                        }
                        is EnrichResult.Suggest -> {
                            suggest++
                            consecutive = 0
                        }
                        is EnrichResult.None -> {
                            none++
                            consecutive = 0
                        }
                        is EnrichResult.Failed -> {
                            failed++
                            consecutive++
                            if (consecutive >= MAX_CONSECUTIVE_FAILURES) break
                            delay(2_000)
                            continue
                        }
                    }
                    delay(800)
                }
                _report.value = "Enrichissement Audible : $applied appliqués" +
                    (if (suggest > 0) ", $suggest à départager (appui long)" else "") +
                    (if (none > 0) ", $none introuvables" else "") +
                    (if (failed > 0) ", $failed en erreur (réseau ?)" else "")
            } finally {
                // Closes the batch AND persists everything it resolved, off
                // the main thread. `endBatch` (not just `flushNow`) matters:
                // leaving `batching` set would silence every later write.
                withContext(Dispatchers.IO) { metadata.endBatch() }
            }
        }
    }
}


/**
 * Library tab — Lots C + D + E.
 *
 *  - [LargeTopAppBar] that collapses on scroll (iOS-style large title)
 *  - 2-column [LazyVerticalGrid] of book covers
 *  - [SingleChoiceSegmentedButtonRow] for the listening-status filter
 *  - "Reprendre" carousel pinned at the top of the grid
 *  - Haptic feedback on book tap
 *  - Mini-player bar with shared-element cover morph (Lot B, preserved)
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalSharedTransitionApi::class)
@Composable
fun LibraryScreen(
    onBookClick: (String, String, String?) -> Unit,
    onAddTorrentClick: () -> Unit,
    onEnableDemo: () -> Unit,
    onNavigateToSettings: () -> Unit,
    sharedTransitionScope: SharedTransitionScope? = null,
    animatedVisibilityScope: AnimatedVisibilityScope? = null,
    viewModel: LibraryViewModel = viewModel {
        val koin = GlobalContext.get()
        LibraryViewModel(koin.get(), koin.get())
    },
) {
    val context = LocalContext.current
    val haptics = LocalHapticFeedback.current
    val state by viewModel.state.collectAsStateWithLifecycle()
    val configured by viewModel.configured.collectAsStateWithLifecycle()
    val dialog by viewModel.dialog.collectAsStateWithLifecycle()
    val report by viewModel.report.collectAsStateWithLifecycle()

    when (val d = dialog) {
        is LibraryViewModel.LibraryDialog.Candidates -> MatchCandidatesDialog(
            options = d.options,
            onPick = { viewModel.confirmMatch(d.bookId, it) },
            onDismiss = viewModel::dismissDialog,
        )
        is LibraryViewModel.LibraryDialog.Fiche -> {
            val meta = viewModel.metadataOf(d.bookId)
            if (meta != null) {
                BookFicheDialog(
                    meta = meta,
                    onOther = { viewModel.chooseOtherEdition(d.bookId) },
                    onSearch = { viewModel.openSearch(d.bookId) },
                    onRemove = { viewModel.removeMetadata(d.bookId) },
                    onDismiss = viewModel::dismissDialog,
                )
            }
        }
        is LibraryViewModel.LibraryDialog.Search -> AudibleSearchDialog(
            state = d,
            onSearch = { query, author -> viewModel.runSearch(d.bookId, query, author) },
            onPick = { viewModel.confirmMatch(d.bookId, it) },
            onDismiss = viewModel::dismissDialog,
        )
        is LibraryViewModel.LibraryDialog.Message -> AlertDialog(
            onDismissRequest = viewModel::dismissDialog,
            text = { Text(d.text) },
            confirmButton = {
                Row {
                    d.bookId?.let { bookId ->
                        TextButton(onClick = { viewModel.openSearch(bookId) }) {
                            Text("Chercher sur Audible")
                        }
                    }
                    TextButton(onClick = viewModel::dismissDialog) { Text("OK") }
                }
            },
        )
        null -> Unit
    }

    // NOT remember(configured): switching Nextcloud -> AllDebrid keeps
    // `configured` true and the FAB used to stay hidden until process death.
    // The settings snapshot IS remembered: building AppSettings and reading
    // SharedPreferences three times per recomposition was visible while
    // scrolling the grid.
    val webdavUrlNow = remember(configured) { AppSettings(context).webdavUrl }
    val canAddTorrent = configured && AllDebridApi.isAllDebridAccount(webdavUrlNow)

    // rememberSaveable: search and filters survive rotation/process death.
    var query by rememberSaveable { mutableStateOf("") }
    var statusFilter by rememberSaveable { mutableStateOf(StatusFilter.ALL) }
    var sortMode by rememberSaveable { mutableStateOf(SortMode.TITLE) }
    var sortMenuOpen by rememberSaveable { mutableStateOf(false) }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) viewModel.refresh()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Bibliothèque") },
                actions = {
                    Box {
                        IconButton(onClick = { sortMenuOpen = true }) {
                            Icon(Icons.Default.Sort, contentDescription = "Trier")
                        }
                        DropdownMenu(expanded = sortMenuOpen, onDismissRequest = { sortMenuOpen = false }) {
                            SortMode.entries.forEach { mode ->
                                DropdownMenuItem(
                                    text = { Text(mode.label) },
                                    onClick = { sortMode = mode; sortMenuOpen = false },
                                    leadingIcon = {
                                        if (mode == sortMode) Icon(Icons.Default.Check, contentDescription = null)
                                    },
                                )
                            }
                        }
                    }
                    IconButton(onClick = { viewModel.forceRefresh() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Rafraîchir")
                    }
                },
            )
        },
        bottomBar = {
            MiniPlayerBar(
                onOpen = onBookClick,
                sharedTransitionScope = sharedTransitionScope,
                animatedVisibilityScope = animatedVisibilityScope,
            )
        },
        floatingActionButton = {
            if (canAddTorrent) {
                FloatingActionButton(
                    onClick = onAddTorrentClick,
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Ajouter un livre")
                }
            }
        },
        floatingActionButtonPosition = FabPosition.End,
    ) { padding ->
        when {
            !configured -> NoSourceContent(
                padding = padding,
                onConfigureClick = onNavigateToSettings,
                onEnableDemo = { onEnableDemo(); viewModel.refresh() },
            )

            else -> when (val s = state) {
                LibraryUiState.Loading -> LoadingContent(padding)

                is LibraryUiState.Failed -> StatusContent(
                    padding = padding,
                    icon = Icons.Default.Warning,
                    isError = true,
                    title = "Connexion impossible",
                    message = s.message,
                    onRetry = { viewModel.forceRefresh() },
                    onConfigureClick = onNavigateToSettings,
                )

                is LibraryUiState.Loaded -> if (s.books.isEmpty() && !s.refreshing) {
                    StatusContent(
                        padding = padding,
                        icon = Icons.Default.Info,
                        isError = false,
                        title = "Aucun livre détecté",
                        message = "La source est connectée, mais aucun livre n\'a été trouvé. " +
                            "Structure attendue : un dossier par livre contenant vos fichiers audio " +
                            "(mp3, m4a, m4b…). Sur AllDebrid, vos dossiers sont sous /links/.",
                        onRetry = { viewModel.forceRefresh() },
                        onConfigureClick = onNavigateToSettings,
                    )
                } else {
                    // remember: this ran on EVERY recomposition (each scroll
                    // frame) instead of once per library emission.
                    val inProgress = remember(s.books) {
                        s.books
                            .filter { (_, p) -> p != null && !p.isFinished }
                            .sortedByDescending { it.second?.updatedAt }
                            .take(8)
                    }

                    // v0.8.0 — accent-insensitive: typing "energie" used to
                    // miss "Énergie", "voeu" missed "Vœu" (ligature). The same
                    // normaliser as the Audible matcher is used on both sides.
                    val q = MetadataMatcher.normalize(query)
                    val visible = remember(s.books, q, statusFilter, sortMode) {
                        val filtered = s.books.filter { (book, p) ->
                            val okStatus = when (statusFilter) {
                                StatusFilter.ALL -> true
                                StatusFilter.ONGOING -> p != null && !p.isFinished
                                StatusFilter.UNSTARTED -> p == null || (!p.isFinished && p.positionMs <= 0L)
                                StatusFilter.FINISHED -> p?.isFinished == true
                            }
                            val okQuery = q.isEmpty() ||
                                MetadataMatcher.normalize(book.title).contains(q) ||
                                book.author?.let { MetadataMatcher.normalize(it).contains(q) } == true ||
                                book.narrator?.let { MetadataMatcher.normalize(it).contains(q) } == true ||
                                book.series?.let { MetadataMatcher.normalize(it).contains(q) } == true ||
                                MetadataMatcher.normalize(book.source.path).contains(q)
                            okStatus && okQuery
                        }
                        // Saga-aware ordering: books sharing a series stay together
                        // (and in volume order) even when their torrent names differ.
                        val sorted = when (sortMode) {
                            SortMode.TITLE -> filtered.sortedWith(
                                compareBy<Pair<Audiobook, ListeningProgress?>, String>(String.CASE_INSENSITIVE_ORDER) {
                                    it.first.series ?: it.first.title
                                }
                                    .thenBy { it.first.seriesIndex ?: 0.0 }
                                    .thenBy(String.CASE_INSENSITIVE_ORDER) { it.first.title },
                            )
                            SortMode.SERIES -> filtered.sortedWith(
                                compareBy<Pair<Audiobook, ListeningProgress?>, String>(String.CASE_INSENSITIVE_ORDER) {
                                    it.first.series ?: it.first.title
                                }
                                    .thenBy { it.first.seriesIndex ?: 0.0 }
                                    .thenBy(String.CASE_INSENSITIVE_ORDER) { it.first.title },
                            )
                            SortMode.RECENT -> filtered.sortedByDescending { it.second?.updatedAt }
                            SortMode.PROGRESS -> filtered.sortedByDescending { it.second?.fraction ?: 0.0 }
                        }
                        when (sortMode) {
                            SortMode.TITLE -> sorted
                                .groupBy { ((it.first.series ?: it.first.title).firstOrNull()?.uppercaseChar() ?: '#').toString() }
                                .toList()
                            SortMode.SERIES -> sorted
                                .groupBy { it.first.series ?: "Hors série" }
                                .toList()
                            else -> listOf(null to sorted)
                        }
                    }
                    val showContinue = q.isEmpty() && statusFilter == StatusFilter.ALL && sortMode == SortMode.TITLE

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        modifier = Modifier.fillMaxSize().padding(padding),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        // Search + filter scroll away with the content
                        item(span = { GridItemSpan(maxLineSpan) }, key = "search") {
                            OutlinedTextField(
                                value = query,
                                onValueChange = { query = it },
                                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                                singleLine = true,
                                placeholder = { Text("Rechercher…") },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                                trailingIcon = {
                                    if (query.isNotEmpty()) {
                                        IconButton(onClick = { query = "" }) {
                                            Icon(Icons.Default.Clear, contentDescription = "Effacer")
                                        }
                                    }
                                },
                            )
                        }
                        item(span = { GridItemSpan(maxLineSpan) }, key = "filter") {
                            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
                                StatusFilter.entries.forEachIndexed { index, filter ->
                                    SegmentedButton(
                                        selected = statusFilter == filter,
                                        onClick = {
                                            statusFilter = filter
                                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        },
                                        shape = SegmentedButtonDefaults.itemShape(index = index, count = StatusFilter.entries.size),
                                        label = { Text(filter.label, maxLines = 1, style = MaterialTheme.typography.labelSmall) },
                                    )
                                }
                            }
                        }
                        if (s.refreshing) {
                            item(span = { GridItemSpan(maxLineSpan) }, key = "refreshing") {
                                LinearProgressIndicator(Modifier.fillMaxWidth())
                            }
                        }
                        report?.let { msg ->
                            item(span = { GridItemSpan(maxLineSpan) }, key = "enrich-report") {
                                Surface(
                                    color = MaterialTheme.colorScheme.secondaryContainer,
                                    shape = MaterialTheme.shapes.medium,
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    Row(
                                        Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        Text(
                                            msg,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                                            modifier = Modifier.weight(1f),
                                        )
                                        TextButton(onClick = viewModel::dismissReport) { Text("OK") }
                                    }
                                }
                            }
                        }
                        s.error?.let { msg ->
                            item(span = { GridItemSpan(maxLineSpan) }, key = "error-banner") {
                                Surface(
                                    color = MaterialTheme.colorScheme.errorContainer,
                                    shape = MaterialTheme.shapes.medium,
                                    modifier = Modifier.fillMaxWidth().clickable { viewModel.forceRefresh() },
                                ) {
                                    Row(
                                        Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        Icon(Icons.Default.Warning, null, tint = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.size(18.dp))
                                        Text(
                                            "Échec — $msg (cache affiché). Toucher pour réessayer.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onErrorContainer,
                                        )
                                    }
                                }
                            }
                        }
                            // "Reprendre" carousel
                            if (showContinue && inProgress.isNotEmpty()) {
                                item(span = { GridItemSpan(maxLineSpan) }, key = "continue-header") {
                                    Text(
                                        "Reprendre",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(bottom = 8.dp, top = 4.dp),
                                    )
                                }
                                item(span = { GridItemSpan(maxLineSpan) }, key = "continue-row") {
                                    ContinueRow(
                                        entries = inProgress,
                                        onOpen = { book ->
                                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                            onBookClick(book.id, book.title, book.author)
                                        },
                                    )
                                }
                            }

                            // Section header
                            item(span = { GridItemSpan(maxLineSpan) }, key = "all-header") {
                                Text(
                                    if (q.isEmpty() && statusFilter == StatusFilter.ALL) {
                                        "Tous les livres (${s.books.size})"
                                    } else {
                                        "${visible.sumOf { it.second.size }} résultat(s)"
                                    },
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(top = 12.dp, bottom = 4.dp),
                                )
                            }

                            if (visible.isEmpty() || visible.all { it.second.isEmpty() }) {
                                item(span = { GridItemSpan(maxLineSpan) }, key = "no-result") {
                                    Text(
                                        if (q.isEmpty()) "Aucun livre dans cette catégorie."
                                        else "Aucun résultat pour « $query ».",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(vertical = 24.dp),
                                    )
                                }
                            }

                            visible.forEach { (header, entries) ->
                                if (header != null && entries.isNotEmpty()) {
                                    item(span = { GridItemSpan(maxLineSpan) }, key = "h:$header") {
                                        Text(
                                            header,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.padding(top = 16.dp, bottom = 4.dp),
                                        )
                                    }
                                }
                                entries.forEach { (book, progress) ->
                                    item(key = book.id) {
                                        BookGridItem(
                                            book = book,
                                            progress = progress,
                                            onClick = {
                                                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                                onBookClick(book.id, book.title, book.author)
                                            },
                                            onLongClick = {
                                                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                                viewModel.onBookLongPress(book)
                                            },
                                            hasRealDuration = (viewModel.metadataOf(book.id)?.runtimeMin ?: 0) > 0,
                                        )
                                    }
                                }
                            }

                            if (s.refreshing) {
                                item(span = { GridItemSpan(maxLineSpan) }, key = "scanning") {
                                    Text(
                                        "Recherche des livres en cours…",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                    )
                                }
                            }
                            s.note?.let { note ->
                                item(span = { GridItemSpan(maxLineSpan) }, key = "note") {
                                    Text(
                                        note,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                    )
                                }
                            }
                        }
                }
            }
        }
    }
}

/** Grid card: cover on top, title + author + progress below. */
@Composable
@OptIn(ExperimentalFoundationApi::class)
private fun BookGridItem(
    book: Audiobook,
    progress: ListeningProgress?,
    onClick: () -> Unit,
    onLongClick: () -> Unit = {},
    hasRealDuration: Boolean = false,
) {
    Card(
        modifier = Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLongClick),
        shape = MaterialTheme.shapes.large,
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column {
            CoverImage(
                url = book.coverUrl,
                size = 160.dp,
                modifier = Modifier.fillMaxWidth().height(160.dp),
            )
            Column(Modifier.padding(10.dp)) {
                Text(
                    book.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                book.author?.let {
                    Text(
                        it,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (progress != null && !progress.isFinished) {
                    LinearProgressIndicator(
                        progress = { progress.fraction.toFloat() },
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp).height(3.dp),
                    )
                    Text(
                        TimeFmt.formatPercent(progress.fraction),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 2.dp),
                    )
                } else if (progress?.isFinished == true) {
                    Text(
                        "Terminé ✓",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                } else {
                    Text(
                        // Size-based estimate (assumes ~128 kbps): shown as
                        // approximate — unless Audible provided the real
                        // runtime. AllDebrid reports no sizes: say so instead
                        // of a useless "~ 0 min".
                        when {
                            hasRealDuration -> TimeFmt.formatCoarse(book.durationMs)
                            book.durationMs < 60_000 -> "durée inconnue"
                            else -> "~ " + TimeFmt.formatCoarse(book.durationMs)
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                }
            }
        }
    }
}

/** Horizontal "keep listening" carousel. */
@Composable
private fun ContinueRow(
    entries: List<Pair<Audiobook, ListeningProgress?>>,
    onOpen: (Audiobook) -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        entries.forEach { (book, progress) ->
            Card(
                modifier = Modifier.width(140.dp).clickable { onOpen(book) },
                shape = MaterialTheme.shapes.large,
            ) {
                Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    CoverImage(
                        url = book.coverUrl,
                        size = 124.dp,
                        modifier = Modifier.align(Alignment.CenterHorizontally),
                    )
                    Text(
                        book.title,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    val fraction = progress?.fraction ?: 0.0
                    LinearProgressIndicator(
                        progress = { fraction.toFloat() },
                        modifier = Modifier.fillMaxWidth().height(3.dp),
                    )
                    Text(
                        TimeFmt.formatPercent(fraction),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

/**
 * Bottom bar shown while a book plays in the background.
 * Cover morphs into the full-screen player via [SharedTransitionScope.sharedElement].
 */
@OptIn(ExperimentalSharedTransitionApi::class)
@Composable
private fun MiniPlayerBar(
    onOpen: (String, String, String?) -> Unit,
    sharedTransitionScope: SharedTransitionScope? = null,
    animatedVisibilityScope: AnimatedVisibilityScope? = null,
) {
    val nowPlaying by PlaybackBus.nowPlaying.collectAsStateWithLifecycle()
    val np = nowPlaying ?: return
    val context = LocalContext.current
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }

    DisposableEffect(np.bookId) {
        val future = MediaController.Builder(
            context,
            SessionToken(context, ComponentName(context, PlaybackService::class.java)),
        ).buildAsync()
        future.addListener({
            runCatching { future.get() }.getOrNull()?.let {
                controller = it
                isPlaying = it.isPlaying
            }
        }, ContextCompat.getMainExecutor(context))
        onDispose {
            MediaController.releaseFuture(future)
            controller = null
        }
    }

    LaunchedEffect(controller) {
        val c = controller ?: return@LaunchedEffect
        while (true) {
            isPlaying = c.isPlaying
            positionMs = c.currentPosition.coerceAtLeast(0L)
            durationMs = c.duration.takeIf { it > 0 } ?: 0L
            kotlinx.coroutines.delay(500)
        }
    }

    val fraction = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f

    val coverModifier: Modifier = if (sharedTransitionScope != null && animatedVisibilityScope != null) {
        with(sharedTransitionScope) {
            Modifier.sharedElement(
                rememberSharedContentState(key = "cover-${np.bookId}"),
                animatedVisibilityScope = animatedVisibilityScope,
            )
        }
    } else {
        Modifier
    }

    Surface(tonalElevation = 3.dp) {
        Box(Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpen(np.bookId, np.title, np.artist) }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                CoverImage(url = np.coverUrl, size = 42.dp, modifier = coverModifier)
                Text(
                    np.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                FilledIconButton(
                    onClick = {
                        val c = controller ?: return@FilledIconButton
                        if (c.isPlaying) c.pause() else c.play()
                        isPlaying = c.isPlaying
                    },
                    modifier = Modifier.size(40.dp),
                ) {
                    Icon(
                        if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Lecture",
                        modifier = Modifier.size(22.dp),
                    )
                }
            }
            Box(
                Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth(fraction)
                    .height(2.dp)
                    .background(MaterialTheme.colorScheme.primary),
            )
        }
    }
}

@Composable
private fun NoSourceContent(
    padding: PaddingValues,
    onConfigureClick: () -> Unit,
    onEnableDemo: () -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(
            Icons.Default.Cloud,
            contentDescription = null,
            modifier = Modifier.size(56.dp),
            tint = MaterialTheme.colorScheme.primary,
        )
        Text(
            "Aucune source configurée",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(top = 16.dp),
        )
        Text(
            "Connectez un stockage cloud (WebDAV, Nextcloud, ownCloud) pour voir vos livres, " +
                "ou explorez la bibliothèque de démonstration.",
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(vertical = 12.dp),
        )
        Button(onClick = onConfigureClick, modifier = Modifier.fillMaxWidth()) {
            Text("Configurer une source")
        }
        OutlinedButton(
            onClick = onEnableDemo,
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        ) { Text("Explorer la bibliothèque de démo") }
    }
}

@Composable
private fun LoadingContent(padding: PaddingValues) {
    Column(
        modifier = Modifier.fillMaxSize().padding(padding),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        CircularProgressIndicator(modifier = Modifier.size(32.dp))
        Text(
            "Chargement de votre bibliothèque…",
            modifier = Modifier.padding(top = 16.dp),
            style = MaterialTheme.typography.bodyMedium,
        )
    }
}

@Composable
private fun StatusContent(
    padding: PaddingValues,
    icon: ImageVector,
    isError: Boolean,
    title: String,
    message: String,
    onRetry: () -> Unit,
    onConfigureClick: () -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(
            icon,
            contentDescription = null,
            modifier = Modifier.size(48.dp),
            tint = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
        )
        Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 16.dp))
        Text(
            message,
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(vertical = 12.dp),
        )
        Button(onClick = onRetry, modifier = Modifier.fillMaxWidth()) { Text("Réessayer") }
        OutlinedButton(
            onClick = onConfigureClick,
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        ) { Text("Modifier la source") }
    }
}


/** "Pick the edition" sheet: scored Audible candidates for one book. */
@Composable
private fun MatchCandidatesDialog(
    options: List<Pair<BookMetadata, Double>>,
    onPick: (BookMetadata) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choisir l'édition") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    "Plusieurs éditions Audible correspondent : touchez la bonne.",
                    style = MaterialTheme.typography.bodySmall,
                )
                options.forEach { (meta, score) ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPick(meta) }
                            .padding(vertical = 10.dp),
                    ) {
                        Text(meta.title, style = MaterialTheme.typography.titleSmall)
                        Text(
                            buildString {
                                append(meta.authors.joinToString(", ").ifBlank { "auteur inconnu" })
                                meta.narrators.firstOrNull()?.let { append(" — lu par $it") }
                                if (meta.releaseYear > 0) append(" · ${meta.releaseYear}")
                                if (meta.runtimeMin > 0) append(" · ${meta.runtimeMin / 60} h ${meta.runtimeMin % 60}")
                                append(" · confiance ${(score * 100).toInt()} %")
                            },
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    HorizontalDivider()
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}

/** Book fiche: everything Audible told us about this book. */
@Composable
private fun BookFicheDialog(
    meta: BookMetadata,
    onOther: () -> Unit,
    onSearch: () -> Unit,
    onRemove: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(meta.title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (meta.authors.isNotEmpty()) Text(meta.authors.joinToString(", "), style = MaterialTheme.typography.titleSmall)
                if (meta.narrators.isNotEmpty()) Text("Lu par ${meta.narrators.joinToString(", ")}", style = MaterialTheme.typography.bodySmall)
                Text(
                    buildString {
                        append("Source : Audible.${meta.market}")
                        if (meta.releaseYear > 0) append(" · ${meta.releaseYear}")
                        if (meta.runtimeMin > 0) append(" · ${meta.runtimeMin / 60} h ${meta.runtimeMin % 60}")
                        if (meta.rating > 0) append(" · note %.1f/5".format(meta.rating))
                        meta.publisher?.let { append(" · $it") }
                        meta.seriesName?.let { append(" · $it") }
                    },
                    style = MaterialTheme.typography.bodySmall,
                )
                meta.summary?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, style = MaterialTheme.typography.bodyMedium)
                }
            }
        },
        confirmButton = {
            Row {
                TextButton(onClick = onSearch) { Text("Rechercher") }
                TextButton(onClick = onOther) { Text("Autre édition") }
                TextButton(onClick = onRemove) { Text("Retirer") }
                TextButton(onClick = onDismiss) { Text("Fermer") }
            }
        },
    )
}

/**
 * "Rechercher sur Audible" — the manual escape hatch added in v0.7.0.
 *
 * The automatic ladder still misses some books (uploader-only saga names,
 * mangled authors, translations whose French title has no Audible edition).
 * Here the user types what they know — title, saga, author, or a 10-character
 * ASIN — and picks among the scored editions returned by the same engine.
 */
@Composable
private fun AudibleSearchDialog(
    state: LibraryViewModel.LibraryDialog.Search,
    onSearch: (String, String) -> Unit,
    onPick: (BookMetadata) -> Unit,
    onDismiss: () -> Unit,
) {
    var query by rememberSaveable(state.bookId) { mutableStateOf(state.query) }
    var author by rememberSaveable(state.bookId) { mutableStateOf(state.author) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Rechercher sur Audible") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Titre, saga ou ASIN") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = author,
                    onValueChange = { author = it },
                    label = { Text("Auteur (optionnel)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(10.dp))
                OutlinedButton(
                    onClick = { onSearch(query, author) },
                    enabled = !state.busy && query.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    if (state.busy) {
                        CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("Recherche…")
                    } else {
                        Text("Rechercher")
                    }
                }
                state.error?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, style = MaterialTheme.typography.bodySmall)
                }
                if (state.results.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "${state.results.size} édition(s) — touchez la bonne",
                        style = MaterialTheme.typography.labelMedium,
                    )
                    state.results.forEach { (meta, score) ->
                        AudibleResultRow(meta, score) { onPick(meta) }
                        HorizontalDivider()
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fermer") } },
    )
}

/** One scored edition in the manual search results. */
@Composable
private fun AudibleResultRow(meta: BookMetadata, score: Double, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
    ) {
        Text(meta.title, style = MaterialTheme.typography.titleSmall)
        Text(
            buildString {
                append(meta.authors.joinToString(", ").ifBlank { "auteur inconnu" })
                meta.narrators.firstOrNull()?.let { append(" — lu par $it") }
                if (meta.releaseYear > 0) append(" · ${meta.releaseYear}")
                if (meta.runtimeMin > 0) append(" · ${meta.runtimeMin / 60} h ${meta.runtimeMin % 60}")
                meta.seriesLabel?.let { append(" · $it") }
                meta.language?.let { append(" · $it") }
                append(" · ${meta.market.uppercase(Locale.ROOT)} · confiance ${(score * 100).toInt()} %")
            },
            style = MaterialTheme.typography.bodySmall,
        )
    }
}
