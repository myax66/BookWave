package dev.bookwave.app.data.metadata

import android.content.Context
import android.os.Handler
import android.os.HandlerThread
import dev.bookwave.core.metadata.BookMetadata
import dev.bookwave.core.metadata.SeriesRef
import dev.bookwave.core.model.Audiobook
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * On-disk cache of resolved Audible metadata, keyed by book id, plus a
 * "tried" ledger: books with NO Audible equivalent (most torrent-only sagas)
 * are remembered for [TRIED_TTL_MS] so the background pass spends its budget
 * on books that can actually match instead of re-probing the same misses.
 */
class MetadataStore(context: Context) {

    companion object {
        const val TRIED_TTL_MS = 7L * 86_400_000L
        /** Hard ceiling: a huge library must not turn this file into a leak. */
        private const val MAX_ENTRIES = 5_000
        private const val TRIED_KEY = "_tried"

        /** A burst of resolutions collapses into one disk write per window. */
        private const val FLUSH_DELAY_MS = 700L
    }

    private val file = File(context.filesDir, "metadata-cache.json")

    /**
     * v0.8.0 — coalesced writes.
     *
     * Every resolved book used to rewrite the WHOLE file (up to 5 000 entries,
     * each carrying an Audible summary): a 60-book pass serialised tens of
     * megabytes and re-parsed the file on each read. Mutations now update the
     * in-memory cache, bump [version] immediately (the UI stays live) and only
     * schedule a disk write; bursts collapse into one write every
     * [FLUSH_DELAY_MS], and [flushNow] forces one when a pass ends.
     */
    private val flushThread = HandlerThread("bookwave-metadata-flush").apply { start() }
    private val flushHandler = Handler(flushThread.looper)
    private val pendingFlush = Runnable { flushNow() }

    /** Bumped on every write so UI flows re-merge without a rescan. */
    private val _version = MutableStateFlow(0)
    val version: StateFlow<Int> = _version

    private class Cache(
        val metas: MutableMap<String, BookMetadata>,
        val tried: MutableMap<String, Long>,
    )

    private var memo: Cache? = null

    @Synchronized
    private fun cache(): Cache = memo ?: read().also { memo = it }

    fun all(): Map<String, BookMetadata> = cache().metas

    /**
     * v0.8.0 — parses the cache NOW, off the main thread.
     *
     * [cache] reads and parses the whole file on first access. Called from
     * `LibraryViewModel.init` (main thread), that was a cold-start stall
     * proportional to the number of resolved books — up to a few MB of JSON
     * with Audible summaries. The application warms it on Dispatchers.IO
     * before any screen can ask for [of].
     */
    fun warmUp() {
        cache()
    }

    fun of(bookId: String): BookMetadata? = cache().metas[bookId]

    fun triedRecently(bookId: String, ttlMs: Long = TRIED_TTL_MS): Boolean {
        val at = cache().tried[bookId] ?: return false
        return System.currentTimeMillis() - at < ttlMs
    }

    @Synchronized
    fun markTried(bookId: String) {
        cache().tried[bookId] = System.currentTimeMillis()
        touch()
    }

    @Synchronized
    fun clearTried() {
        val c = cache()
        if (c.tried.isNotEmpty()) {
            c.tried.clear()
            touch()
        }
    }

    @Synchronized
    fun put(bookId: String, meta: BookMetadata) {
        val c = cache()
        c.metas[bookId] = meta.copy(savedAt = System.currentTimeMillis())
        c.tried.remove(bookId)
        touch()
    }

    /** Explicit removal is rare and user-driven: write through immediately. */
    @Synchronized
    fun remove(bookId: String) {
        val c = cache()
        if (c.metas.remove(bookId) != null) {
            _version.value++
            flushHandler.removeCallbacks(pendingFlush)
            write(c)
        }
    }

    /**
     * v0.8.0 — batching. An identification pass resolves books every second or
     * so; the 700 ms debounce alone still let each of those rewrite the whole
     * file (2 000 entries × ~2 KB = ~4 MB, 60 times). Inside [batch] no write
     * is scheduled at all: ONE serialisation happens at the end.
     *
     * Safe by construction: the batch is closed in a `finally`, so a crashing
     * pass still persists what it resolved.
     */
    @Volatile
    private var batching = false

    @Synchronized
    fun beginBatch() {
        batching = true
        flushHandler.removeCallbacks(pendingFlush)
    }

    @Synchronized
    fun endBatch() {
        batching = false
        flushHandler.removeCallbacks(pendingFlush)
        write(cache())
    }

    /** Runs [block] with writes batched, flushing even when it throws. */
    fun <T> batch(block: () -> T): T {
        beginBatch()
        return try {
            block()
        } finally {
            endBatch()
        }
    }

    /** UI re-merges at once; the disk write is debounced. */
    private fun touch() {
        _version.value++
        if (batching) return
        flushHandler.removeCallbacks(pendingFlush)
        flushHandler.postDelayed(pendingFlush, FLUSH_DELAY_MS)
    }

    /** Forces the pending write (end of an enrichment pass, app backgrounded). */
    @Synchronized
    fun flushNow() {
        flushHandler.removeCallbacks(pendingFlush)
        write(cache())
    }

    /** Official metadata wins where present; torrent cleaning remains the fallback. */
    fun merge(book: Audiobook): Audiobook {
        val meta = of(book.id) ?: return book
        return book.copy(
            title = meta.title.ifBlank { book.title },
            author = meta.authors.joinToString(", ").ifBlank { book.author },
            series = meta.seriesName ?: book.series,
            seriesIndex = meta.seriesIndex ?: book.seriesIndex,
            coverUrl = meta.coverUrl ?: book.coverUrl,
            durationMs = if (meta.runtimeMin > 0) meta.runtimeMin * 60_000L else book.durationMs,
        )
    }

    private fun write(c: Cache) {
        runCatching {
            // Housekeeping on every write: drop ledger rows older than a month
            // and the least recently saved metadata above the ceiling.
            val now = System.currentTimeMillis()
            c.tried.entries.removeIf { now - it.value > 30L * 86_400_000L }
            if (c.metas.size > MAX_ENTRIES) {
                val keep = c.metas.entries.sortedByDescending { it.value.savedAt }.take(MAX_ENTRIES)
                c.metas.clear()
                keep.forEach { (id, meta) -> c.metas[id] = meta }
            }
            val root = JSONObject()
            c.metas.forEach { (id, m) -> root.put(id, encode(m)) }
            val tried = JSONObject()
            c.tried.forEach { (id, at) -> tried.put(id, at) }
            root.put(TRIED_KEY, tried)
            val tmp = File(file.parentFile, file.name + ".tmp")
            tmp.writeText(root.toString())
            if (!tmp.renameTo(file)) {
                file.writeText(root.toString())
                tmp.delete()
            }
        }
    }

    private fun read(): Cache = runCatching {
        val c = Cache(mutableMapOf(), mutableMapOf())
        if (!file.exists()) return c
        val root = JSONObject(file.readText())
        val tried = root.optJSONObject(TRIED_KEY)
        if (tried != null) {
            for (key in tried.keys()) c.tried[key] = tried.optLong(key)
        }
        for (key in root.keys()) {
            if (key == TRIED_KEY) continue
            runCatching { c.metas[key] = decode(key, root.getJSONObject(key)) }
        }
        c
    }.getOrDefault(Cache(mutableMapOf(), mutableMapOf()))

    private fun encode(m: BookMetadata): JSONObject = JSONObject().apply {
        put("asin", m.asin)
        put("market", m.market)
        put("title", m.title)
        m.subtitle?.let { put("subtitle", it) }
        put("authors", JSONArray(m.authors))
        put("narrators", JSONArray(m.narrators))
        m.seriesName?.let { put("seriesName", it) }
        m.seriesIndex?.let { put("seriesIndex", it) }
        if (m.seriesEntries.isNotEmpty()) {
            put("seriesEntries", JSONArray().apply {
                m.seriesEntries.forEach { entry ->
                    put(JSONObject().apply {
                        put("name", entry.name)
                        entry.index?.let { put("index", it) }
                    })
                }
            })
        }
        put("runtimeMin", m.runtimeMin)
        m.publisher?.let { put("publisher", it) }
        put("releaseYear", m.releaseYear)
        m.summary?.let { put("summary", it) }
        m.coverUrl?.let { put("coverUrl", it) }
        put("rating", m.rating)
        m.language?.let { put("language", it) }
        put("savedAt", m.savedAt)
    }

    private fun decode(id: String, o: JSONObject): BookMetadata = BookMetadata(
        asin = o.optString("asin", id),
        market = o.optString("market", "fr"),
        title = o.optString("title"),
        subtitle = o.optString("subtitle").takeIf { it.isNotBlank() },
        authors = strings(o, "authors"),
        narrators = strings(o, "narrators"),
        seriesName = o.optString("seriesName").takeIf { it.isNotBlank() },
        seriesIndex = if (o.has("seriesIndex")) o.optDouble("seriesIndex") else null,
        seriesEntries = seriesEntries(o),
        runtimeMin = o.optInt("runtimeMin", 0),
        publisher = o.optString("publisher").takeIf { it.isNotBlank() },
        releaseYear = o.optInt("releaseYear", 0),
        summary = o.optString("summary").takeIf { it.isNotBlank() },
        coverUrl = o.optString("coverUrl").takeIf { it.isNotBlank() },
        rating = o.optDouble("rating", 0.0),
        language = o.optString("language").takeIf { it.isNotBlank() },
        savedAt = o.optLong("savedAt", 0L),
    )

    /** v0.7.0 entries carry every Audible series pair; older caches only one. */
    private fun seriesEntries(o: JSONObject): List<SeriesRef> {
        val array = o.optJSONArray("seriesEntries") ?: return emptyList()
        return (0 until array.length()).mapNotNull { i ->
            val entry = array.optJSONObject(i) ?: return@mapNotNull null
            val name = entry.optString("name").takeIf { it.isNotBlank() } ?: return@mapNotNull null
            SeriesRef(name, if (entry.has("index")) entry.optDouble("index") else null)
        }
    }

    private fun strings(o: JSONObject, field: String): List<String> {
        val array = o.optJSONArray(field) ?: return emptyList()
        return (0 until array.length()).mapNotNull { i -> array.optString(i).takeIf { it.isNotBlank() } }
    }
}
