# Bookwave 📚🎧

*Lecteur de livres audio cloud, moderne, pour Android.*

Réinvention de CloudBooks (analysée via REA + JADX) avec un ADN **audiobook** :
chapitres, vitesse par livre persistante, minuteur « fin de chapitre »,
catalogue Torznab (C411 / TR4KER) + AllDebrid, progression synchronisée entre
appareils via un fichier sidecar WebDAV.

## Structure

```
core/   Kotlin pur — modèles et logique (chapitres, progression, sync, minuteur,
        nettoyage de titres torrent, ordre naturel des pistes)
        ✅ 108 tests unitaires
app/    Android — Compose + Media3 + connecteurs cloud (WebDAV/AllDebrid) +
        catalogue Torznab + WorkManager (sync de progression)
```

## Démarrage

1. Ouvrir le dossier dans **Android Studio** (Ladybug ou plus récent).
   ⚠️ Le **wrapper Gradle n'est pas inclus** : laissez Android Studio utiliser
   son Gradle (8.10.2+) ou générez le wrapper (`gradle wrapper`).
2. ⚠️ `gradle.properties` est calibré pour un **bac à sable de build à mémoire
   limitée** (Xmx800m, `workers.max=1`, compilation incrémentale désactivée).
   Sur une machine de dev normale, supprimer ces contraintes accélère
   énormément les builds.
3. `gradle :core:test` — tests du domaine
4. `gradle :app:assembleDebug` — APK de débogage
5. ⚠️ **Avant toute livraison** : `tools/check-regex-icu.sh` — vérifie que chaque
   `Regex(...)` du projet compile avec **ICU** (le moteur d'Android). La JVM des
   tests accepte des motifs qu'Android rejette : la v0.7.0 a planté en production
   sur `\{[^}]*}` (« Syntax error in regexp pattern near index 8 ») alors que les
   tests étaient verts.

### Configurer une source

Tout se règle dans l'onglet **Réglages** de l'app (persisté par
`app/src/main/kotlin/dev/bookwave/app/data/AppSettings.kt`, préférences
`bookwave`) :

- **WebDAV / Nextcloud / ownCloud** : URL, identifiant, mot de passe/jeton.
- **AllDebrid** : URL `https://webdav.debrid.it/`, identifiant = clé API,
  mot de passe = `eeeeee` (l'app complète automatiquement).
- **Catalogue** : clés API Torznab C411 et TR4KER.

## Sécurité

- Aucun composant `exported=true` sauf le launcher (CloudBooks en exposait 11).
- Aucune clé en dur dans le binaire (CloudBooks embarquait sa Dropbox key).
- `allowBackup="false"` : les identifiants (SharedPreferences non chiffrés)
  ne partent PAS dans la sauvegarde cloud Google.
- Parsing XML durci contre XXE (WebDAV) ; les .torrent téléchargés portent le
  passkey du membre — ne jamais les partager.
- `debug.keystore` n'est **pas inclus dans le dépôt public**. Si des APK déjà
  installés doivent recevoir une mise à jour sans désinstallation, conservez la
  clé de débogage d'origine uniquement sur votre machine, à la racine du projet :
  elle est ignorée par Git. Sans cette clé, Android Studio utilise sa clé de
  débogage par défaut et la signature sera différente. Pour une publication sur
  un store, utilisez une clé release dédiée, sauvegardée hors du dépôt.

## État des fonctionnalités

- [x] **Fondations** — `core` (modèles, chapitres, fusion de progression, minuteur) + tests
- [x] **Lecture** — `PlaybackService` Media3, écran Lecteur (vitesse/minuteur/chapitres),
      reprise précise, **sauvegarde de la progression côté service** (l'écoute en
      arrière-plan survit à la mort du processus), erreurs de flux affichées
- [x] **Cloud** — WebDAV/AllDebrid, scan borné et parallèle, cache disque, couvertures
      embarquées extraites côté client
- [x] **Catalogue** — Torznab C411/TR4KER (derniers ajouts + recherche), envoi
      .torrent → AllDebrid en un tap, suivi des transferts
- [x] **Métadonnées réelles** — identification dans le catalogue Audible (API publique,
      sans clé) : titre/auteur officiels, narrateur, durée réelle, couverture officielle,
      résumé, note ; matching scoré (auto ≥ 0,75, choix de l'édition entre 0,50 et 0,75),
      cache local, appui long = fiche / autre édition / retrait.
- [x] **Recherche Audible v0.7.0** — échelle de requêtes mesurée sur l'API (`title=`
      pour saga+tome, `keywords` en repli), résultats **poolés** et classés localement,
      retry sans auteur (Audible ET-ait le filtre `author`), toutes les séries prises en
      compte, noms « (French Edition) » normalisés, pénalité de langue, cache de requêtes,
      sortie anticipée dès 0,75 (1-2 requêtes par livre) et **feuille « Rechercher sur
      Audible »** (titre, saga, auteur ou ASIN) pour rattraper les faux négatifs.
      Chapitres Audible : plus tard
- [x] **v0.7.1** — correctif du crash regex ICU, nettoyage des tags `M4B-K`,
      découpe « Auteur - Titre » pour la recherche (L'Ensoleillé de Sanderson :
      0,41 → 0,85), et saga extraite du préfixe auteur. Vérification ICU outillée.
- [x] **v0.8.0** — audit général : passe d'identification qui ne s'arrête plus au
      premier échec réseau, écritures de métadonnées groupées, fusion O(n),
      lecteur à cadence adaptative, réessais HTTP avec backoff, recherche
      insensible aux accents (voir `audit-general-v0.8.0.md`).
- [x] **v0.7.4** — recherche reconstruite : requêtes par segments (saga, sous-titre,
      mots-clés courts), plus de filtre `author` en ET, **balayage du catalogue de
      l'auteur** en dernier recours, score symétrique, parties « 1.1/1.2 »,
      ligatures `œ`. Corpus de 18 dossiers réels : **18/18 auto-appliqués**.
- [x] **v0.7.3** — auteur en tête **sans tiret** (« Brandon Sanderson L Ensoleille »),
      score protégé contre un nom resté dans le titre, message d'échec qui liste
      les requêtes réellement envoyées.
- [x] **v0.7.2** — auteur en fin de nom (« … - Joe Abercrombie ») et tome au milieu
      (« L'Âge de la Folie 03 … ») détectés ; requête « derniers mots du titre » ;
      audit général du code : intents validés, caches disque plafonnés, hash de
      pochette stable, message d'échec lisible (voir `audit-general-v0.7.2.md`).
- [x] **Sync multi-appareils** — fichier `.bookwave-progress.json` sur le WebDAV,
      fusion déterministe, worker périodique (30 min, réseau requis) planifié au
      démarrage. ⚠️ Non testée contre un vrai serveur multi-appareils ; un compte
      AllDebrid (WebDAV probablement en lecture seule) ne pourra pas l'héberger.
- [ ] **Restes de la feuille de route** — téléchargements hors-ligne, probing des
      durées réelles (les durées affichées sont estimées « ~ » à partir de la
      taille), chapitres m4b embarqués, Android Auto, widget, signets

## Choix techniques

| Sujet | Choix | Pourquoi |
|---|---|---|
| UI | Jetpack Compose + Material 3 | Moderne, dynamic color, adapté aux foldables |
| Lecture | Media3 `MediaSessionService` | Standard Android, Bluetooth/notification gratuits |
| Audio | `CONTENT_TYPE_SPEECH`, skip silence OFF, `WAKE_MODE_NETWORK` | Voix lue : les pauses font partie du texte ; les livres streament |
| Cloud | Interface `CloudSource` + WebDAV | Auto-hébergé + AllDebrid, sans SDK propriétaire |
| Sync | Fusion déterministe côté client (`core/sync`) | Converge sans serveur, testé |
| DI | Koin | Léger, sans KSP |
| Réseau | Un `OkHttpClient` partagé (`util/Http`) + appels annulables (`util/Suspend`) | Un seul pool de connexions ; quitter un écran annule les requêtes |
| Titres | `TitleCleaner` (sagas, auteurs, tomes) + `NaturalOrder` (pistes 1, 2, 10) | Noms de torrent hétérogènes → bibliothèque regroupée |

## Leçons de l'analyse de CloudBooks (dans le code)

- Aucun composant `exported=true` inutile
- Aucune clé OAuth en dur dans le DEX
- Logique premium non patchable côté client (si un achat est ajouté un jour :
  vérification serveur, jamais une constante locale)
