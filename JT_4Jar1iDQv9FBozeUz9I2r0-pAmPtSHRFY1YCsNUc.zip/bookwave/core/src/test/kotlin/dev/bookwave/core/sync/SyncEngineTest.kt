package dev.bookwave.core.sync

import dev.bookwave.core.model.ListeningProgress
import java.time.Instant
import kotlin.test.Test
import kotlin.test.assertEquals

class SyncEngineTest {

    private fun p(bookId: String, pos: Long, deviceId: String, updatedAt: String) =
        ListeningProgress(
            bookId = bookId,
            positionMs = pos,
            durationMs = 100_000,
            updatedAt = Instant.parse(updatedAt),
            deviceId = deviceId,
        )

    @Test
    fun mergesPerBookAndCountsConflicts() {
        val local = SyncPayload(
            deviceId = "phone",
            revision = 1,
            entries = listOf(
                p("a", 10_000, "phone", "2026-10-18T10:00:00Z"),
                p("b", 50_000, "phone", "2026-10-18T10:00:00Z"),
            ),
        )
        val remote = SyncPayload(
            deviceId = "car",
            revision = 4,
            entries = listOf(
                p("a", 20_000, "car", "2026-10-18T09:00:00Z"),
                p("c", 1_000, "car", "2026-10-18T09:30:00Z"),
            ),
        )
        val result = SyncEngine.mergeAll(local, remote)
        assertEquals(listOf("a", "b", "c"), result.merged.map { it.bookId })
        assertEquals(20_000, result.merged.first { it.bookId == "a" }.positionMs)
        assertEquals(1, result.conflictsResolved)
    }

    @Test
    fun identicalRecordsAreNotConflicts() {
        val entry = p("a", 10_000, "phone", "2026-10-18T10:00:00Z")
        val result = SyncEngine.mergeAll(
            SyncPayload("phone", 1, listOf(entry)),
            SyncPayload("car", 1, listOf(entry)),
        )
        assertEquals(0, result.conflictsResolved)
    }

    @Test
    fun `merging 2000 books keeps every id exactly once`() {
        // Guards the v0.8.0 index refactor: a missing id here means a book
        // silently lost its progress during sync.
        val local = (1..1_000).map { p("book$it", it.toLong() * 10, "phone", "2026-10-18T10:00:00Z") }
        val remote = (501..2_000).map { p("book$it", it.toLong() * 20, "car", "2026-10-18T11:00:00Z") }
        val result = SyncEngine.mergeAll(
            SyncPayload("phone", 1, local),
            SyncPayload("car", 2, remote),
        )
        assertEquals(2_000, result.merged.size)
        assertEquals(2_000, result.merged.map { it.bookId }.distinct().size)
        // 500 ids are on both sides → 500 conflicts, resolved on the furthest.
        assertEquals(500, result.conflictsResolved)
        assertEquals(1_000 * 20, result.merged.first { it.bookId == "book1000" }.positionMs)
    }
}
