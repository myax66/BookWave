package dev.bookwave.app.ui.nav

import android.net.Uri
import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionLayout
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import dev.bookwave.app.data.AppSettings
import dev.bookwave.app.data.alldebrid.PendingTorrent
import dev.bookwave.app.ui.add.AddTorrentScreen
import dev.bookwave.app.ui.catalog.CatalogScreen
import dev.bookwave.app.ui.library.LibraryScreen
import dev.bookwave.app.ui.player.PlayerScreen
import dev.bookwave.app.ui.settings.SettingsScreen

object Routes {
    const val LIBRARY = "library"
    const val SETTINGS = "settings"
    const val ADD_TORRENT = "add_torrent"
    const val CATALOG = "catalog"
    const val PLAYER = "player/{bookId}/{title}/{author}"

    /** A blank author travels as one encoded space — an empty last segment
     *  would not match the route pattern. */
    fun player(bookId: String, title: String, author: String?) =
        "player/${Uri.encode(bookId)}/${Uri.encode(title)}/" +
            Uri.encode(author?.takeIf { it.isNotBlank() } ?: " ")

    /** Routes that show the bottom tab bar. */
    val TABS = setOf(LIBRARY, CATALOG, SETTINGS)
}

private data class TabItem(val route: String, val label: String, val icon: @Composable () -> Unit)

/**
 * App navigation — Lot C: bottom tab bar (Bibliothèque / Catalogue / Réglages)
 * with the player and "add torrent" pushed as full-screen destinations.
 *
 * Wrapped in [SharedTransitionLayout] for the mini-bar → player cover morph (Lot B).
 */
@OptIn(ExperimentalSharedTransitionApi::class)
@Composable
fun BookwaveNav(shareTick: Int = 0) {
    val nav = rememberNavController()
    val haptics = LocalHapticFeedback.current

    LaunchedEffect(shareTick) {
        if (PendingTorrent.hasPending() &&
            nav.currentBackStackEntry?.destination?.route != Routes.ADD_TORRENT
        ) {
            nav.navigate(Routes.ADD_TORRENT)
        }
    }

    val backStackEntry by nav.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showTabs = currentRoute in Routes.TABS

    val tabs = listOf(
        TabItem(Routes.LIBRARY, "Bibliothèque") { Icon(Icons.Default.LibraryBooks, contentDescription = null) },
        TabItem(Routes.CATALOG, "Catalogue") { Icon(Icons.Default.Explore, contentDescription = null) },
        TabItem(Routes.SETTINGS, "Réglages") { Icon(Icons.Default.Settings, contentDescription = null) },
    )

    SharedTransitionLayout {
        Scaffold(
            // Each destination applies its own status-bar insets (TopAppBar /
            // systemBars padding). Letting the outer Scaffold add them too drew
            // a doubled empty band under the status bar on every tab.
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            bottomBar = {
                if (showTabs) {
                    NavigationBar {
                        tabs.forEach { tab ->
                            val selected = backStackEntry?.destination?.hierarchy
                                ?.any { it.route == tab.route } == true
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    if (!selected) haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                    nav.navigate(tab.route) {
                                        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = tab.icon,
                                label = { Text(tab.label) },
                            )
                        }
                    }
                }
            },
        ) { padding ->
            NavHost(
                navController = nav,
                startDestination = Routes.LIBRARY,
                modifier = Modifier.padding(padding),
            ) {
                composable(Routes.LIBRARY) {
                    val context = LocalContext.current
                    LibraryScreen(
                        onBookClick = { bookId, title, author ->
                            nav.navigate(Routes.player(bookId, title, author))
                        },
                        onAddTorrentClick = { nav.navigate(Routes.ADD_TORRENT) },
                        onEnableDemo = {
                            AppSettings(context).demoMode = true
                            dev.bookwave.app.data.BookRepository.invalidateCache()
                        },
                        onNavigateToSettings = {
                            nav.navigate(Routes.SETTINGS) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        sharedTransitionScope = this@SharedTransitionLayout,
                        animatedVisibilityScope = this@composable,
                    )
                }
                composable(Routes.CATALOG) {
                    CatalogScreen(
                        onOpenTransfers = { nav.navigate(Routes.ADD_TORRENT) },
                        onOpenSettings = {
                            nav.navigate(Routes.SETTINGS) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                    )
                }
                composable(Routes.SETTINGS) {
                    SettingsScreen()
                }
                composable(Routes.ADD_TORRENT) {
                    AddTorrentScreen(onBack = { nav.popBackStack() })
                }
                composable(
                    Routes.PLAYER,
                    arguments = listOf(
                        navArgument("bookId") { type = NavType.StringType },
                        navArgument("title") { type = NavType.StringType },
                        navArgument("author") { type = NavType.StringType },
                    ),
                ) { entry ->
                    PlayerScreen(
                        bookId = entry.arguments?.getString("bookId").orEmpty(),
                        title = entry.arguments?.getString("title"),
                        author = entry.arguments?.getString("author")?.takeIf { it.isNotBlank() },
                        onBack = { nav.popBackStack() },
                        sharedTransitionScope = this@SharedTransitionLayout,
                        animatedVisibilityScope = this@composable,
                    )
                }
            }
        }
    }
}
