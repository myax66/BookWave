"""
Banc d'essai v0.7.4 — 18 noms de dossiers réels, plan produit par le VRAI
AudibleQueries (exporté par probe/BenchDump), exécuté sur l'API Audible live,
scoré par un port fidèle de MetadataMatcher (couverture symétrique incluse).

Usage : python3 bench_corpus.py [plans.json]
"""
import json, sys, time, urllib.parse, urllib.request
from measure_search import toks, dice, coverage, norm, norm_series, dearticle, Cand, fetch as _fetch

def fetch(mode, text, market="fr", num=20, page=None):
    url = f"https://api.audible.{market}/1.0/catalog/products?" + urllib.parse.urlencode(
        {mode.lower(): text, "num_results": num, "response_groups": "contributors,product_attrs,media,series,product_desc,rating",
         **({"page": page} if page else {})})
    req = urllib.request.Request(url, headers={"User-Agent": "Bookwave/0.7 (audiobook library)"})
    with urllib.request.urlopen(req, timeout=25) as r:
        d = json.load(r)
    out = []
    for p in (d.get("products") or []):
        if not p.get("asin") or not p.get("title"): continue
        authors = [a.get("name") for a in (p.get("authors") or []) if a.get("name")]
        narr = [a.get("name") for a in (p.get("narrators") or []) if a.get("name")]
        series = []
        for s in (p.get("series") or []):
            idx = s.get("sequence") or None
            try: idx = float(idx) if idx not in (None, "") else None
            except ValueError: idx = None
            if s.get("title"): series.append((s["title"], idx))
        c = Cand(p["asin"], p["title"], p.get("subtitle"), authors, narr, series,
                 p.get("runtime_length_min") or 0, p.get("language"), market)
        if not (c.authors or c.narrators or c.runtime): continue
        out.append(c)
    return out

ORDINALS = {"premier":1,"premiere":1,"first":1,"un":1,"second":2,"seconde":2,"deuxieme":2,"two":2,"deux":2,
            "troisieme":3,"third":3,"three":3,"trois":3,"quatrieme":4,"fourth":4,"quatre":4,"cinquieme":5,"fifth":5,"cinq":5}

VOL = {"tome","tomes","volume","volumes","vol","livre","livres","partie","parties","part","book","books","saison","season","episode"}

def part_number(title):
    ts = toks(title); found = set()
    for i, w in enumerate(ts):
        volw = (i > 0 and ts[i-1] in VOL) or (i+1 < len(ts) and ts[i+1] in VOL)
        n = int(w) if (len(w) <= 2 and w.isdigit()) else (ORDINALS.get(w) if volw else None)
        if n is None: continue
        found.add(n)
        if len(found) > 1: return None
    return found.pop() if found else None

def part_conflict(b, c):
    mp = part_number(b["title"]); cp = part_number(comparison_title(c))
    return mp is not None and cp is not None and mp != cp

def comparison_title(c):
    sub = c.subtitle
    if sub and sub.strip():
        sn = norm(sub)
        import re as _re
        red = any(norm_series(n) == norm_series(sub) for (n, _) in (c.series or [])) \
            or any(norm_series(n) and sn.startswith(norm_series(n)) and len(sn[len(norm_series(n)):].split()) <= 2 for (n, _) in (c.series or [])) \
            or sn in norm(c.title) \
            or bool(_re.search(r"\b(tome|tomes|volume|volumes|vol|livre|livres|partie|parties|book|books|saison|season|episode)\b\.?\s*\d", sn))
        if not red: return c.title + " " + sub
    return c.title

def score(b, c):
    """Port de MetadataMatcher v0.7.4."""
    theirs = toks(comparison_title(c))
    mine = toks(b["title"])
    pref = None
    if c.authors and len(mine) >= 3:
        for a in c.authors:
            ta = toks(a)
            if ta and len(ta) < len(mine) and mine[:len(ta)] == ta:
                pref = ta; break
    if pref: mine = mine[len(pref):]
    idx = b["index"] or None
    if idx is not None and idx == int(idx) and mine and mine[-1] == str(int(idx)):
        mine = mine[:-1]
    if mine:
        fwd, bwd = coverage(mine, theirs), (coverage(theirs, mine) if len(theirs) >= 2 else 0.0)
        w = min(1.0, len(mine) / 3.0)
        t = (0.6 * w * max(fwd, bwd) + 0.4 * dice(mine, theirs)) / (0.6 * w + 0.4)
        if part_conflict(b, c): t *= 0.75
    else:
        t = 0.0
    author = b["author"]
    if author is None: a = 1.0 if pref else 0.5
    elif not c.authors: a = 0.0
    else:
        def asc(x):
            tx = toks(x)
            return max(dice(toks(author), tx), 1.0 if "".join(toks(author)) == "".join(tx) else dice(["".join(toks(author))], ["".join(tx)]))
        a = max(asc(x) for x in c.authors)
    mine_s, sl = b["series"], (c.series or [])
    partial = False
    if mine_s is None and not sl: s, ident = 0.5, False
    elif mine_s is None or not sl: s, ident = 0.3, False
    else:
        s, ident, anyk, samev, partial = 0.0, False, False, False, False
        for (name, ci) in sl:
            nd = dice(toks(mine_s), toks(norm_series(name)))
            im = idx is not None and ci is not None and abs(idx - ci) < 0.01
            same = idx is not None and ci is not None and int(idx) == int(ci)
            iv = 0.6 if (idx is None or ci is None) else (1.0 if im else (0.8 if same else 0.3))
            s = max(s, nd * 0.7 + iv * 0.3)
            if nd >= 0.75 and im: ident = True
            if ci is not None:
                anyk = True
                if idx is not None and int(idx) == int(ci): samev = True
        partial = samev and not ident
    r = 0.5
    base = 0.5 * t + 0.2 * a + 0.15 * s + 0.15 * r
    factor = 1.0 if not c.language else (1.0 if norm(c.language) == "french" else 0.80)
    if mine_s is not None and sl and anyk and idx is not None and not samev: factor *= 0.90
    conflict = part_conflict(b, c)
    if not conflict and (ident or partial):
        veto_a = author is not None and c.authors and a == 0.0
        top = 0.85 if ident else 0.80
        floor = max(base, top) if not veto_a else base
        return floor * factor
    return base * factor

def containment(b, c):
    theirs = toks(comparison_title(c)); mine = toks(b["title"])
    if not mine or len(theirs) < 2: return 0.0
    return max(coverage(mine, theirs), coverage(theirs, mine))

AUTO = 0.75

def run(b):
    pool, trace, calls = {}, [], 0
    for market in ("fr", "com"):
        market_calls = 0
        for q in b["plan"]:
            if market_calls >= 6: break
            try:
                got = fetch(q["mode"], q["text"], market)
            except Exception as e:
                trace.append(f"{market}:ERR {e}"); market_calls += 1; calls += 1; continue
            trace.append(f"{market}:{q['mode'][0]}«{q['text']}»→{len(got)}")
            market_calls += 1; calls += 1
            for c in got: pool.setdefault((c.market, c.asin), c)
            if pool:
                best = max(score(b, c) for c in pool.values())
                if best >= AUTO: return b, pool, trace, calls, "ladder"
        if pool: break
    best = max((score(b, c) for c in pool.values()), default=0.0)
    if b["author"] and best < AUTO:
        n = 0
        for page in (1, 2):
            try: got = fetch("keywords", b["author"], "fr", num=50, page=page)
            except Exception: break
            n += len(got)
            for c in got:
                if containment(b, c) >= 0.5: pool.setdefault((c.market, c.asin), c)
            if len(got) < 50: break
            time.sleep(0.2)
        calls += 1
        trace.append(f"fr:balayage «{b['author']}»→{n}")
    return b, pool, trace, calls, "sweep" if pool else "none"

def main(path="/tmp/plans.json"):
    books = json.load(open(path))
    ok = sug = none = 0
    for i, b in enumerate(books, 1):
        b2, pool, trace, calls, how = run(b)
        ranked = sorted(((score(b2, c), c) for c in pool.values()), key=lambda x: -x[0])
        best = ranked[0] if ranked else (0.0, None)
        verdict = "APPLIQUÉ" if best[0] >= AUTO else ("suggéré" if best[0] >= 0.50 else "AUCUN")
        if best[0] >= AUTO: ok += 1
        elif best[0] >= 0.50: sug += 1
        else: none += 1
        print(f"{i:2}. {b['raw'][:46]:<48} {best[0]:.3f} {verdict:<8} {calls}q  {best[1].asin+' '+best[1].title[:34] if best[1] else '-'}")
        if best[0] < AUTO:
            print(f"      plan: {' | '.join(q['mode'][0]+'«'+q['text']+'»' for q in b['plan'][:4])}")
            print(f"      trace: {'; '.join(trace[-6:])}")
        time.sleep(0.2)
    print(f"\n=== {ok}/18 appliqués, {sug} suggérés, {none} aucun ({ok/18:.0%} de réussite auto) ===")

if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "/tmp/plans.json")
