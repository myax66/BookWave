package dev.bookwave.core.util

import java.util.Locale

/** Duration formatting shared by UI and notifications. Locale-independent. */
object TimeFmt {

    /** "12:34" under an hour, "1:02:03" beyond. Negative input formats as zero. */
    fun formatDuration(ms: Long): String {
        val totalSec = (ms.coerceAtLeast(0)) / 1000
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        return if (h > 0) {
            String.format(Locale.ROOT, "%d:%02d:%02d", h, m, s)
        } else {
            String.format(Locale.ROOT, "%d:%02d", m, s)
        }
    }

    /** "3 h 12" style label for coarse durations (library rows). */
    fun formatCoarse(ms: Long): String {
        val totalMin = (ms.coerceAtLeast(0)) / 60000
        val h = totalMin / 60
        val m = totalMin % 60
        return if (h > 0) String.format(Locale.ROOT, "%d h %02d", h, m) else String.format(Locale.ROOT, "%d min", m)
    }

    /** Percentage label for listening progress, e.g. "42 %". */
    fun formatPercent(fraction: Double): String {
        val pct = (fraction.coerceIn(0.0, 1.0) * 100).toInt()
        return "$pct %"
    }
}
