package dev.bookwave.app.util

import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * One shared OkHttp client for the whole app. Every network class derives its
 * variant with `newBuilder()` so ALL calls share the connection pool and the
 * dispatcher threads instead of five independent pools (WebDAV, AllDebrid,
 * Torznab, sync, covers each used to build their own).
 */
object Http {
    val shared: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()
}
