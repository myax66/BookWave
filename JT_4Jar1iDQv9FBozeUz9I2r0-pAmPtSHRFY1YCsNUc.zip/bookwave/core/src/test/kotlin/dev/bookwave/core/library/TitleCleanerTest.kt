package dev.bookwave.core.library

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class TitleCleanerTest {

    @Test
    fun `strips dot separated scene tags`() {
        val c = TitleCleaner.clean("Le.Nom.du.Vent.2007.FRENCH.AUDIOBOOK.MP3.128kbps-XYZ")
        assertEquals("Le Nom du Vent", c.title)
    }

    @Test
    fun `strips bracketed release metadata`() {
        val c = TitleCleaner.clean("[French] Harry Potter - Tome 1 {2019} [MP3 128kbps]")
        assertEquals("Harry Potter", c.series)
        assertEquals(1.0, c.seriesIndex)
        assertTrue(c.title.startsWith("Harry Potter"))
    }

    @Test
    fun `detects tome and volume series`() {
        val tome = TitleCleaner.clean("Dune - Tome 3 La bataille d'Arrakeen")
        assertEquals(3.0, tome.seriesIndex)
        assertTrue(tome.title.startsWith("Dune"))

        val vol = TitleCleaner.clean("Fondation Volume 2")
        assertEquals("Fondation", vol.series)
        assertEquals(2.0, vol.seriesIndex)
    }

    @Test
    fun `detects hash numbering`() {
        val c = TitleCleaner.clean("Le Trone de Fer #12")
        assertEquals("Le Trone de Fer", c.series)
        assertEquals(12.0, c.seriesIndex)
    }

    @Test
    fun `underscores and cd tags are cleaned`() {
        val c = TitleCleaner.clean("DUNE_BY_FRANK_HERBERT_AUDIOBOOK_CD1")
        assertTrue("Dune" in c.title, "got: ${c.title}")
        assertTrue("AUDIOBOOK" !in c.title.uppercase())
        assertTrue("CD1" !in c.title.uppercase())
    }

    @Test
    fun `leading track number becomes the series index`() {
        val c = TitleCleaner.clean("03 - La route de Tarbean")
        assertEquals("La route de Tarbean", c.title)
        assertEquals(3.0, c.seriesIndex)
    }

    @Test
    fun `all caps names are recased`() {
        val c = TitleCleaner.clean("LE NOM DU VENT")
        assertEquals("Le Nom du Vent", c.title)
    }

    @Test
    fun `already clean titles are untouched`() {
        val c = TitleCleaner.clean("L'Étranger")
        assertEquals("L'Étranger", c.title)
    }

    @Test
    fun `never returns a blank title`() {
        listOf("", "   ", "mp3", "[128kbps]", "-XYZ").forEach { raw ->
            assertTrue(TitleCleaner.clean(raw).title.isNotBlank(), "blank for input '$raw'")
        }
    }

    @Test
    fun `file extension is removed`() {
        val c = TitleCleaner.clean("Dune.m4b")
        assertEquals("Dune", c.title)
    }

    @Test
    fun `author-prefixed saga names share one series key`() {
        val one = TitleCleaner.clean("Brandon Sanderson - Elantris 1 - Chute")
        val two = TitleCleaner.clean("Brandon Sanderson - Elantris 2 - Rédemption")
        assertEquals("Brandon Sanderson", one.author)
        assertEquals("Elantris", one.series)
        assertEquals("Elantris", two.series)
        assertEquals(1.0, one.seriesIndex)
        assertEquals(2.0, two.seriesIndex)
        assertEquals("Elantris 1 - Chute", one.title)
    }

    @Test
    fun `author prefix does not split a saga from its keyword-less volumes`() {
        val keyed = TitleCleaner.clean("La Roue du Temps - Tome 1")
        val bare = TitleCleaner.clean("Robert Jordan - La Roue du Temps 05 - Le Feu du ciel")
        assertEquals("La Roue du Temps", keyed.series)
        assertEquals("La Roue du Temps", bare.series)
        assertEquals("Robert Jordan", bare.author)
        assertEquals(5.0, bare.seriesIndex)
    }

    @Test
    fun `bare volume number without keyword is detected`() {
        val c = TitleCleaner.clean("La Roue du Temps 18")
        assertEquals("La Roue du Temps", c.series)
        assertEquals(18.0, c.seriesIndex)
    }

    @Test
    fun `bitrate numbers drop only next to format tags`() {
        assertEquals("Room 128", TitleCleaner.clean("Room 128").title)
        val scene = TitleCleaner.clean("Album.FRENCH.MP3.320-XYZ")
        assertTrue("320" !in scene.title, "got: ${scene.title}")
        assertTrue("Album" in scene.title, "got: ${scene.title}")
    }

    @Test
    fun `plain numbered titles do not become sagas`() {
        listOf("Studio 60", "Le Monde - Encyclopédie 2").forEach { raw ->
            val c = TitleCleaner.clean(raw)
            assertEquals(null, c.series, "unexpected series for '$raw': ${c.series}")
        }
    }

    @Test
    fun `hyphenated release tags are dropped from the displayed title`() {
        val c = TitleCleaner.clean("Brandon Sanderson - L Ensoleille M4B-K")
        assertTrue("M4B" !in c.title.uppercase(), "got: ${c.title}")
        assertTrue(c.title.contains("Ensoleille"), "got: ${c.title}")
    }

    @Test
    fun `hyphenated words that are not release tags survive`() {
        val c = TitleCleaner.clean("La science-fiction expliquee aux nuls")
        assertTrue("fiction" in c.title.lowercase(), "got: ${c.title}")
    }

    @Test
    fun `author prefix is split for search without a volume number`() {
        val split = TitleCleaner.authorPrefix("Brandon Sanderson - L Ensoleille M4B-K")
        assertTrue(split != null, "should split")
        assertEquals("Brandon Sanderson", split!!.first)
        assertEquals("L Ensoleille M4B-K", split.second)
    }

    @Test
    fun `single-word author before a volume is split too`() {
        // v0.7.4 — "Chugong - Solo Leveling 3" is a saga key built from a
        // one-word pen name; leaving it in the title made every query miss.
        val split = TitleCleaner.authorPrefix("Chugong - Solo Leveling 3")
        assertEquals("Chugong", split?.first)
        assertEquals("Solo Leveling 3", split?.second)
    }

    @Test
    fun `plain titles have no author prefix`() {
        assertEquals(null, TitleCleaner.authorPrefix("Le Nom du Vent"))
    }

    @Test
    fun `author prefix is stripped from a title when the author is known`() {
        assertEquals(
            "Les Archives de Roshar 2 - Le Livre des radieux",
            TitleCleaner.stripAuthorPrefix(
                "Brandon Sanderson - Les Archives de Roshar 2 - Le Livre des radieux",
                "Brandon Sanderson",
            ),
        )
    }

    @Test
    fun `a title that merely starts with a word of the author name is untouched`() {
        val title = "Sanderson et moi"
        assertEquals(title, TitleCleaner.stripAuthorPrefix(title, "Brandon Sanderson"))
    }

    @Test
    fun `volume in the middle and author at the end are both detected`() {
        val c = TitleCleaner.clean("L'Âge de la Folie 03 La Sagesse des Foules - Joe Abercrombie")
        assertEquals("L'Âge de la Folie", c.series)
        assertEquals(3.0, c.seriesIndex)
        assertEquals("Joe Abercrombie", c.author)
        assertTrue("Abercrombie" !in c.title, "author leaked into title: ${c.title}")
        assertTrue(c.title.contains("Sagesse des Foules"), "got: ${c.title}")
    }

    @Test
    fun `a digit inside a saga name does not start a fake volume`() {
        val c = TitleCleaner.clean("Le Sang des 7 Rois 1 - Le couronnement")
        assertTrue(c.series != "Le Sang des", "wrong split: ${c.series}")
    }

    @Test
    fun `a dash before a volume marker is never an author`() {
        // "Harry Potter - Tome 1" is one name, not an author and a title.
        assertEquals(null, TitleCleaner.clean("Harry Potter - Tome 1").author)
        assertEquals(1.0, TitleCleaner.clean("Harry Potter - Tome 1").seriesIndex)
    }

    @Test
    fun `a trailing person name becomes the author`() {
        val c = TitleCleaner.clean("Le Nom du Vent - Patrick Rothfuss")
        assertEquals("Patrick Rothfuss", c.author)
    }

    @Test
    fun `author prefix without any dash is split for search`() {
        val split = TitleCleaner.authorPrefix("Brandon Sanderson L Ensoleille")
        assertTrue(split != null, "should split")
        assertEquals("Brandon Sanderson", split!!.first)
        assertEquals("L Ensoleille", split.second)
    }

    @Test
    fun `a saga name starting with an article is not an author`() {
        assertEquals(null, TitleCleaner.authorPrefix("Le Seigneur des Anneaux"))
        assertEquals(null, TitleCleaner.authorPrefix("Harry Potter et le prisonnier d Azkaban"))
    }

    @Test
    fun `author prefix without a dash is stripped from a known title`() {
        assertEquals(
            "L Ensoleille",
            TitleCleaner.stripAuthorPrefix("Brandon Sanderson L Ensoleille", "Brandon Sanderson"),
        )
        // A single leftover word is never enough to strip.
        assertEquals(
            "Brandon Sanderson",
            TitleCleaner.stripAuthorPrefix("Brandon Sanderson", "Brandon Sanderson"),
        )
    }
}
