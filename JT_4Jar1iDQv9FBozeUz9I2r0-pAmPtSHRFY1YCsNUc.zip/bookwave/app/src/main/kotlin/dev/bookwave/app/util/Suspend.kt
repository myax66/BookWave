package dev.bookwave.app.util

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Response
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * `runCatching` for suspend code that does NOT swallow [CancellationException]:
 * a cancelled coroutine must propagate its cancellation instead of being
 * reported as a regular failure (phantom work + misleading error messages).
 */
suspend inline fun <T> suspendRunCatching(crossinline block: suspend () -> T): Result<T> =
    try {
        Result.success(block())
    } catch (cancellation: CancellationException) {
        throw cancellation
    } catch (e: Exception) {
        Result.failure(e)
    }

/**
 * Cancellable OkHttp call. `Call.execute()` inside `withContext(IO)` ignores
 * coroutine cancellation (a 60 s read keeps a thread hostage after the screen
 * is gone); enqueue + [suspendCancellableCoroutine] ties the call lifetime to
 * the coroutine: cancelling the coroutine cancels the request.
 */
suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
    enqueue(
        object : Callback {
            override fun onResponse(call: Call, response: Response) {
                if (cont.isActive) {
                    cont.resume(response)
                } else {
                    response.close()
                }
            }

            override fun onFailure(call: Call, e: IOException) {
                // A cancelled call also lands here — only resume a live continuation.
                if (cont.isActive) cont.resumeWithException(e)
            }
        },
    )
    cont.invokeOnCancellation {
        runCatching { cancel() }
    }
}
