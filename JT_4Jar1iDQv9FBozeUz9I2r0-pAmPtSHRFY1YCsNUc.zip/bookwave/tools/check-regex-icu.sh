#!/usr/bin/env bash
# Vérifie que TOUTES les Regex("...") du projet compilent avec ICU — le moteur
# utilisé par android.util.regex. La JVM (OpenJDK) accepte des motifs qu'ICU
# refuse (« syntax error near index 8 » sur "\{[^}]*}"), et les tests unitaires
# tournent sur la JVM : sans cette vérification, le bug n'apparaît qu'à
# l'exécution sur le téléphone.
#
# Prérequis : gcc + libicu-dev (Debian/Ubuntu : sudo apt install libicu-dev)
# Usage : tools/check-regex-icu.sh [racine-du-projet]
set -euo pipefail
ROOT="${1:-.}"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

cat > "$TMP/icucheck.c" <<'EOF'
#include <stdio.h>
#include <string.h>
#include <unicode/uregex.h>
#include <unicode/ustring.h>
#include <unicode/utypes.h>
int main(void) {
    char line[8192];
    while (fgets(line, sizeof line, stdin)) {
        size_t len = strlen(line);
        if (len && line[len-1] == '\n') line[--len] = 0;
        if (len && line[len-1] == '\r') line[--len] = 0;
        if (!len) continue;
        UErrorCode status = U_ZERO_ERROR;
        UParseError pe;
        UChar pat[4096];
        int32_t patLen = 0;
        u_strFromUTF8(pat, 4096, &patLen, line, (int32_t)len, &status);
        if (U_FAILURE(status)) { printf("ENCODING\t%s\n", line); continue; }
        URegularExpression *re = uregex_open(pat, patLen, 0, &pe, &status);
        if (U_FAILURE(status)) printf("FAIL %s @%d\t%s\n", u_errorName(status), pe.offset, line);
        else { printf("OK\t%s\n", line); uregex_close(re); }
    }
    return 0;
}
EOF
gcc "$TMP/icucheck.c" -o "$TMP/icucheck" -licui18n -licuuc -lstdc++

python3 - "$ROOT" > "$TMP/patterns.txt" <<'EOF'
import glob, re, sys
root = sys.argv[1]
for f in glob.glob(root + '/**/src/**/*.kt', recursive=True):
    src = open(f, encoding='utf-8').read()
    for m in re.finditer(r'Regex\(\s*("(?:[^"\\]|\\.)*"|"""[\s\S]*?""")', src):
        raw = m.group(1)
        if raw.startswith('"""'):
            body = raw[3:-3]
        else:
            body, out, i = raw[1:-1], [], 0
            while i < len(body):
                c = body[i]
                if c == '\\' and i + 1 < len(body):
                    out.append({'n': '\n', 't': '\t', 'r': '\r', '"': '"', '\\': '\\', '$': '$'}
                               .get(body[i+1], '\\' + body[i+1]))
                    i += 2
                else:
                    out.append(c)
                    i += 1
            body = ''.join(out)
        if '${' in body:
            print("// mot supprimé : template ${} non résolu", file=sys.stderr)
            continue
        print(body.replace('\n', '\\n').replace('\r', '\\r'))
EOF

TOTAL=$(wc -l < "$TMP/patterns.txt")
FAILS=$("$TMP/icucheck" < "$TMP/patterns.txt" | grep -c '^FAIL' || true)
"$TMP/icucheck" < "$TMP/patterns.txt" | grep '^FAIL' || true
echo "$TOTAL motif(s) vérifié(s) avec ICU, $FAILS invalide(s)"
[ "$FAILS" -eq 0 ]
