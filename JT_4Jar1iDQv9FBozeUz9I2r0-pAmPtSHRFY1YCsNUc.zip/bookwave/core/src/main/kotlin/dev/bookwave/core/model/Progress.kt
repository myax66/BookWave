package dev.bookwave.core.model

import java.time.Instant

/**
 * Listening progress for one book, as kept locally and synced across devices.
 *
 * Conflict resolution is deterministic and symmetric (see [ProgressMerge]) so
 * that every device converges to the same state without a server round-trip.
 */
data class ListeningProgress(
    val bookId: String,
    val positionMs: Long,
    val durationMs: Long,
    val speed: Float = 1f,
    val completed: Boolean = false,
    val updatedAt: Instant,
    val deviceId: String,
) {
    init {
        require(bookId.isNotBlank()) { "book id must not be blank" }
        require(positionMs >= 0) { "position must be >= 0" }
        require(durationMs >= 0) { "duration must be >= 0" }
        require(deviceId.isNotBlank()) { "device id must not be blank" }
    }

    /** Fraction of the book listened to, in 0.0..1.0 (position clamped to duration). */
    val fraction: Double
        get() = when {
            completed -> 1.0
            durationMs == 0L -> 0.0
            else -> (positionMs.toDouble() / durationMs).coerceIn(0.0, 1.0)
        }

    val isFinished: Boolean get() = completed || (durationMs > 0 && positionMs >= durationMs)

    /** Wall-clock time left at the current speed; null when unknown. */
    fun remainingWallMs(): Long? {
        if (durationMs <= 0 || speed <= 0f) return null
        val remainingAudio = (durationMs - positionMs).coerceAtLeast(0)
        return (remainingAudio / speed).toLong()
    }
}

/**
 * Deterministic merge of two progress states for the same book.
 *
 * Rules (in order):
 *  1. A completed state always wins over a non-completed one.
 *  2. Otherwise the furthest position wins — replaying a passage on another
 *     device never rewinds the shared position.
 *  3. Ties break on the most recent [ListeningProgress.updatedAt].
 *  4. Absolute ties break on [ListeningProgress.deviceId] for symmetry.
 */
object ProgressMerge {

    fun merge(a: ListeningProgress, b: ListeningProgress): ListeningProgress {
        require(a.bookId == b.bookId) { "cannot merge progress of different books" }
        return when {
            a.completed != b.completed -> if (a.completed) a else b
            a.positionMs != b.positionMs -> if (a.positionMs > b.positionMs) a else b
            a.updatedAt != b.updatedAt -> if (a.updatedAt.isAfter(b.updatedAt)) a else b
            else -> if (a.deviceId >= b.deviceId) a else b
        }
    }
}
