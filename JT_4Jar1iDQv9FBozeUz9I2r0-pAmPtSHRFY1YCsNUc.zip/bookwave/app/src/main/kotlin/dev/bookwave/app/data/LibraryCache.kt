package dev.bookwave.app.data

import android.content.Context
import dev.bookwave.core.model.Audiobook
import dev.bookwave.core.model.Chapter
import dev.bookwave.core.library.TitleCleaner
import dev.bookwave.core.model.SourceRef
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * On-disk library snapshot so a cold start shows the last known books
 * INSTANTLY instead of re-scanning a (possibly huge) WebDAV account.
 *
 * The scan that produced the snapshot can take minutes on loaded accounts;
 * the UI serves this cache first and refreshes in the background.
 */
class LibraryCache(context: Context) {

    data class Entry(val books: List<Audiobook>, val savedAt: Long) {
        fun ageMs(now: Long = System.currentTimeMillis()): Long = now - savedAt
    }

    private val file = File(context.filesDir, "library-cache.json")

    /**
     * Last parsed entry, so one library refresh parses the (potentially
     * multi-MB) JSON ONCE instead of three times (freshness check, cached
     * books, then the network path). Invalidated by [save]/[clear].
     */
    private var memoKey: String? = null
    private var memo: Entry? = null

    /** Cache younger than this is served without any network round-trip. */
    fun isFresh(entry: Entry, maxAgeMs: Long = FRESH_MS): Boolean = entry.ageMs() < maxAgeMs

    fun save(books: List<Audiobook>, key: String) {
        memoKey = null
        memo = null
        runCatching {
            val root = JSONObject()
            root.put("key", key)
            root.put("savedAt", System.currentTimeMillis())
            val array = JSONArray()
            books.forEach { array.put(encode(it)) }
            root.put("books", array)
            val tmp = File(file.parentFile, file.name + ".tmp")
            tmp.writeText(root.toString())
            if (!tmp.renameTo(file)) {
                file.writeText(root.toString())
                tmp.delete()
            }
        }
    }

    /** Returns null when there is no cache or it belongs to another account. */
    fun load(expectedKey: String): Entry? {
        memo?.let { if (memoKey == expectedKey) return it }
        val entry = readFromDisk(expectedKey)
        memo = entry
        memoKey = expectedKey
        return entry
    }

    private fun readFromDisk(expectedKey: String): Entry? = runCatching {
        if (!file.exists()) return null
        val root = JSONObject(file.readText())
        if (root.optString("key") != expectedKey) return null
        val array = root.optJSONArray("books") ?: return null
        val books = mutableListOf<Audiobook>()
        for (i in 0 until array.length()) {
            // One malformed record must not lose the whole library.
            runCatching { decode(array.getJSONObject(i)) }.getOrNull()?.let { books += reclean(it) }
        }
        Entry(books, root.optLong("savedAt", 0L))
    }.getOrNull()

    /**
     * Titles cached by an OLDER TitleCleaner kept showing release junk
     * ("(Audiobook Fr) [MP3…]") after app updates: a fresh cache is served
     * without any rescan. Re-derive display metadata from the source path on
     * every load — pure, microseconds per book, always current.
     */
    private fun reclean(book: Audiobook): Audiobook {
        val raw = book.source.path.trimEnd('/').substringAfterLast('/')
        if (raw.isBlank()) return book
        return runCatching {
            val c = TitleCleaner.clean(raw)
            // v0.8.0 — `author = c.author` used to ERASE an author the cleaner
            // could not re-derive on this run (a cleaned name whose author was
            // already split by the previous version), silently losing data on
            // every cold start. Fall back to what the cache already knows.
            book.copy(
                title = c.title.ifBlank { book.title },
                author = c.author ?: book.author,
                series = c.series ?: book.series,
                seriesIndex = c.seriesIndex ?: book.seriesIndex,
            )
        }.getOrDefault(book)
    }

    fun clear() {
        memoKey = null
        memo = null
        runCatching { if (file.exists()) file.delete() }
    }

    private fun encode(book: Audiobook): JSONObject = JSONObject().apply {
        put("id", book.id)
        put("title", book.title)
        book.author?.let { put("author", it) }
        book.narrator?.let { put("narrator", it) }
        book.series?.let { put("series", it) }
        book.seriesIndex?.let { put("seriesIndex", it) }
        book.coverUrl?.let { put("coverUrl", it) }
        put("durationMs", book.durationMs)
        put("sizeBytes", book.sizeBytes)
        put(
            "source",
            JSONObject().apply {
                put("provider", book.source.provider)
                put("account", book.source.account)
                put("path", book.source.path)
                book.source.contentUrl?.let { put("contentUrl", it) }
            },
        )
        val chapters = JSONArray()
        book.chapters.forEach { c ->
            chapters.put(
                JSONObject().apply {
                    put("index", c.index)
                    c.title?.let { put("title", it) }
                    put("startMs", c.startMs)
                    put("endMs", c.endMs)
                },
            )
        }
        put("chapters", chapters)
    }

    private fun decode(obj: JSONObject): Audiobook {
        val src = obj.getJSONObject("source")
        val chapters = mutableListOf<Chapter>()
        obj.optJSONArray("chapters")?.let { array ->
            for (i in 0 until array.length()) {
                val c = array.getJSONObject(i)
                val start = c.optLong("startMs", 0L)
                val end = c.optLong("endMs", start + 1).coerceAtLeast(start + 1)
                chapters += Chapter(
                    index = c.optInt("index", i),
                    title = c.optString("title").ifBlank { null },
                    startMs = start,
                    endMs = end,
                )
            }
        }
        return Audiobook(
            id = obj.getString("id"),
            title = obj.getString("title"),
            author = obj.optString("author").ifBlank { null },
            narrator = obj.optString("narrator").ifBlank { null },
            series = obj.optString("series").ifBlank { null },
            seriesIndex = if (obj.has("seriesIndex")) obj.optDouble("seriesIndex") else null,
            coverUrl = obj.optString("coverUrl").ifBlank { null },
            durationMs = obj.optLong("durationMs", 0L).coerceAtLeast(0L),
            chapters = chapters,
            source = SourceRef(
                provider = src.getString("provider"),
                account = src.getString("account"),
                path = src.getString("path"),
                contentUrl = src.optString("contentUrl").ifBlank { null },
            ),
            sizeBytes = obj.optLong("sizeBytes", 0L).coerceAtLeast(0L),
        )
    }

    companion object {
        /** Serve the disk cache without hitting the network inside this window. */
        const val FRESH_MS = 15 * 60_000L
    }
}
