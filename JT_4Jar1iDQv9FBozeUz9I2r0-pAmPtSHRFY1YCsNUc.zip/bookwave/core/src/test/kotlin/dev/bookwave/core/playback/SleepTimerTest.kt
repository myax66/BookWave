package dev.bookwave.core.playback

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNull
import kotlin.test.assertTrue

class SleepTimerTest {

    @Test
    fun durationModeCountsDown() {
        val mode = SleepTimerMode.Duration(30_000)
        assertEquals(30_000, SleepTimer.remainingAudioMs(mode, 0, 100, null, null))
        assertEquals(5_000, SleepTimer.remainingAudioMs(mode, 25_000, 100, null, null))
        assertEquals(0, SleepTimer.remainingAudioMs(mode, 40_000, 100, null, null))
        assertTrue(SleepTimer.shouldStop(mode, 30_000, 100, null, null))
    }

    @Test
    fun endOfChapterStopsAtBoundary() {
        val mode = SleepTimerMode.EndOfChapter
        assertEquals(2_000, SleepTimer.remainingAudioMs(mode, 0, 8_000, 10_000, 50_000))
        assertTrue(SleepTimer.shouldStop(mode, 0, 10_000, 10_000, 50_000))
        assertFalse(SleepTimer.shouldStop(mode, 0, 9_999, 10_000, 50_000))
    }

    @Test
    fun endOfBookStopsAtBookEnd() {
        val mode = SleepTimerMode.EndOfBook
        assertEquals(1_000, SleepTimer.remainingAudioMs(mode, 0, 49_000, 20_000, 50_000))
        assertTrue(SleepTimer.shouldStop(mode, 0, 50_000, 20_000, 50_000))
    }

    @Test
    fun noModeMeansNoTimer() {
        assertNull(SleepTimer.remainingAudioMs(null, 0, 0, 0, 0))
        assertFalse(SleepTimer.shouldStop(null, 999_999, 0, 0, 0))
    }
}

class AudioSpeedTest {

    @Test
    fun labelsAreCompact() {
        assertEquals("1×", AudioSpeed.label(1.0f))
        assertEquals("1.5×", AudioSpeed.label(1.5f))
        assertEquals("2.5×", AudioSpeed.label(2.5f))
    }

    @Test
    fun coercionRespectsBounds() {
        assertEquals(AudioSpeed.MIN, AudioSpeed.coerce(0.1f))
        assertEquals(AudioSpeed.MAX, AudioSpeed.coerce(9f))
    }

    @Test
    fun wallTimeScalesWithSpeed() {
        assertEquals(60_000, AudioSpeed.wallDurationMs(60_000, 1.0f))
        assertEquals(30_000, AudioSpeed.wallDurationMs(60_000, 2.0f))
    }
}
