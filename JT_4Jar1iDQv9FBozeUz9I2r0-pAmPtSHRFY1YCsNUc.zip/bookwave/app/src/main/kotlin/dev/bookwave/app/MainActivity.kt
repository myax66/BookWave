package dev.bookwave.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import dev.bookwave.app.data.AppSettings
import dev.bookwave.app.data.alldebrid.PendingTorrent
import dev.bookwave.app.ui.nav.BookwaveNav
import dev.bookwave.app.ui.theme.BookwaveTheme

class MainActivity : ComponentActivity() {

    /** Bumped on every incoming share/magnet intent so the UI can react. */
    private var shareTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Media notification (pause/resume outside the app) needs the runtime
        // notification grant on Android 13+ — asked ONCE: re-prompting on every
        // launch nagged users who dismissed the dialog.
        val settings = AppSettings(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            !settings.notificationPromptShown &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            settings.notificationPromptShown = true
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                1001,
            )
        }

        handleIncoming(intent)

        setContent {
            BookwaveTheme {
                BookwaveNav(shareTick = shareTick)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncoming(intent)
    }

    /**
     * Accepts torrents pushed into the app: the browser/app "Share" sheet with
     * a magnet link or a hash, and direct `magnet:` links.
     */
    private fun handleIncoming(intent: Intent?) {
        val text = when (intent?.action) {
            Intent.ACTION_SEND -> if (intent.type == "text/plain") {
                intent.getStringExtra(Intent.EXTRA_TEXT)
            } else {
                null
            }

            Intent.ACTION_VIEW -> intent.data?.takeIf { it.scheme == "magnet" }?.toString()
            else -> null
        }
        if (!text.isNullOrBlank()) {
            PendingTorrent.offer(text)
            shareTick++
        }
    }
}
