package dev.bookwave.core.library

/**
 * Result of cleaning a raw cloud/torrent folder name into display metadata.
 *
 * @param title display title, never blank
 * @param series detected series name when the raw name carried one
 * @param seriesIndex detected volume/episode number
 */
data class CleanedTitle(
    val title: String,
    val author: String? = null,
    val series: String? = null,
    val seriesIndex: Double? = null,
)

/**
 * Turns scene/torrent style names into readable audiobook titles.
 *
 * Real-world inputs this handles:
 *  - `Le.Nom.du.Vent.2007.FRENCH.AUDIOBOOK.MP3.128kbps-XYZ`
 *  - `[French] Harry Potter - Tome 1 {2019} [MP3 128kbps]`
 *  - `DUNE_BY_FRANK_HERBERT_AUDIOBOOK_CD1`
 *  - `03 - La route de Tarbean`
 *
 * Pure and side-effect free so it stays unit-testable without Android.
 */
object TitleCleaner {

    private val AUDIO_EXT = Regex(
        "\\.(mp3|m4a|m4b|aac|ogg|oga|opus|flac|wav|wma|zip)$",
        RegexOption.IGNORE_CASE,
    )

    /** Anything inside brackets is removed when it looks like release metadata. */
    private val BRACKETED = Regex("[\\[({]([^\\])}]*)[\\])}]")

    /** Words that never belong in a displayed title. */
    private val JUNK_TOKENS = setOf(
        "audiobook", "audio", "ebook", "mp3", "m4a", "m4b", "flac", "aac", "ogg", "opus", "wav",
        "kbps", "vbr", "cbr", "hq", "hd", "repack", "proper", "complete", "complet",
        "french", "francais", "français", "truefrench", "vostfr", "multi", "vf", "vo", "subforced",
        "cd1", "cd2", "cd3", "cd4", "cd5", "cd6", "cd7", "cd8", "cd9", "cd10",
        "disc1", "disc2", "disc3", "disc4", "disc5", "disque1", "disque2", "disque3",
        "part1", "part2", "part3", "part4", "part5",
        "44100", "48000",
    )

    /**
     * Bare numbers are NOT junk in general ("Room 128" keeps its 128): a number
     * only drops when it sits next to a bitrate/format tag ("MP3 320", "192 kbps").
     */
    /**
     * `m4b-k`, `web-dl`, `aac-x`: short hyphenated alnum tags that survive
     * token cleaning because they are ONE token (the exact-match JUNK_TOKENS
     * list only knows "m4b"). Seen in the wild as "… L Ensoleille M4B-K".
     */
    private val RELEASE_TAG_SHAPE = Regex("^[a-z0-9]{1,6}-[a-z0-9]{1,8}$")

    private val BITRATE_NEIGHBOURS = setOf(
        "kbps", "vbr", "cbr", "khz", "hz", "mp3", "m4a", "m4b", "flac", "aac", "ogg", "opus", "wav",
    )

    /** `Tome 3`, `Volume 2`, `Book 1`, `Partie 4`, `Épisode 12`, `Saison 1`, `#5`, `T2`. */
    private val SERIES_WORD = Regex(
        "^(?<series>.+?)\\s+(?:tome|tomes|volume|volumes|vol|livre|livres|partie|parties|part|épisode|episode|chapitre|saison|season|book|books|t|v)\\.?\\s*(?<index>\\d{1,3}(?:[.,]\\d+)?)\\b",
        RegexOption.IGNORE_CASE,
    )
    private val SERIES_HASH = Regex("^(?<series>.+?)\\s*#(?<index>\\d{1,3})\\b")
    private val LEADING_NUMBER = Regex("^(?<index>\\d{1,3}(?:[.,]\\d+)?)\\s*[-–—.\\s]+\\s*(?<rest>.+)$")

    /**
     * "Brandon Sanderson - Elantris 1 - Chute" → author + series + index.
     * The author part must be 2-3 capitalised words (a person's name), which
     * keeps saga names like "Le Monde …" from being mistaken for an author.
     */
    private val AUTHOR_SERIES_NUM = Regex(
        "^(?<author>\\p{Lu}\\S+(?:\\s+\\p{Lu}\\S+){1,2})\\s*[-–—]\\s*(?<series>[^-–—]+?)\\s+(?<index>\\d{1,3}(?:[.,]\\d+)?)\\s*(?:[-–—]\\s*(?<sub>.+))?$",
    )

    /**
     * "Auteur - Titre" with NO volume number ("Brandon Sanderson - L Ensoleille"):
     * the case the pattern above cannot take (it requires a volume).
     */
    private val AUTHOR_PREFIX = Regex(
        "^(?<author>\\p{Lu}\\S+(?:\\s+\\p{Lu}\\S+){1,2})\\s*[-–—]\\s*(?<rest>.+)$",
    )

    /** "Tolkien - Le Seigneur des Anneaux 1" */
    private val SINGLE_WORD_AUTHOR = Regex(
        "^(?<author>\\p{Lu}\\S+)\\s*[-–—]\\s*(?<rest>.+)$",
    )

    private val VOLUME_TAIL = Regex("\\s\\d{1,3}\\s*$")

    /**
     * "Tome 1", "Volume 3", "Livre 2": a volume marker is not a title, so the
     * segment before it is NOT an author ("Harry Potter - Tome 1" is one name).
     */
    private val VOLUME_MARKER = Regex(
        "^(?:tome|tomes|volume|volumes|vol|livre|livres|partie|parties|part|épisode|episode|chapitre|saison|season|book|books|t|v)\\.?\\s*\\d",
        RegexOption.IGNORE_CASE,
    )

    /**
     * Words that open a French/English title: after a person's name they are
     * proof that a new segment starts, even without a dash.
     * "Brandon Sanderson L Ensoleille" → "L" opens the title.
     */
    private val DETERMINERS = setOf(
        "l", "le", "la", "les", "un", "une", "des", "de", "du", "d", "au", "aux",
        "the", "a", "an", "el", "los", "las", "der", "die", "das",
    )

    /**
     * Trailing author: "… La Sagesse des Foules - Joe Abercrombie".
     * Half the trackers put the author AFTER the title; without this split the
     * author's name stayed in the query and every keyword search missed.
     */
    private val TRAILING_AUTHOR = Regex(
        "^(?<title>.+?)\\s*[-–—]\\s*(?<author>\\p{Lu}\\S+(?:\\s+\\p{Lu}\\S+){1,2})\\s*$",
    )

    /**
     * Volume number EMBEDDED mid-title: "L'Âge de la Folie 03 La Sagesse des
     * Foules" → saga "L'Âge de la Folie", tome 3, sous-titre "La Sagesse…".
     * Guarded: the tail must hold at least two words and NO digits (otherwise
     * "Le Sang des 7 Rois 1" would split at its "7").
     */
    private val SERIES_EMBEDDED = Regex(
        "^(?<series>[^-–—]*?\\S)\\s+(?<index>\\d{1,3})\\s+(?<sub>\\p{L}[^-–—]*)$",
    )

    /** "Elantris 1 - Chute" / "La Roue du Temps 05" → series + index (no author). */
    private val SERIES_NUM = Regex(
        "^(?<series>[^-–—]+?)\\s+(?<index>\\d{1,3}(?:[.,]\\d+)?)\\s*(?:[-–—]\\s*(?<sub>.+))?$",
    )

    private val SMALL_WORDS = setOf("le", "la", "les", "l", "de", "du", "des", "un", "une", "et", "a", "à", "en", "the", "of", "and")

    /**
     * Words that LINK a number to what follows: when the token before a volume
     * number is one of these, the number belongs to the title ("Le Sang des
     * **7** Rois 1") and must not be read as a saga index.
     */
    private val LINK_WORDS = setOf(
        "de", "des", "du", "d", "l", "la", "le", "les", "et", "a", "à", "en", "au", "aux",
        "pour", "sur", "sous", "dans", "avec", "of", "the", "and", "for", "in", "on", "with",
    )

    /** Trailing `-GROUP` release tag (no spaces, all-caps or with digits). */
    private val TRAILING_GROUP = Regex("[-–—]\\s*([A-Za-z0-9._]+)$")

    fun clean(raw: String): CleanedTitle {
        val fallback = raw.trim().ifBlank { "Sans titre" }
        var s = fallback

        // 0. Exotic spaces (WebDAV/AFP names) behave like normal ones, else
        //    "Brandon<NBSP>Sanderson" is ONE word and no prefix is detected.
        s = s.replace(Regex("[\\u00A0\\u2007\\u202F\\uFEFF]"), " ")

        // 1. Drop a trailing audio/container extension and bracketed metadata.
        s = AUDIO_EXT.replace(s, "")
        s = stripJunkBrackets(s)

        // 2. Dot/underscore separated names (only when clearly machine-named).
        if (looksDotSeparated(s)) {
            s = s.replace(Regex("[._]+"), " ")
        }

        // 3. Trailing release group tag.
        s = stripReleaseGroup(s)

        // 4. Junk tokens anywhere in the name.
        s = dropJunkTokens(s)

        // 5. Tidy separators and whitespace.
        s = s.replace(Regex("\\s{2,}"), " ")
            .replace(Regex("(?:\\s*[-–—_:|,.]\\s*)+$"), "")
            .replace(Regex("^\\s*[-–—_:|,.]+\\s*"), "")
            .trim()
        if (s.isEmpty()) return CleanedTitle(fallback)

        // 6. ALL-CAPS torrents → readable casing.
        s = fixShouting(s)

        // 7. Trailing author ("Titre - Joe Abercrombie").
        val trailing = splitTrailingAuthor(s)
        var author = trailing.first
        var core = trailing.second

        // 7b. v0.7.4 — leading author. Most trackers put the writer FIRST
        // ("Brandon Sanderson Les Archives de Roshar 05 …", "Tolkien - Le
        // Seigneur des Anneaux 1 …"). It used to be recognised only by the
        // enricher, i.e. AFTER the series had been read from a string still
        // carrying the name — every saga key started with "Brandon Sanderson".
        if (author == null) {
            authorPrefix(core)?.let { (found, rest) ->
                author = found
                core = rest
            }
        }

        // 8. Series / index extraction.
        val extracted = extractSeries(core)

        return CleanedTitle(
            title = extracted.title.ifBlank { core },
            author = extracted.author ?: author,
            series = extracted.series,
            seriesIndex = extracted.index,
        )
    }

    /**
     * Splits a trailing author off a name: "Titre - Joe Abercrombie" →
     * ("Joe Abercrombie", "Titre"). Returns (null, s) when the tail does not
     * look like a person's name — "Harry Potter - Le Monde des sorciers" keeps
     * its dashes (the tail starts with an article).
     */
    private fun splitTrailingAuthor(s: String): Pair<String?, String> {
        val m = TRAILING_AUTHOR.find(s.trim()) ?: return null to s
        val author = m.groups["author"]?.value?.trim().orEmpty()
        val title = m.groups["title"]?.value?.trim().orEmpty()
        if (author.isEmpty() || title.isEmpty()) return null to s
        if (author.split(" ").any { it.lowercase().trim('\'') in SMALL_WORDS }) return null to s
        return author to title
    }

    /**
     * Splits "Brandon Sanderson - L Ensoleille M4B-K" into
     * ("Brandon Sanderson" / "L Ensoleille M4B-K").
     *
     * SEARCH ONLY — never used to build the displayed title: a title can look
     * like a person's name ("Harry Potter - Le Monde des sorciers"), so the
     * user's view keeps the cleaned folder name until an edition is matched.
     * The enricher only calls it when neither an author nor a series was found.
     */
    fun authorPrefix(s: String): Pair<String, String>? {
        val t = s.trim()
        AUTHOR_PREFIX.find(t)?.let { m ->
            val author = m.groups["author"]?.value?.trim().orEmpty()
            val rest = m.groups["rest"]?.value?.trim().orEmpty()
            // A one-word rest is fine ("Brandon Sanderson - Elantris"): the
            // head is already a full person's name.
            if (author.isNotEmpty() && rest.isNotEmpty() &&
                author.split(" ").none { it.lowercase().trim('\'') in SMALL_WORDS } &&
                !VOLUME_MARKER.containsMatchIn(rest)
            ) {
                return author to rest
            }
        }
        // One-word author before a dash: "Tolkien - Le Seigneur des Anneaux 1",
        // "Chugong - Solo Leveling 3". Accepted only when what follows really
        // looks like a title: it opens on a determiner, or it ends on a volume.
        SINGLE_WORD_AUTHOR.find(t)?.let { m ->
            val author = m.groups["author"]?.value?.trim().orEmpty()
            val rest = m.groups["rest"]?.value?.trim().orEmpty()
            val words = rest.split(" ").filter { it.isNotBlank() }
            val opener = words.firstOrNull()?.lowercase()?.trim('\'', '-', '–', '—') ?: ""
            val endsOnVolume = VOLUME_TAIL.containsMatchIn(rest)
            if (author.length >= 4 && words.size >= 2 &&
                (opener in DETERMINERS || endsOnVolume) &&
                !VOLUME_MARKER.containsMatchIn(rest)
            ) {
                return author to rest
            }
        }
        return spaceSeparatedAuthorPrefix(t)
    }

    /**
     * No dash at all: "Brandon Sanderson L Ensoleille" (renamed folders, tags
     * written by uploaders). A person's name is only accepted when the next
     * word OPENS a title ("L", "Les", "Un"…), which keeps "Harry Potter" and
     * "Le Seigneur des Anneaux" from being mistaken for authors.
     */
    private fun spaceSeparatedAuthorPrefix(t: String): Pair<String, String>? {
        val words = t.split(" ").filter { it.isNotBlank() }
        if (words.size < 4) return null
        for (n in minOf(3, words.size - 2) downTo 2) {
            val author = words.take(n)
            val rest = words.drop(n)
            val authorOk = author.all { w ->
                w.length >= 2 && w.first().isUpperCase() && w.lowercase().trim('\'') !in SMALL_WORDS
            }
            if (!authorOk) continue
            val first = rest.first().lowercase().trim('\'', '-', '–', '—')
            if (first !in DETERMINERS) continue
            if (rest.size < 2) continue
            return author.joinToString(" ") to rest.joinToString(" ")
        }
        return null
    }

    /**
     * Removes a leading "<author> - " from a title, verbatim match only.
     * "Brandon Sanderson - Les Archives de Roshar 2 - Le Livre des radieux"
     * with author "Brandon Sanderson" → "Les Archives de Roshar 2 - …".
     * Used for search/scoring, never for display.
     */
    fun stripAuthorPrefix(title: String, author: String?): String {
        if (author.isNullOrBlank()) return title
        val t = title.trim()
        val a = author.trim()
        if (!t.startsWith(a, ignoreCase = true)) return title
        val rest = t.substring(a.length).trimStart()
        val dash = rest.firstOrNull()
        if (dash == '-' || dash == '–' || dash == '—') {
            return rest.drop(1).trimStart().ifBlank { title }
        }
        // v0.7.3 — no separator ("Brandon Sanderson L Ensoleille"): strip only
        // when a real title survives, never a lone word.
        return if (rest.split(' ').count { it.isNotBlank() } >= 2) rest else title
    }

    private val YEAR = Regex("(19|20)\\d{2}")
    private val BITRATE = Regex("\\d{2,4}\\s*kbps")

    /**
     * Removes release tokens. A lone year (`1984`) is a plausible title, so
     * years are only dropped when something meaningful remains without them.
     */
    private fun dropJunkTokens(s: String): String {
        val words = s.split(" ")
        fun isJunk(word: String, dropYears: Boolean): Boolean {
            val raw = word.trim(',', ';', ':', '.', '!', '?')
            val bare = raw.lowercase()
            if (bare.isEmpty()) return true
            if (bare in JUNK_TOKENS) return true
            if (BITRATE.matches(bare)) return true
            if (isReleaseTag(raw, bare)) return true
            return dropYears && YEAR.matches(bare)
        }

        fun isBitrateNumber(i: Int): Boolean {
            val bare = words[i].trim(',', ';', ':', '.', '!', '?').lowercase()
            if (bare.isEmpty() || !bare.all { it.isDigit() }) return false
            val prev = if (i > 0) words[i - 1].trim(',', ';', ':', '.', '!', '?').lowercase() else ""
            val next = if (i < words.size - 1) words[i + 1].trim(',', ';', ':', '.', '!', '?').lowercase() else ""
            return prev in BITRATE_NEIGHBOURS || next in BITRATE_NEIGHBOURS
        }

        val withoutJunk = words.filterIndexed { i, w -> !isJunk(w, dropYears = false) && !isBitrateNumber(i) }
        // A year is release noise ("… 2007 FRENCH MP3") but it is also a real
        // title ("George Orwell - 1984"). It only drops when it is NOT the
        // only content and NOT what follows a separator.
        val withoutYears = withoutJunk.filterIndexed { k, w ->
            val bare = w.trim(',', ';', ':', '.', '!', '?')
            if (!YEAR.matches(bare)) return@filterIndexed true
            val prev = withoutJunk.getOrNull(k - 1)?.trim().orEmpty()
            val followsSeparator = prev.endsWith("-") || prev.endsWith("–") ||
                prev.endsWith("—") || prev.endsWith(":")
            val noLettersLeft = withoutJunk.count { it.any { c -> c.isLetter() } } <= 1
            followsSeparator || noLettersLeft
        }
        return (if (withoutYears.isNotEmpty()) withoutYears else withoutJunk).joinToString(" ")
    }

    /**
     * A hyphenated token is a release tag when it carries a digit ("m4b-k",
     * "mp3-320") or is written in capitals ("WEB-DL"). Words like "sci-fi"
     * or "va-t'en" are left alone.
     */
    private fun isReleaseTag(raw: String, bare: String): Boolean {
        if (!bare.matches(RELEASE_TAG_SHAPE)) return false
        val letters = raw.filter { it.isLetter() }
        return bare.any { it.isDigit() } || (letters.length >= 2 && letters.all { it.isUpperCase() })
    }

    private fun looksDotSeparated(s: String): Boolean {
        val dots = s.count { it == '.' || it == '_' }
        val spaces = s.count { it == ' ' }
        return dots >= 3 && dots > spaces
    }

    private fun stripJunkBrackets(s: String): String =
        BRACKETED.replace(s) { m ->
            val content = m.groupValues[1].trim()
            if (content.isEmpty() || isJunkContent(content)) "" else " ${content} "
        }

    /** True for bracket content that is release metadata rather than a subtitle. */
    private fun isJunkContent(content: String): Boolean {
        val tokens = content.lowercase().split(Regex("[\\s,;._/|+-]+")).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return true
        // A lone year, or a majority of junk tokens → metadata.
        if (tokens.size == 1 && tokens[0].matches(Regex("(19|20)\\d{2}"))) return true
        val junky = tokens.count { it in JUNK_TOKENS || it.matches(Regex("(19|20)\\d{2}")) || it.matches(Regex("\\d{2,3}kbps")) }
        return junky * 2 >= tokens.size
    }

    private fun stripReleaseGroup(s: String): String {
        val m = TRAILING_GROUP.find(s.trim()) ?: return s
        val tag = m.groupValues[1]
        val hasDigit = tag.any { it.isDigit() }
        val upper = tag.count { it.isUpperCase() }
        val letters = tag.count { it.isLetter() }
        val looksLikeGroup = letters >= 2 && (hasDigit || (letters >= 3 && upper == letters))
        return if (looksLikeGroup) s.trim().removeSuffix(m.value).trimEnd() else s
    }

    /** `LE NOM DU VENT` → `Le Nom du Vent`; leaves normal casing untouched. */
    private fun fixShouting(s: String): String {
        val letters = s.filter { it.isLetter() }
        if (letters.length < 4) return s
        val upperRatio = letters.count { it.isUpperCase() }.toDouble() / letters.length
        if (upperRatio < 0.8) return s
        val small = setOf("de", "du", "des", "la", "le", "les", "et", "au", "aux", "a", "à", "en", "un", "une", "sur", "sous", "of", "the", "and", "in", "on", "at", "to", "l'", "d'")
        return s.split(" ").mapIndexed { i, word ->
            val bare = word.lowercase().trim('\'')
            when {
                // Never lowercase the very first word of a title.
                i > 0 && bare in small && word.length <= 4 -> word.lowercase()
                else -> word.lowercase().replaceFirstChar { it.uppercaseChar() }
            }
        }.joinToString(" ")
    }

    /** Trims separators left behind when a "Tome 3" chunk is removed. */
    private fun tidy(part: String): String =
        part.trim().replace(Regex("(?:\\s*[-–—_:|,.]+\\s*)+$"), "").trim()

    /** `3.0` → "3", `2.5` → "2.5" — for readable volume numbers in titles. */
    private fun fmtIndex(index: Double): String =
        if (index % 1.0 == 0.0) index.toInt().toString() else index.toString()

    /** Everything left in the raw string after the matched volume number. */
    private fun tailAfter(s: String, matchEnd: Int): String =
        s.substring(matchEnd.coerceAtMost(s.length)).trim().replace(Regex("^[-–—_:|,.]\\s*"), "").trim()

    private data class Extracted(
        val title: String,
        val author: String? = null,
        val series: String? = null,
        val index: Double? = null,
    )

    /**
     * Detects saga + volume so books of the same saga stay together even when
     * their torrent names differ ("Auteur - Saga 2 - Sous-titre", "Saga - Tome 2",
     * "Saga 05", "#12", leading track number…).
     */
    private fun extractSeries(s: String): Extracted {
        SERIES_WORD.find(s)?.let { m ->
            val series = tidy(m.groups["series"]?.value.orEmpty())
            val index = m.groups["index"]?.value?.replace(',', '.')?.toDoubleOrNull()
            if (series.length >= 2 && index != null) {
                val sub = tailAfter(s, m.range.last + 1)
                val title = buildString {
                    append(series).append(' ').append(fmtIndex(index))
                    if (sub.isNotEmpty()) append(" - ").append(sub)
                }
                return Extracted(title, null, series, index)
            }
        }
        SERIES_HASH.find(s)?.let { m ->
            val series = tidy(m.groups["series"]?.value.orEmpty())
            val index = m.groups["index"]?.value?.toDoubleOrNull()
            if (series.length >= 2 && index != null) {
                val sub = tailAfter(s, m.range.last + 1)
                val title = buildString {
                    append(series).append(' ').append(fmtIndex(index))
                    if (sub.isNotEmpty()) append(" - ").append(sub)
                }
                return Extracted(title, null, series, index)
            }
        }
        // "Saga 03 Subtitle" (volume number in the MIDDLE, author elsewhere).
        //
        // v0.7.4 — the old guard rejected any tail holding a digit, so
        // "Les Archives de Roshar 05 Vent et verite 2" (a part number in the
        // subtitle) was not parsed at all and the whole folder name went to
        // Audible as ONE query. Now the tail only has to LOOK like a title;
        // what protects "Le Sang des 7 Rois 1" is the word before the number
        // ("des" links it to what follows, so 7 is part of the title).
        SERIES_EMBEDDED.find(s)?.let { m ->
            val series = tidy(m.groups["series"]?.value.orEmpty())
            val index = m.groups["index"]?.value?.toDoubleOrNull()
            val sub = m.groups["sub"]?.value?.trim().orEmpty()
            val words = series.split(" ").filter { it.isNotBlank() }
            val last = words.lastOrNull()?.lowercase()?.trim('\'', '-') ?: ""
            val tailWords = sub.split(" ").filter { it.isNotBlank() }
            val headOk = words.size >= 2 &&
                words.none { w -> w.any { it.isDigit() } } &&
                last.length >= 3 && last !in LINK_WORDS
            val tailOk = tailWords.size >= 2 &&
                sub.count { it.isLetter() } >= 4 &&
                tailWords.any { w -> w.any { it.isLetter() } }
            if (headOk && tailOk && index != null && index >= 1.0) {
                val title = buildString {
                    append(series).append(' ').append(fmtIndex(index))
                    if (sub.isNotEmpty()) append(" - ").append(sub)
                }
                return Extracted(title, null, series, index)
            }
        }
        // "Author - Saga N [- subtitle]": split the person's name out so every
        // volume of the saga shares one series key regardless of the prefix.
        AUTHOR_SERIES_NUM.find(s)?.let { m ->
            val author = m.groups["author"]?.value?.trim().orEmpty()
            val series = tidy(m.groups["series"]?.value.orEmpty())
            val index = m.groups["index"]?.value?.replace(',', '.')?.toDoubleOrNull()
            val sub = m.groups["sub"]?.value?.trim().orEmpty()
            val authorOk = author.split(" ").none { it.lowercase().trim('\'') in SMALL_WORDS }
            if (authorOk && series.length >= 2 && index != null) {
                val title = buildString {
                    append(series).append(' ').append(fmtIndex(index))
                    if (sub.isNotEmpty()) append(" - ").append(sub)
                }
                return Extracted(title, author, series, index)
            }
        }
        // "Saga N [- subtitle]" without an author prefix.
        SERIES_NUM.find(s)?.let { m ->
            val series = tidy(m.groups["series"]?.value.orEmpty())
            val index = m.groups["index"]?.value?.replace(',', '.')?.toDoubleOrNull()
            val sub = m.groups["sub"]?.value?.trim().orEmpty()
            // Without a subtitle the bare number must look like a volume (≤ 40),
            // otherwise "Studio 60" and friends would become phantom sagas.
            val plausible = series.length >= 3 && index != null && series.any { it.isLetter() } &&
                (sub.isNotEmpty() || index <= 40.0)
            if (plausible) {
                val title = buildString {
                    append(series).append(' ').append(fmtIndex(index))
                    if (sub.isNotEmpty()) append(" - ").append(sub)
                }
                return Extracted(title, null, series, index)
            }
        }
        // Leading track/volume number: keep it out of the title, remember the index.
        LEADING_NUMBER.find(s)?.let { m ->
            val rest = m.groups["rest"]?.value?.trim().orEmpty()
            val index = m.groups["index"]?.value?.replace(',', '.')?.toDoubleOrNull()
            if (rest.length >= 3 && index != null) return Extracted(rest, null, null, index)
        }
        return Extracted(s)
    }
}
