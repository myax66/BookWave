package dev.bookwave.app.data

import dev.bookwave.core.model.Audiobook
import dev.bookwave.core.model.Chapter
import dev.bookwave.core.model.SourceRef

/**
 * Offline sample library so the app is fully explorable before any cloud
 * account is configured (demo mode).
 */
object DemoLibrary {

    fun books(): List<Audiobook> = listOf(
        Audiobook(
            id = "demo:nom-du-vent",
            title = "Le Nom du Vent",
            author = "Patrick Rothfuss",
            narrator = "Jean-Pierre Michaël",
            series = "Le Royaume du Vent",
            seriesIndex = 1.0,
            durationMs = h(10, 24),
            chapters = chapters(
                "Prologue — Un silence à trois temps",
                "Chapitre 1 — Un endroit pour mourir",
                "Chapitre 2 — Bien se conduire",
                "Chapitre 3 — Mon client, l'étudiant",
                "Chapitre 4 — La route de Tarbean",
                "Chapitre 5 — Le sang et la poussière",
                "Épilogue — La route qui va vers la maison",
            ),
            source = SourceRef("demo", "démonstration", "/demo/nom-du-vent"),
        ),
        Audiobook(
            id = "demo:dune",
            title = "Dune",
            author = "Frank Herbert",
            narrator = "Bruno Choël",
            series = "Cycle de Dune",
            seriesIndex = 1.0,
            durationMs = h(21, 2),
            chapters = chapters(
                "Livre I — Arrakis",
                "Livre II — Muad'Dib",
                "Livre III — Le prophète",
            ),
            source = SourceRef("demo", "démonstration", "/demo/dune"),
        ),
        Audiobook(
            id = "demo:etranger",
            title = "L'Étranger",
            author = "Albert Camus",
            narrator = "Denis Podalydès",
            durationMs = h(3, 47),
            chapters = chapters(
                "Première partie",
                "Seconde partie",
            ),
            source = SourceRef("demo", "démonstration", "/demo/etranger"),
        ),
    )

    private fun h(hours: Int, minutes: Int): Long =
        (hours * 3_600_000L) + (minutes * 60_000L)

    /** Evenly spread chapters across the book, ~realistic lengths. */
    private fun chapters(vararg names: String): List<Chapter> {
        val each = 55 * 60_000L
        return names.mapIndexed { i, name ->
            Chapter(index = i, title = name, startMs = i * each, endMs = (i + 1) * each)
        }
    }
}
