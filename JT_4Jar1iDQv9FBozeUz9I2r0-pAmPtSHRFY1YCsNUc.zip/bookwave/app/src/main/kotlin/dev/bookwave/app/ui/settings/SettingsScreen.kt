package dev.bookwave.app.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import dev.bookwave.app.data.AppSettings
import dev.bookwave.app.data.BookRepository
import dev.bookwave.app.data.cloud.WebDavSource
import dev.bookwave.app.player.PlaybackService
import dev.bookwave.core.cloud.CloudEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material3.FilterChip
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.height
import kotlinx.coroutines.withContext

/**
 * Cloud source configuration: WebDAV / Nextcloud / ownCloud credentials with a
 * live connection test, plus the offline demo toggle. Values are stored via
 * [AppSettings]; the library screen reloads on return.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: (() -> Unit)? = null,
    onSaved: () -> Unit = {},
) {
    // Built from LocalContext — never depends on DI resolution (a missing Koin
    // definition must not crash this screen again).
    val context = LocalContext.current
    val settings = remember { AppSettings(context) }
    val scope = rememberCoroutineScope()

    // rememberSaveable: a half-typed URL/password survives rotation.
    var url by rememberSaveable { mutableStateOf(settings.webdavUrl) }
    var user by rememberSaveable { mutableStateOf(settings.webdavUser) }
    var password by rememberSaveable { mutableStateOf(settings.webdavPassword) }
    var demo by rememberSaveable { mutableStateOf(settings.demoMode) }
    var enrich by rememberSaveable { mutableStateOf(settings.enrichEnabled) }
    var enrichMarket by rememberSaveable { mutableStateOf(settings.enrichMarket) }
    var c411Url by rememberSaveable { mutableStateOf(settings.c411Url) }
    var c411Key by rememberSaveable { mutableStateOf(settings.c411ApiKey) }
    var tr4kerUrl by rememberSaveable { mutableStateOf(settings.tr4kerUrl) }
    var tr4kerKey by rememberSaveable { mutableStateOf(settings.tr4kerApiKey) }

    var testing by remember { mutableStateOf(false) }
    var testResult by rememberSaveable { mutableStateOf<String?>(null) }

    fun save() {
        val oldUrl = settings.webdavUrl
        val oldUser = settings.webdavUser
        val oldPassword = settings.webdavPassword
        val (u, usr, pwd) = normalizeWebDav(url, user, password)
        url = u
        user = usr
        password = pwd
        settings.webdavUrl = u
        settings.webdavUser = usr
        settings.webdavPassword = pwd
        settings.demoMode = demo
        settings.enrichEnabled = enrich
        settings.enrichMarket = enrichMarket
        settings.c411Url = c411Url
        settings.c411ApiKey = c411Key
        settings.tr4kerUrl = tr4kerUrl
        settings.tr4kerApiKey = tr4kerKey
        c411Url = settings.c411Url
        tr4kerUrl = settings.tr4kerUrl
        BookRepository.invalidateCache() // sources changed: reload from network
        // The playback service baked the OLD credentials into its data source
        // at creation: streaming would keep failing with silent 401s. Stop it
        // (after saving the position) so the next playback rebuilds it fresh.
        if (oldUrl != u || oldUser != usr || oldPassword != pwd) {
            PlaybackService.handleCredentialsChanged()
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            TopAppBar(
                title = { Text("Réglages") },
                navigationIcon = {
                    if (onBack != null) {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                        }
                    }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Card {
                Column(
                    Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text("Bookwave v0.8.0 (vc31) · moteur de métadonnées v10", style = MaterialTheme.typography.bodySmall)
                    Text("WebDAV / Nextcloud / ownCloud", style = MaterialTheme.typography.titleMedium)

                    OutlinedTextField(
                        value = url,
                        onValueChange = { url = it },
                        label = { Text("URL du compte") },
                        placeholder = { Text("https://cloud.exemple.fr/remote.php/dav/files/moi") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = user,
                        onValueChange = { user = it },
                        label = { Text("Identifiant") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Mot de passe / jeton d'application") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )

                    Text(
                        "💡 AllDebrid : URL = https://webdav.debrid.it/ — identifiant = votre clé API " +
                            "(alldebrid.com/apikeys) — mot de passe = eeeee",
                        style = MaterialTheme.typography.bodySmall,
                    )

                    Button(
                        onClick = {
                            save()
                            onSaved()
                            onBack?.invoke()
                        },
                        enabled = url.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Enregistrer et charger la bibliothèque") }

                    OutlinedButton(
                        onClick = {
                            testing = true
                            testResult = null
                            val (u, usr, pwd) = normalizeWebDav(url, user, password)
                            url = u
                            user = usr
                            password = pwd
                            scope.launch {
                                testResult = testConnection(u, usr, pwd)
                                testing = false
                            }
                        },
                        enabled = url.isNotBlank() && !testing,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text(if (testing) "Test en cours…" else "Tester la connexion") }

                    if (testing) CircularProgressIndicator(Modifier.padding(8.dp))
                    testResult?.let {
                        Text(it, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            Card {
                Column(
                    Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text("Catalogue (trackers)", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Recherche les livres audio des trackers ci-dessous et envoie-les à " +
                            "AllDebrid en un tap. Chaque site expose une API Torznab officielle.",
                        style = MaterialTheme.typography.bodyMedium,
                    )

                    Text(
                        "C411",
                        style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                    OutlinedTextField(
                        value = c411Url,
                        onValueChange = { c411Url = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("URL du site") },
                        placeholder = { Text("https://c411.org") },
                        singleLine = true,
                    )
                    OutlinedTextField(
                        value = c411Key,
                        onValueChange = { c411Key = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Clé API C411") },
                        placeholder = { Text("collée depuis ton profil C411") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                    )
                    Text(
                        "Où la trouver : c411.org → ton profil → Clés API (page « Integrations »).",
                        style = MaterialTheme.typography.bodySmall,
                    )

                    Text(
                        "TR4KER",
                        style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.padding(top = 10.dp),
                    )
                    OutlinedTextField(
                        value = tr4kerUrl,
                        onValueChange = { tr4kerUrl = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("URL du site") },
                        placeholder = { Text("https://tr4ker.net") },
                        singleLine = true,
                    )
                    OutlinedTextField(
                        value = tr4kerKey,
                        onValueChange = { tr4kerKey = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Clé API TR4KER") },
                        placeholder = { Text("collée depuis tes paramètres TR4KER") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                    )
                    Text(
                        "Où la trouver : tr4ker.net → Mon compte → Paramètres → section « Clé API ». " +
                            "Ces clés sont distinctes de ta clé AllDebrid et restent sur l'appareil.",
                        style = MaterialTheme.typography.bodySmall,
                    )

                    OutlinedButton(
                        onClick = {
                            save()
                            val enabled = listOfNotNull(
                                "C411".takeIf { settings.isC411Configured },
                                "TR4KER".takeIf { settings.isTr4kerConfigured },
                            )
                            testResult = if (enabled.isEmpty()) {
                                "Catalogue : aucune clé renseignée."
                            } else {
                                "Catalogue actif sur : ${enabled.joinToString(", ")}."
                            }
                        },
                        enabled = !testing,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Enregistrer les clés") }
                }
            }

            Card {
                Column(
                    Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text("Métadonnées (Audible)", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Bookwave identifie chaque livre dans le catalogue Audible : vrai titre, " +
                            "auteur, narrateur, durée réelle, couverture officielle et résumé " +
                            "remplacent ceux devinés depuis le nom de torrent. Les titres de vos " +
                            "livres sont donc envoyés à Amazon (marketplace choisie) — rien d'autre.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "Enrichissement automatique",
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.weight(1f),
                        )
                        Switch(checked = enrich, onCheckedChange = { enrich = it })
                    }
                    Text("Marché Audible préféré", style = MaterialTheme.typography.bodyMedium)
                    Row {
                        listOf("auto" to "Auto (FR puis US)", "fr" to "France", "com" to "International").forEach { (value, label) ->
                            FilterChip(
                                selected = enrichMarket == value,
                                onClick = { enrichMarket = value },
                                label = { Text(label) },
                            )
                            Spacer(Modifier.width(8.dp))
                        }
                    }
                    Text(
                        "Appliqué seul en cas de confiance élevée ; sinon choix parmi les éditions. " +
                            "Appui long sur un livre : fiche, autre édition, retrait.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    // v0.8.0 — this button was rendered TWICE, and each copy
                    // built a NEW MetadataStore: its own in-memory cache, which
                    // the library's real instance overwrote on its next write.
                    // Clearing the ledger from here therefore undid itself.
                    // The shared instance is resolved once per click instead.
                    Button(
                        onClick = {
                            runCatching {
                                org.koin.core.context.GlobalContext.get()
                                    .get<dev.bookwave.app.data.metadata.MetadataStore>()
                            }.getOrNull()?.let { store ->
                                store.clearTried()
                                store.flushNow()
                            }
                            settings.enrichPassRequested = true
                            testResult = "Registre effacé : rouvrez la bibliothèque pour relancer l'identification."
                        },
                    ) { Text("Relancer l'identification maintenant") }
                    Spacer(Modifier.height(16.dp))

                    Text("Mode démonstration", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Affiche une bibliothèque d'exemple hors-ligne (3 livres) pour explorer l'app sans configuration.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Switch(
                        checked = demo,
                        onCheckedChange = {
                            demo = it
                            save()
                        },
                    )
                }
            }

            Text(
                "Vos identifiants restent sur l'appareil. Une clé d'application Nextcloud est recommandée.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

/** Blocking PROPFIND on IO — returns a human-readable result line. */
private suspend fun testConnection(url: String, user: String, password: String): String =
    withContext(Dispatchers.IO) {
        runCatching {
            val entries: List<CloudEntry> = WebDavSource("test", url, user, password).list("/")
            val dirs = entries.count { it.isDirectory }
            buildString {
                append("✅ Connexion réussie — ${entries.size} élément(s) à la racine")
                if (entries.isNotEmpty()) {
                    append(" ($dirs dossier(s), ${entries.size - dirs} fichier(s))")
                } else {
                    append(" (dossier vide)")
                }
            }
        }.getOrElse { e ->
            when (e) {
                is java.net.UnknownHostException -> "❌ Serveur introuvable — vérifiez l'adresse"
                is java.net.SocketTimeoutException -> "❌ Délai dépassé — le serveur ne répond pas"
                is javax.net.ssl.SSLException -> "❌ Erreur de certificat SSL — ${e.message}"
                is IllegalArgumentException -> "❌ URL invalide — elle doit commencer par https://"
                else -> "❌ ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

/**
 * AllDebrid & co convenience: accepts davs:// scheme and the key-in-URL form
 * https://webdav.debrid.it/<APIKEY>; fills the ignored password placeholder.
 */
private fun normalizeWebDav(url: String, user: String, password: String): Triple<String, String, String> {
    var u = url.trim()
    var usr = user.trim()
    var pwd = password
    if (u.startsWith("davs://")) u = "https://" + u.removePrefix("davs://")
    val key = Regex("^https?://webdav\\.debrid\\.it/([^/]+)/?$").find(u)
    if (key != null) {
        if (usr.isEmpty()) usr = key.groupValues[1]
        u = "https://webdav.debrid.it/"
    }
    if (usr.isNotEmpty() && pwd.isEmpty() && u.contains("debrid.it")) pwd = "eeeee"
    return Triple(u, usr, pwd)
}
