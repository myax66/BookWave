package dev.bookwave.core.cloud

/**
 * Provider-agnostic view of a cloud storage account.
 *
 * Implementations live in the app module (WebDAV, Dropbox, Drive…). The core
 * only reasons about entries and streamable paths, so library/sync logic stays
 * testable without any SDK.
 */
interface CloudSource {
    val provider: String
    val account: String

    suspend fun list(path: String): List<CloudEntry>

    suspend fun stat(path: String): CloudEntry?

    /** Resolvable URL the player can stream from (may require auth headers). */
    suspend fun streamUrl(path: String): String
}

data class CloudEntry(
    val path: String,
    val name: String,
    val isDirectory: Boolean,
    val sizeBytes: Long,
    val modifiedEpochMs: Long,
    val mediaKind: MediaKind,
)

enum class MediaKind {
    AUDIO, COVER, OTHER;

    companion object {
        private val AUDIO_EXT = setOf("mp3", "m4a", "m4b", "aac", "ogg", "oga", "opus", "flac", "wav")
        private val COVER_EXT = setOf("jpg", "jpeg", "png", "webp")

        fun of(fileName: String): MediaKind {
            val ext = fileName.substringAfterLast('.', "").lowercase()
            return when {
                ext in AUDIO_EXT -> AUDIO
                ext in COVER_EXT -> COVER
                else -> OTHER
            }
        }
    }
}
