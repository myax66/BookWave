package dev.bookwave.app.data.torznab

import android.util.Xml
import dev.bookwave.app.util.Http
import dev.bookwave.app.util.await
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Request
import org.xmlpull.v1.XmlPullParser
import java.io.IOException
import java.io.StringReader
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.LinkedHashMap
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Identity of a Torznab-speaking tracker.
 *
 * Endpoints differ per site, so each profile lists the paths to try in order:
 *  - C411 documents `https://c411.org/api` (Prowlarr style) and `/api/torznab`;
 *  - TR4KER serves searches from `https://tr4ker.net/api/torznab/all`
 *    (its `t=caps` lives on `/api/torznab`).
 */
data class TrackerProfile(
    val id: String,
    val label: String,
    val defaultUrl: String,
    val searchPaths: List<String>,
    /** Extra RSS-style listings tried only for the "latest additions" feed. */
    val feedPaths: List<String> = emptyList(),
    val audiobookCat: Int = 3030,
    /** Where the member finds their API key, shown in the settings screen. */
    val keyHint: String = "",
) {
    companion object {
        val C411 = TrackerProfile(
            id = "c411",
            label = "C411",
            defaultUrl = "https://c411.org",
            searchPaths = listOf("api", "api/torznab"),
            feedPaths = listOf("api/torrents"),
            keyHint = "c411.org → ton profil → Clés API (page « Integrations »)",
        )

        val TR4KER = TrackerProfile(
            id = "tr4ker",
            label = "TR4KER",
            defaultUrl = "https://tr4ker.net",
            searchPaths = listOf("api/torznab/all", "api/torznab", "api"),
            // TR4KER is global freeleech: downloads never count against the ratio.
            keyHint = "tr4ker.net → Mon compte → Paramètres → section « Clé API »",
        )

        val ALL = listOf(C411, TR4KER)
    }
}

/**
 * Generic Torznab client (the protocol Prowlarr/Sonarr/Jackett speak).
 *
 * A search is `GET <base>/<path>?apikey=KEY&t=search&q=…&cat=3030&extended=1`,
 * answered as RSS whose `<item>` elements carry `<enclosure url=…>` (the
 * .torrent link) plus torznab attributes: size, seeders, peers, infohash,
 * grabs, downloadvolumefactor (0 = freeleech).
 *
 * Two parsing details that bite:
 *  - `t=` is mandatory. Omitting it makes the site answer its HTML app shell,
 *    which is why the "latest additions" feed used to fail with "réponse non XML".
 *  - namespaces are disabled, so qualified names keep their prefix
 *    (`torznab:attr`, `torrent:seeders`). Every name is reduced to its local
 *    part before matching, otherwise all extended attributes are dropped.
 *
 * These trackers are private: the .torrent they hand back embeds the member's
 * passkey, so [downloadTorrent] output is personal and must never be shared.
 */
class TorznabApi(
    val profile: TrackerProfile,
    baseUrl: String,
    private val apiKey: String,
) {

    val label: String get() = profile.label

    private val base = baseUrl.trim().trimEnd('/').removeSuffix("/api").ifBlank { profile.defaultUrl }

    // Shares the app-wide connection pool (see dev.bookwave.app.util.Http).
    private val client = Http.shared.newBuilder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    /**
     * url -> (ETag, body). Trackers cache the feed, so honour conditional GETs.
     * Synchronized (queries fan out over IO threads) and BOUNDED: URLs embed the
     * query string, an old plain HashMap grew forever.
     */
    private val etagCache: MutableMap<String, Pair<String, String>> = Collections.synchronizedMap(
        object : LinkedHashMap<String, Pair<String, String>>(16, 0.75f, true) {
            override fun removeEldestEntry(
                eldest: MutableMap.MutableEntry<String, Pair<String, String>>?,
            ): Boolean = size > 32
        },
    )

    /** One catalogue entry. */
    data class Release(
        val source: String,
        val guid: String,
        val title: String,
        val sizeBytes: Long,
        /** null when the indexer did not expose the stat — never defaulted to 0. */
        val seeders: Int?,
        val peers: Int?,
        val grabs: Int,
        val infohash: String,
        val magnetUrl: String,
        val enclosureUrl: String,
        val detailsUrl: String,
        val pubDate: String,
        val dateMillis: Long,
        val downloadVolumeFactor: Double,
        val category: String,
    ) : java.io.Serializable {
        val isFreeleech: Boolean get() = downloadVolumeFactor <= 0.0

        /** Stable identity for UI state maps (unique across trackers). */
        val key: String
            get() = "$source|${guid.ifBlank { infohash.ifBlank { title } }}"

        val sizeLabel: String get() = humanSize(sizeBytes)
    }

    /** Free-text search in the audiobook category. */
    suspend fun search(
        query: String,
        cat: Int = profile.audiobookCat,
        limit: Int = 50,
        offset: Int = 0,
    ): List<Release> = withContext(Dispatchers.IO) {
        val params = linkedMapOf(
            "t" to "search",
            "q" to query.trim(),
            "cat" to cat.toString(),
            "limit" to limit.toString(),
            "offset" to offset.toString(),
            "extended" to "1",
        )
        val xml = request(params)
        errorIn(xml)?.let { throw IOException(it) }
        parseReleases(xml)
    }

    /**
     * Newest releases of a category — the RSS-style feed Prowlarr polls.
     * Indexers disagree on how "everything recent" is requested, so the
     * variants are tried in order and the first that answers wins.
     */
    suspend fun latest(
        cat: Int = profile.audiobookCat,
        limit: Int = 50,
    ): List<Release> = withContext(Dispatchers.IO) {
        val common = linkedMapOf(
            "t" to "search",
            "cat" to cat.toString(),
            "limit" to limit.toString(),
            "offset" to "0",
            "extended" to "1",
        )
        val attempts = buildList {
            profile.searchPaths.forEach { add(Attempt(it, common)) }
            add(Attempt(profile.searchPaths.first(), common + ("q" to "")))
            profile.feedPaths.forEach { add(Attempt(it, linkedMapOf("cat" to cat.toString()))) }
        }

        var meaningful: String? = null
        var last: String = "Aucune nouveauté renvoyée"
        for (attempt in attempts) {
            try {
                val xml = fetch(attempt.path, attempt.params)
                errorIn(xml)?.let { throw IOException(it) }
                val items = parseReleases(xml)
                if (items.isNotEmpty()) {
                    return@withContext items.sortedByDescending { it.dateMillis }.take(limit)
                }
                last = "Aucune nouveauté renvoyée par $label"
            } catch (e: IOException) {
                val message = e.message.orEmpty()
                last = message
                // Prefer a real API/HTTP complaint over the generic "not XML".
                if (meaningful == null && !message.contains("non XML", ignoreCase = true)) {
                    meaningful = message
                }
            }
        }
        throw IOException(meaningful ?: "$last (via ${profile.searchPaths.joinToString(", ")})")
    }

    /**
     * Downloads the .torrent behind a release (it carries the member passkey).
     * Returns the file name to hand to AllDebrid plus the raw bytes.
     */
    suspend fun downloadTorrent(
        url: String,
        fileNameHint: String? = null,
    ): Pair<String, ByteArray> = withContext(Dispatchers.IO) {
        if (url.isBlank()) throw IOException("Ce résultat n'expose aucun lien de téléchargement")
        if (url.startsWith("magnet:")) {
            throw IOException("Lien magnet seul : un tracker privé exige le fichier .torrent")
        }

        val response = client.newCall(
            Request.Builder().url(withAuth(url)).header("Accept", "*/*").get().build(),
        ).await()

        response.use { resp ->
            if (!resp.isSuccessful) throw IOException(frenchHttp(resp.code))
            val bytes = resp.body?.bytes() ?: ByteArray(0)
            if (bytes.isEmpty()) throw IOException("Fichier .torrent vide")
            // A .torrent is a bencoded dict: it always starts with 'd'.
            if (bytes[0] != 'd'.code.toByte()) {
                throw IOException("$label n'a pas renvoyé de .torrent (clé API refusée ?)")
            }
            fileName(resp.header("Content-Disposition"), fileNameHint) to bytes
        }
    }

    // --- transport -------------------------------------------------------

    private data class Attempt(val path: String, val params: Map<String, String>)

    /** Tries every documented endpoint spelling until one answers XML. */
    private suspend fun request(params: Map<String, String>): String {
        var last: IOException? = null
        for (path in profile.searchPaths) {
            try {
                return fetch(path, params)
            } catch (e: IOException) {
                last = e
            }
        }
        throw last ?: IOException("$label injoignable")
    }

    private suspend fun fetch(path: String, params: Map<String, String>): String {
        val url = "$base/$path".toHttpUrlOrNull()?.newBuilder()
            ?.addQueryParameter("apikey", apiKey)
            ?.apply { params.forEach { (k, v) -> addQueryParameter(k, v) } }
            ?.build()
            ?: throw IOException("URL $label invalide : $base/$path")

        val cacheKey = url.toString()
        val cached = etagCache[cacheKey]

        val builder = Request.Builder()
            .url(url)
            .header("Accept", "application/xml, text/xml")
        cached?.let { builder.header("If-None-Match", it.first) }

        val response = client.newCall(builder.get().build()).await()

        response.use { resp ->
            // 304: unchanged since the cached ETag — reuse the stored body.
            if (resp.code == 304 && cached != null) return cached.second
            if (!resp.isSuccessful) throw IOException(frenchHttp(resp.code))
            val body = resp.body?.string().orEmpty()
            val trimmed = body.trim()
            if (!trimmed.startsWith("<") || trimmed.startsWith("<!DOCTYPE html", true)) {
                throw IOException("$label a répondu une page non XML (clé API refusée ?)")
            }
            resp.header("ETag")?.takeIf { it.isNotBlank() }?.let { etagCache[cacheKey] = it to body }
            return body
        }
    }

    private fun withAuth(url: String): String {
        if (url.contains("apikey=", true) || url.contains("passkey=", true)) return url
        val sep = if (url.contains('?')) '&' else '?'
        return "$url${sep}apikey=$apiKey"
    }

    // --- XML -------------------------------------------------------------

    private fun parseReleases(xml: String): List<Release> {
        val parser = newParser(xml)
        val out = ArrayList<Release>()
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && localName(parser) == "item") {
                out += parseItem(parser)
            }
            event = parser.next()
        }
        return out
    }

    /** Reads one `<item>`; leaves the parser on its END_TAG. */
    private fun parseItem(parser: XmlPullParser): Release {
        var title = ""
        var guid = ""
        var link = ""
        var comments = ""
        var pubDate = ""
        var category = ""
        var enclosure = ""
        var enclosureLength = 0L
        var attrSize = 0L
        var seeders: Int? = null
        var leechers: Int? = null
        var peers: Int? = null
        var grabs = 0
        var infohash = ""
        var magnet = ""
        var dvf = Double.NaN

        while (true) {
            val event = parser.next()
            val name = localName(parser)
            if (event == XmlPullParser.END_TAG && name == "item") {
                return build(
                    guid = guid,
                    title = title,
                    size = if (attrSize > 0) attrSize else enclosureLength,
                    seeders = seeders,
                    leechers = leechers,
                    peers = peers,
                    grabs = grabs,
                    infohash = infohash,
                    magnet = magnet,
                    enclosure = enclosure,
                    link = link,
                    comments = comments,
                    pubDate = pubDate,
                    dvf = if (dvf.isNaN()) 1.0 else dvf,
                    category = category,
                )
            }
            if (event != XmlPullParser.START_TAG) continue

            when (name) {
                "title" -> title = parser.nextText().trim()
                "guid" -> guid = parser.nextText().trim()
                "link" -> link = parser.nextText().trim()
                "comments" -> comments = parser.nextText().trim()
                "pubDate" -> pubDate = parser.nextText().trim()

                "category" -> {
                    category = parser.getAttributeValue(null, "domain").orEmpty()
                    if (category.isBlank()) category = parser.nextText().trim()
                }

                "enclosure" -> {
                    enclosure = parser.getAttributeValue(null, "url").orEmpty().trim()
                    enclosureLength =
                        parser.getAttributeValue(null, "length")?.toLongOrNull() ?: 0L
                }

                // torznab:attr — namespaces off means the prefix is part of the name.
                "attr" -> {
                    val attr = parser.getAttributeValue(null, "name")
                    val value = parser.getAttributeValue(null, "value").orEmpty()
                    when (attr) {
                        "size" -> attrSize = value.toLongOrNull() ?: attrSize
                        "seeders" -> seeders = value.toIntOrNull() ?: seeders
                        "leechers" -> leechers = value.toIntOrNull() ?: leechers
                        "peers" -> peers = value.toIntOrNull() ?: peers
                        "grabs" -> grabs = value.toIntOrNull() ?: grabs
                        "infohash" -> infohash = value.trim()
                        "magneturl" -> magnet = value.trim()
                        "downloadvolumefactor" -> dvf = value.toDoubleOrNull() ?: dvf
                        "category" -> if (category.isBlank()) category = value.trim()
                    }
                }

                // Some indexers also emit the <torrent:*> RSS elements.
                "seeders" -> seeders = parser.nextText().trim().toIntOrNull() ?: seeders
                "leechers" -> leechers = parser.nextText().trim().toIntOrNull() ?: leechers
                "peers" -> peers = parser.nextText().trim().toIntOrNull() ?: peers
                "grabs" -> grabs = parser.nextText().trim().toIntOrNull() ?: grabs
                "infohash" -> infohash = parser.nextText().trim().ifBlank { infohash }
                "magneturi" -> magnet = parser.nextText().trim().ifBlank { magnet }
            }
        }
    }

    private fun build(
        guid: String,
        title: String,
        size: Long,
        seeders: Int?,
        leechers: Int?,
        peers: Int?,
        grabs: Int,
        infohash: String,
        magnet: String,
        enclosure: String,
        link: String,
        comments: String,
        pubDate: String,
        dvf: Double,
        category: String,
    ): Release = Release(
        source = label,
        guid = guid,
        title = title,
        sizeBytes = size,
        seeders = seeders,
        // TR4KER uses "peers" for the leecher count; keep both readings available.
        peers = peers ?: if (seeders != null && leechers != null) seeders + leechers else null,
        grabs = grabs,
        infohash = infohash.ifBlank { magnetInfohash(magnet) },
        magnetUrl = magnet,
        enclosureUrl = enclosure.ifBlank { link },
        detailsUrl = comments.ifBlank { link },
        pubDate = pubDate,
        dateMillis = parseDate(pubDate),
        downloadVolumeFactor = dvf,
        category = category,
    )

    private fun newParser(xml: String): XmlPullParser =
        Xml.newPullParser().apply {
            setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            setInput(StringReader(xml))
        }

    /** Local part only: "torznab:attr" and "attr" both reduce to "attr". */
    private fun localName(parser: XmlPullParser): String =
        parser.name?.substringAfterLast(':').orEmpty()

    /** `<error code="100" description="…"/>` inside an otherwise valid RSS. */
    private fun errorIn(xml: String): String? {
        val parser = newParser(xml)
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && localName(parser) == "error") {
                val code = parser.getAttributeValue(null, "code").orEmpty()
                val description = parser.getAttributeValue(null, "description").orEmpty()
                return frenchTorznabError(code, description)
            }
            event = parser.next()
        }
        return null
    }

    // --- helpers ---------------------------------------------------------

    private val datePatterns = listOf(
        "EEE, dd MMM yyyy HH:mm:ss Z",
        "EEE, dd MMM yyyy HH:mm:ss zzz",
        "EEE, dd MMM yyyy HH:mm:ss",
        "dd MMM yyyy HH:mm:ss Z",
        "yyyy-MM-dd HH:mm:ss",
        "yyyy-MM-dd'T'HH:mm:ss",
        "yyyy-MM-dd",
    )

    /** Tolerant RFC822/ISO date parsing — 0 when absent or oddly formatted. */
    private fun parseDate(raw: String): Long {
        val value = raw.trim()
        if (value.isEmpty()) return 0L
        val normalized = value.replace("GMT", "+0000").replace("UTC", "+0000")
        for (pattern in datePatterns) {
            try {
                val format = SimpleDateFormat(pattern, Locale.US)
                format.isLenient = true
                return format.parse(normalized)?.time ?: continue
            } catch (_: Exception) {
                // next pattern
            }
        }
        return 0L
    }

    private fun frenchTorznabError(code: String, description: String): String {
        val detail = description.ifBlank { "erreur $code" }
        return when (code) {
            "100" -> "$label : clé API refusée — vérifie-la ($detail)"
            "101" -> "$label : compte suspendu ($detail)"
            "200", "201" -> "$label : requête incorrecte ($detail)"
            "300" -> "$label : aucun résultat"
            "500" -> "$label : erreur interne du tracker ($detail)"
            else -> "$label : $detail"
        }
    }

    private fun frenchHttp(code: Int): String = when (code) {
        401, 403 -> "$label : accès refusé (HTTP $code) — clé API invalide ou expirée"
        404 -> "$label : API introuvable (HTTP 404) — vérifie l'URL du site"
        429 -> "$label : trop de requêtes (HTTP 429) — réessaie dans une minute"
        in 500..599 -> "$label : erreur du serveur (HTTP $code)"
        else -> "$label a répondu HTTP $code"
    }

    private fun fileName(disposition: String?, hint: String?): String {
        disposition?.let { header ->
            Regex("filename\\*?=(?:UTF-8'')?\"?([^\";]+)\"?", RegexOption.IGNORE_CASE)
                .find(header)?.groupValues?.get(1)?.trim()
                ?.let { if (it.isNotBlank()) return it }
        }
        val cleaned = hint?.replace(Regex("[\\\\/:*?\"<>|]"), "_")?.trim().orEmpty()
        val stem = cleaned.ifBlank { "torrent" }.take(80)
        return if (stem.endsWith(".torrent", true)) stem else "$stem.torrent"
    }

    private fun magnetInfohash(magnet: String): String {
        if (magnet.isBlank()) return ""
        val m = Regex("btih:([a-fA-F0-9]{40}|[a-zA-Z2-7]{32})", RegexOption.IGNORE_CASE)
            .find(magnet) ?: return ""
        return m.groupValues[1].lowercase(Locale.ROOT)
    }

    companion object {
        const val CAT_AUDIOBOOK = 3030
        const val CAT_EBOOK = 7020
        const val CAT_COMICS = 7030
        const val CAT_MUSIC = 3010

        fun humanSize(bytes: Long): String {
            if (bytes <= 0) return "—"
            val units = arrayOf("o", "Ko", "Mo", "Go", "To")
            var value = bytes.toDouble()
            var i = 0
            while (value >= 1024 && i < units.lastIndex) {
                value /= 1024.0
                i++
            }
            val decimals = if (value >= 100 || i == 0) 0 else 1
            return String.format(Locale.FRANCE, "%.${decimals}f %s", value, units[i])
        }

        /** Compact French age for the "latest additions" list. */
        fun relativeDate(millis: Long): String {
            if (millis <= 0L) return ""
            val minutes = (System.currentTimeMillis() - millis) / 60_000
            return when {
                minutes < 1 -> "à l'instant"
                minutes < 60 -> "il y a $minutes min"
                minutes < 1_440 -> "il y a ${minutes / 60} h"
                minutes < 2_880 -> "hier"
                minutes < 10_080 -> "il y a ${minutes / 1_440} j"
                else -> SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(millis))
            }
        }
    }
}
