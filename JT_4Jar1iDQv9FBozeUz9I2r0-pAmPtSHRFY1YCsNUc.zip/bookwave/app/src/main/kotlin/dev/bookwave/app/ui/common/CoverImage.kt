package dev.bookwave.app.ui.common

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Base64
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.List
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import dev.bookwave.app.data.AppSettings
import dev.bookwave.app.util.Http
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.Locale
import java.security.MessageDigest
import java.util.Collections
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit

/**
 * Cover art loader.
 *
 * Two sources, because audiobook folders rarely ship a cover file:
 *  1. an image file next to the audio (jpg/png/webp) → plain authenticated GET
 *  2. artwork EMBEDDED in the mp3/m4b → MediaMetadataRetriever, exactly like
 *     the media notification does
 *
 * Results are cached in memory (LRU) and on disk, so scrolling a big library —
 * or relaunching the app — never re-downloads artwork.
 */
object CoverCache {

    /** Sized in BYTES (~8 MB of decoded 256 px covers), not in entry count. */
    private val memory = object : LruCache<String, Bitmap>(8 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    /** Mutated from several IO threads — a plain mutableSet was a data race. */
    private val knownMissing: MutableSet<String> = Collections.synchronizedSet(HashSet())

    /** Extraction over the network is slow: keep at most 2 in flight. */
    private val gate = Semaphore(2)

    @Volatile
    private var http: OkHttpClient? = null

    private fun client(context: Context): OkHttpClient =
        http ?: synchronized(this) {
            http ?: Http.shared.newBuilder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .addInterceptor { chain ->
                    val settings = AppSettings(context)
                    val request = chain.request()
                    // Origin check (v0.7.0): the WebDAV credentials used to be
                    // attached to EVERY cover request, including Audible's
                    // m.media-amazon.com artwork — a third party was being
                    // handed the user's WebDAV account.
                    val davHost = runCatching {
                        settings.webdavUrl.trim().toHttpUrl().host
                    }.getOrNull()
                    val req = if (
                        settings.webdavUser.isBlank() || davHost == null ||
                        !request.url.host.equals(davHost, ignoreCase = true)
                    ) {
                        request
                    } else {
                        request.newBuilder().header("Authorization", authHeader(context)).build()
                    }
                    chain.proceed(req)
                }
                .build()
                .also { http = it }
        }

    private fun authHeader(context: Context): String {
        val settings = AppSettings(context)
        return "Basic " + Base64.encodeToString(
            "${settings.webdavUser}:${settings.webdavPassword}".toByteArray(),
            Base64.NO_WRAP,
        )
    }

    private fun diskDir(context: Context): File =
        File(context.cacheDir, "covers").apply {
            if (!exists()) mkdirs()
            pruneDisk(this)
        }

    /**
     * The cover cache had no ceiling: every re-identification produced a new
     * URL hash and the old file stayed forever. Trim to [DISK_BUDGET] by
     * last-modified, once per process.
     */
    private fun pruneDisk(dir: File) {
        if (pruned) return
        pruned = true
        runCatching {
            val files = dir.listFiles()?.filter { it.isFile } ?: return@runCatching
            var total = files.sumOf { it.length() }
            if (total <= DISK_BUDGET) return@runCatching
            files.sortedBy { it.lastModified() }.forEach { f ->
                if (total <= DISK_BUDGET) return@forEach
                total -= f.length()
                f.delete()
            }
        }
    }

    @Volatile
    private var pruned = false
    private const val DISK_BUDGET = 150L * 1024 * 1024

    private fun diskFile(context: Context, url: String, missing: Boolean): File {
        // Locale.ROOT: "%02x".format() renders non-ASCII digits under some
        // locales (ar/fa), which would change file names between sessions and
        // orphan the cache.
        val hash = MessageDigest.getInstance("SHA-1")
            .digest(url.toByteArray()).joinToString("") { String.format(Locale.ROOT, "%02x", it) }
        return File(diskDir(context), hash + if (missing) ".none" else ".img")
    }

    fun peek(url: String?): Bitmap? = url?.let { memory.get(it) }

    /**
     * `file://` URI of the on-disk cached cover, when already downloaded —
     * used for the media NOTIFICATION artwork: the system loader cannot send
     * WebDAV auth headers, but it reads local files fine. Null when uncached.
     */
    fun diskUriIfCached(context: Context, url: String?): String? {
        if (url.isNullOrBlank()) return null
        val f = diskFile(context, url, missing = false)
        return if (f.exists()) Uri.fromFile(f).toString() else null
    }

    /** Blocking load — call from a background dispatcher. */
    fun load(context: Context, url: String): Bitmap? {
        memory.get(url)?.let { return it }
        if (knownMissing.contains(url)) return null

        val imgFile = diskFile(context, url, missing = false)
        val noneFile = diskFile(context, url, missing = true)
        if (noneFile.exists()) {
            knownMissing += url
            return null
        }
        if (imgFile.exists()) {
            val bmp = decodeScaled(imgFile.readBytes())
            if (bmp != null) {
                memory.put(url, bmp)
                return bmp
            }
            imgFile.delete()
        }

        val bytes = gate.withPermit { fetchArtwork(context, url) }
        val bmp = bytes?.let { decodeScaled(it) }
        return if (bmp != null) {
            runCatching { imgFile.writeBytes(bytes!!) }
            memory.put(url, bmp)
            bmp
        } else {
            runCatching { noneFile.writeText("0") }
            knownMissing += url
            null
        }
    }

    private fun fetchArtwork(context: Context, url: String): ByteArray? {
        val ext = url.substringAfterLast('.', "").substringBefore('?').lowercase(Locale.ROOT)
        if (ext in IMAGE_EXT) {
            download(context, url)?.let { if (decodeScaled(it) != null) return it }
        }
        // Embedded artwork (also the fallback when an image URL 404s).
        return embeddedArtwork(context, url)
    }

    private fun download(context: Context, url: String): ByteArray? = runCatching {
        client(context).newCall(Request.Builder().url(url).build()).execute().use { resp ->
            if (!resp.isSuccessful) null else resp.body?.bytes()
        }
    }.getOrNull()

    private fun embeddedArtwork(context: Context, url: String): ByteArray? = runCatching {
        val retriever = MediaMetadataRetriever()
        try {
            val headers = if (AppSettings(context).webdavUser.isBlank()) {
                emptyMap()
            } else {
                mapOf("Authorization" to authHeader(context))
            }
            retriever.setDataSource(url, headers)
            retriever.embeddedPicture
        } finally {
            runCatching { retriever.release() }
        }
    }.getOrNull()

    /** Decodes at ~256 px max — full covers are heavy in a long list. */
    private fun decodeScaled(bytes: ByteArray): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 256) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }

    private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp")

    private inline fun <T> Semaphore.withPermit(block: () -> T): T {
        acquire()
        try {
            return block()
        } finally {
            release()
        }
    }
}

/** Rounded cover thumbnail with a graceful placeholder when missing. */
@Composable
fun CoverImage(url: String?, size: Dp, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var bitmap by remember(url) { mutableStateOf(CoverCache.peek(url)) }

    LaunchedEffect(url) {
        if (url != null && bitmap == null) {
            bitmap = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                CoverCache.load(context, url)
            }
        }
    }

    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        val bmp = bitmap
        if (bmp != null) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            Icon(
                Icons.Default.List,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
