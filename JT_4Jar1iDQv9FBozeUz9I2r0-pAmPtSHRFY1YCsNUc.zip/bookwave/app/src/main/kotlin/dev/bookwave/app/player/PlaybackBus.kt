package dev.bookwave.app.player

import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Lightweight "now playing" bridge between the player screen and the library
 * mini-player. Playback itself lives in [PlaybackService]; this carries the
 * book identity so the library can show a pause/resume bar after the player
 * screen is closed — and so the SERVICE can persist progress in the background
 * (it needs bookId + chapterCount to build a [dev.bookwave.core.model.ListeningProgress]).
 */
object PlaybackBus {

    data class NowPlaying(
        val bookId: String,
        val title: String,
        val artist: String? = null,
        val coverUrl: String? = null,
        /** Number of playable chapters; 0 disables service-side progress saves. */
        val chapterCount: Int = 0,
    )

    val nowPlaying = MutableStateFlow<NowPlaying?>(null)
}
