package dev.bookwave.core.library

import dev.bookwave.core.cloud.CloudEntry

/**
 * Picks which image of a book folder becomes the displayed cover.
 *
 * Naive "first image of the folder" selection shows tracker logos: private
 * torrents ship their banner (e.g. the C411 logo) alongside the real cover,
 * and directory order put it first. Scores names instead:
 *  +4 explicit cover markers (cover/front/folder/pochette…),
 *  +3 name echoing the folder name (scans name files after the book),
 *  −6 known non-cover artifacts (logo/banner/back/disc/playlist…),
 * then largest file wins (covers outweigh thumbnails), then name for stability.
 */
object CoverPicker {

    private val GOOD = Regex("cover|front|folder|artwork|poster|jaquette|pochette", RegexOption.IGNORE_CASE)
    private val BAD = Regex("logo|banner|back|inside|disc|cd\\d|playlist|bookmark|nfo|fanart|thumb|watermark", RegexOption.IGNORE_CASE)

    fun choose(covers: List<CloudEntry>, folderName: String = ""): CloudEntry? {
        if (covers.isEmpty()) return null
        val folder = folderName.trim().lowercase()
        return covers.maxWithOrNull(
            compareBy<CloudEntry> { score(it, folder) }
                .thenBy { it.sizeBytes }
                .thenBy { it.name },
        )
    }

    fun score(entry: CloudEntry, folderNameLower: String = ""): Int {
        var s = 0
        if (GOOD.containsMatchIn(entry.name)) s += 4
        if (folderNameLower.length >= 4 && entry.name.lowercase().startsWith(folderNameLower.take(12))) s += 3
        if (BAD.containsMatchIn(entry.name)) s -= 6
        return s
    }
}
