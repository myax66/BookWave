# Keep Media3 session glue and the core model names used by serializers.
-keep class dev.bookwave.core.** { *; }
-dontwarn org.slf4j.**
