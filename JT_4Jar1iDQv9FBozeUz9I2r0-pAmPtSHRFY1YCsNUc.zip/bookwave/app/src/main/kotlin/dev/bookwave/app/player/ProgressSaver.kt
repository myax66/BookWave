package dev.bookwave.app.player

import android.content.Context
import dev.bookwave.app.data.ProgressStore
import dev.bookwave.core.model.ListeningProgress
import java.time.Instant

/**
 * Single source of truth for turning player positions into [ListeningProgress]
 * records. Shared by the player UI AND the background service so both persist
 * the exact same format.
 *
 * Positions are stored against a pseudo-duration ([PROGRESS_SCALE] per chapter)
 * so the saved fraction survives chapter-count changes between scans: only the
 * ratio position/duration is meaningful, never the raw milliseconds.
 */
object ProgressSaver {

    private const val PROGRESS_SCALE = 10_000L

    /**
     * @param chapterCount number of playable files/chapters of the book
     * @param chapterIndex index of the chapter being played
     * @param positionInChapterMs player position inside that chapter
     * @param chapterDurationMs duration of that chapter (<= 0 when unknown)
     */
    fun snapshot(
        bookId: String,
        chapterCount: Int,
        chapterIndex: Int,
        positionInChapterMs: Long,
        chapterDurationMs: Long,
        speed: Float,
        deviceId: String,
    ): ListeningProgress? {
        if (bookId.isBlank() || chapterCount <= 0) return null
        val idx = chapterIndex.coerceIn(0, chapterCount - 1)
        val intra = if (chapterDurationMs > 0) {
            (positionInChapterMs.toDouble() / chapterDurationMs).coerceIn(0.0, 1.0)
        } else {
            0.0
        }
        val fraction = ((idx + intra) / chapterCount).coerceIn(0.0, 1.0)
        return ListeningProgress(
            bookId = bookId,
            positionMs = (fraction * PROGRESS_SCALE * chapterCount).toLong(),
            durationMs = PROGRESS_SCALE * chapterCount,
            speed = speed,
            completed = fraction >= 0.999,
            updatedAt = Instant.now(),
            deviceId = deviceId,
        )
    }

    /** Persists one snapshot; never throws (a failed save must not break playback). */
    suspend fun save(context: Context, entry: ListeningProgress?) {
        if (entry == null) return
        runCatching { ProgressStore(context).upsert(entry) }
    }
}
