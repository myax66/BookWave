package dev.bookwave.app.ui.player

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Forward30
import androidx.compose.material.icons.filled.Nightlight
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import dev.bookwave.app.data.AppSettings
import dev.bookwave.app.data.DemoLibrary
import dev.bookwave.app.data.ProgressStore
import dev.bookwave.app.data.cloud.WebDavSource
import dev.bookwave.app.player.PlaybackBus
import dev.bookwave.app.player.PlaybackService
import dev.bookwave.app.player.ProgressSaver
import dev.bookwave.app.ui.common.CoverCache
import dev.bookwave.app.ui.common.CoverImage
import dev.bookwave.app.ui.common.FallbackCoverColors
import dev.bookwave.app.ui.common.rememberCoverColors
import dev.bookwave.core.cloud.MediaKind
import dev.bookwave.core.library.TitleCleaner
import dev.bookwave.core.playback.AudioSpeed
import dev.bookwave.core.playback.SleepTimerMode
import dev.bookwave.core.util.NaturalOrder
import dev.bookwave.core.util.TimeFmt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

/**
 * Full-screen audiobook player — Apple Podcasts / Music inspired.
 *
 * Visual design:
 *  - edge-to-edge gradient tinted with the cover's dominant colours
 *  - large centred artwork with a soft shadow
 *  - elapsed time on the left, **remaining time in negative** on the right
 *  - −15 s / +30 s skip buttons flanking a large play/pause
 *  - speed shown as plain text ("1.5×"), not an icon
 *  - chapter list lives in a bottom sheet, keeping the main view uncluttered
 *
 * All playback logic (Media3 controller, progress persistence, sleep timer)
 * is unchanged from v0.4.2.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalSharedTransitionApi::class)
@Composable
fun PlayerScreen(
    bookId: String,
    onBack: () -> Unit,
    title: String? = null,
    author: String? = null,
    sharedTransitionScope: SharedTransitionScope? = null,
    animatedVisibilityScope: AnimatedVisibilityScope? = null,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var controller by remember { mutableStateOf<MediaController?>(null) }
    var chapters by remember(bookId) { mutableStateOf<List<PlayableChapter>>(emptyList()) }
    var coverUrl by remember(bookId) { mutableStateOf<String?>(null) }
    var startIndex by remember(bookId) { mutableIntStateOf(0) }
    var startRatio by remember(bookId) { mutableFloatStateOf(0f) }
    var isLoading by remember(bookId) { mutableStateOf(true) }
    var loadError by remember(bookId) { mutableStateOf<String?>(null) }

    val settings = remember { AppSettings(context) }

    var isPlaying by remember { mutableStateOf(false) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var currentIndex by remember { mutableIntStateOf(0) }
    // Keyed by book so a reuse of this screen for another book resets them.
    var speed by remember(bookId) { mutableFloatStateOf(AudioSpeed.coerce(settings.playbackSpeed)) }
    var sleepMode by remember { mutableStateOf<SleepTimerMode?>(null) }
    var sleepChapterAnchor by remember { mutableStateOf<Int?>(null) }
    var sheet by remember { mutableStateOf<Sheet?>(null) }
    var started by remember(bookId) { mutableStateOf(false) }
    /** Stream failure surfaced to the user (was a silent frozen player before). */
    var playbackError by remember(bookId) { mutableStateOf<String?>(null) }
    /** Non-null while the user drags the slider — owns the displayed position. */
    var scrubFraction by remember(bookId) { mutableStateOf<Float?>(null) }

    // ---- Precise resume: seek inside the chapter once its duration is known --
    val resumeListener = remember {
        object : Player.Listener {
            override fun onEvents(player: Player, events: Player.Events) {
                // Surface stream failures (401, network, missing file) instead
                // of leaving a silently frozen player; clears on recovery.
                playbackError = player.playerError?.let { describePlaybackError(it) }
                val ratio = startRatio
                if (ratio <= 0f) return
                val d = player.duration
                if (d > 0) {
                    player.seekTo((ratio * d).toLong())
                    startRatio = 0f
                }
            }
        }
    }

    // ---- Load chapters + connect to the playback service -------------------
    DisposableEffect(bookId) {
        var disposed = false
        val future = MediaController.Builder(
            context,
            SessionToken(context, ComponentName(context, PlaybackService::class.java)),
        ).buildAsync()
        future.addListener({
            if (!disposed) {
                val c = runCatching { future.get() }.getOrNull()
                if (c != null && isSameBookPlaying(c, bookId)) {
                    started = true
                    startRatio = 0f
                    speed = AudioSpeed.coerce(c.playbackParameters.speed)
                }
                controller = c
                c?.addListener(resumeListener)
                if (c != null && chapters.isNotEmpty() && !started) {
                    started = true
                    startPlayback(context, c, chapters, startIndex, speed, bookId, title, coverUrl, author)
                }
            }
        }, ContextCompat.getMainExecutor(context))

        val job = scope.launch {
            try {
                val resolved = withContext(Dispatchers.IO) { resolveBook(context, bookId) }
                chapters = resolved.chapters
                coverUrl = resolved.coverUrl
                isLoading = false

                val live = controller?.takeIf { isSameBookPlaying(it, bookId) }
                if (live != null) {
                    startRatio = 0f
                    speed = AudioSpeed.coerce(live.playbackParameters.speed)
                } else {
                    startIndex = resolved.startIndex
                    startRatio = resolved.startRatio
                    resolved.speed?.let { speed = AudioSpeed.coerce(it) }
                    controller?.let { c ->
                        if (!started) {
                            started = true
                            startPlayback(
                                context, c, resolved.chapters, resolved.startIndex,
                                speed, bookId, title, resolved.coverUrl, author,
                            )
                        }
                    }
                }

                if (resolved.chapters.isEmpty()) {
                    loadError = "Aucun fichier audio trouvé dans ce livre"
                }
            } catch (e: Exception) {
                isLoading = false
                loadError = e.message ?: e.javaClass.simpleName
            }
        }

        onDispose {
            disposed = true
            persistProgress(controller, chapters, speed, bookId, context)
            controller?.removeListener(resumeListener)
            job.cancel()
            MediaController.releaseFuture(future)
            controller = null
        }
    }

    // ---- Poll player state + enforce sleep timer + save progress -----------
    LaunchedEffect(controller) {
        val c = controller ?: return@LaunchedEffect
        var lastSavedAt = 0L
        var wasPlaying = false
        while (true) {
            // v0.8.0 — adaptive tick. The old fixed 500 ms loop rewrote four
            // Compose states twice a second FOREVER (even paused, even with the
            // screen dimmed), recomposing the whole player for nothing.
            // Now: 250 ms while playing (smooth slider), 1 s when paused, and
            // a state is only written when its value actually changed.
            val playing = c.isPlaying
            if (playing != isPlaying) isPlaying = playing
            val pos = c.currentPosition.coerceAtLeast(0L)
            if (pos != positionMs) positionMs = pos
            val dur = c.duration.takeIf { it > 0 } ?: 0L
            if (dur != durationMs) durationMs = dur
            val idx = c.currentMediaItemIndex
            if (idx != currentIndex) currentIndex = idx

            if (sleepMode == SleepTimerMode.EndOfChapter) {
                val anchor = sleepChapterAnchor
                if (anchor != null && idx != anchor) {
                    sleepMode = null
                    sleepChapterAnchor = null
                    c.pause()
                }
            }

            val now = System.currentTimeMillis()
            if (chapters.isNotEmpty() && ((isPlaying && now - lastSavedAt > 5_000) || (wasPlaying && !isPlaying))) {
                lastSavedAt = now
                persistProgress(c, chapters, speed, bookId, context)
            }
            wasPlaying = isPlaying
            delay(if (playing) 250 else 1_000)
        }
    }

    // ---- Cover-derived gradient (Apple Music style) ------------------------
    val coverColors = rememberCoverColors(coverUrl)
    val palette = coverColors ?: FallbackCoverColors
    val baseDark = Color(0xFF080808)
    val gradient = remember(palette) {
        Brush.verticalGradient(
            0.0f to palette.darkMuted.copy(alpha = 0.92f).compositeOver(baseDark),
            0.35f to palette.dominant.copy(alpha = 0.38f).compositeOver(baseDark),
            1.0f to baseDark,
        )
    }

    // Shared-element modifier for the mini-bar → player morph.
    val coverModifier: Modifier = if (sharedTransitionScope != null && animatedVisibilityScope != null) {
        with(sharedTransitionScope) {
            Modifier.sharedElement(
                rememberSharedContentState(key = "cover-$bookId"),
                animatedVisibilityScope = animatedVisibilityScope,
            )
        }
    } else {
        Modifier
    }

    val chapterTitle = chapters.getOrNull(currentIndex)?.title ?: "Chapitre ${currentIndex + 1}"
    // While dragging, the scrub position owns the display (polling keeps running).
    val shownPositionMs = scrubFraction?.let { (it * durationMs).toLong() } ?: positionMs
    val remaining = (durationMs - shownPositionMs).coerceAtLeast(0L)

    // ---- UI -----------------------------------------------------------------
    Box(
        Modifier
            .fillMaxSize()
            .background(gradient),
    ) {
        when {
            isLoading -> Column(
                Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                CircularProgressIndicator(color = Color.White)
                Text(
                    "Chargement des chapitres…",
                    color = Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.padding(top = 16.dp),
                )
            }

            loadError != null -> Column(
                Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars).padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    "❌ $loadError",
                    color = Color.White,
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.titleMedium,
                )
                Spacer(Modifier.height(24.dp))
                TextButton(onClick = onBack) { Text("Retour", color = Color.White) }
            }

            else -> Column(
                Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.systemBars)
                    .padding(horizontal = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                // -- Top row: dismiss chevron + speed + sleep ------------------
                Row(
                    Modifier.fillMaxWidth().padding(top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.Default.ExpandMore,
                            contentDescription = "Réduire le lecteur",
                            tint = Color.White.copy(alpha = 0.85f),
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { sheet = Sheet.SPEED }) {
                        Text(
                            AudioSpeed.label(speed),
                            color = if (speed != 1f) Color.White else Color.White.copy(alpha = 0.7f),
                            fontWeight = if (speed != 1f) FontWeight.Bold else FontWeight.Normal,
                            style = MaterialTheme.typography.titleSmall,
                        )
                    }
                    Spacer(Modifier.width(4.dp))
                    IconButton(onClick = { sheet = Sheet.SLEEP }) {
                        Icon(
                            Icons.Default.Nightlight,
                            contentDescription = "Minuteur de sommeil",
                            tint = if (sleepMode != null) Color.White else Color.White.copy(alpha = 0.55f),
                        )
                    }
                }

                Spacer(Modifier.weight(0.6f))

                // -- Cover art -------------------------------------------------
                Box(
                    Modifier
                        .size(280.dp)
                        .shadow(32.dp, RoundedCornerShape(14.dp), spotColor = Color.Black.copy(alpha = 0.6f))
                        .clip(RoundedCornerShape(14.dp))
                        .then(coverModifier),
                ) {
                    CoverImage(url = coverUrl, size = 280.dp)
                }

                Spacer(Modifier.weight(0.5f))

                // -- Title + chapter -------------------------------------------
                Text(
                    title ?: "Livre audio",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    chapterTitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.6f),
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )

                Spacer(Modifier.height(24.dp))

                // -- Slider + times --------------------------------------------
                Slider(
                    value = scrubFraction
                        ?: (if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f),
                    // The 500 ms poll used to rewrite positionMs mid-drag and the
                    // thumb snapped back; scrubbing now owns a separate state.
                    onValueChange = { frac -> scrubFraction = frac },
                    onValueChangeFinished = {
                        scrubFraction?.let { f ->
                            val target = (f * durationMs).toLong()
                            positionMs = target
                            controller?.seekTo(target)
                        }
                        scrubFraction = null
                    },
                    valueRange = 0f..1f,
                    modifier = Modifier.fillMaxWidth(),
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = Color.White,
                        inactiveTrackColor = Color.White.copy(alpha = 0.25f),
                    ),
                )
                Row(Modifier.fillMaxWidth().padding(horizontal = 2.dp)) {
                    Text(
                        TimeFmt.formatDuration(shownPositionMs),
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White.copy(alpha = 0.55f),
                    )
                    Spacer(Modifier.weight(1f))
                    Text(
                        "−${TimeFmt.formatDuration(remaining)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White.copy(alpha = 0.55f),
                    )
                }

                playbackError?.let { msg ->
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                    ) {
                        Row(
                            Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                "⚠ $msg",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.weight(1f),
                            )
                            TextButton(
                                onClick = {
                                    playbackError = null
                                    controller?.let { c ->
                                        c.prepare()
                                        c.play()
                                    }
                                },
                            ) {
                                Text("Réessayer", color = MaterialTheme.colorScheme.onErrorContainer)
                            }
                        }
                    }
                }

                Spacer(Modifier.height(20.dp))

                // -- Transport controls ----------------------------------------
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = { controller?.seekToPreviousMediaItem() }) {
                        Icon(
                            Icons.Default.SkipPrevious,
                            contentDescription = "Chapitre précédent",
                            tint = Color.White.copy(alpha = 0.85f),
                            modifier = Modifier.size(30.dp),
                        )
                    }
                    IconButton(onClick = {
                        positionMs = (positionMs - 15_000L).coerceAtLeast(0L)
                        controller?.seekTo(positionMs)
                    }) {
                        Icon(
                            Icons.Default.Replay10,
                            contentDescription = "Reculer 15 secondes",
                            tint = Color.White.copy(alpha = 0.85f),
                            modifier = Modifier.size(32.dp),
                        )
                    }
                    FilledIconButton(
                        onClick = {
                            val c = controller ?: return@FilledIconButton
                            if (c.isPlaying) c.pause() else c.play()
                            isPlaying = c.isPlaying
                        },
                        modifier = Modifier.size(74.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = Color.White,
                            contentColor = Color.Black,
                        ),
                    ) {
                        Icon(
                            if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Lecture",
                            modifier = Modifier.size(40.dp),
                        )
                    }
                    IconButton(onClick = {
                        positionMs = (positionMs + 30_000L).coerceAtMost(durationMs.takeIf { it > 0 } ?: Long.MAX_VALUE)
                        controller?.seekTo(positionMs)
                    }) {
                        Icon(
                            Icons.Default.Forward30,
                            contentDescription = "Avancer 30 secondes",
                            tint = Color.White.copy(alpha = 0.85f),
                            modifier = Modifier.size(32.dp),
                        )
                    }
                    IconButton(onClick = { controller?.seekToNextMediaItem() }) {
                        Icon(
                            Icons.Default.SkipNext,
                            contentDescription = "Chapitre suivant",
                            tint = Color.White.copy(alpha = 0.85f),
                            modifier = Modifier.size(30.dp),
                        )
                    }
                }

                Spacer(Modifier.weight(0.8f))

                // -- Chapter list access ---------------------------------------
                TextButton(onClick = { sheet = Sheet.CHAPTERS }) {
                    Text(
                        "Chapitres · ${currentIndex + 1}/${chapters.size}",
                        color = Color.White.copy(alpha = 0.65f),
                        style = MaterialTheme.typography.labelLarge,
                    )
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }

    // ---- Sheets ---------------------------------------------------------------
    when (sheet) {
        Sheet.SPEED -> SpeedSheet(
            current = speed,
            onPick = {
                speed = it
                controller?.let { c -> applySpeedIfDifferent(c, it) }
                settings.playbackSpeed = it
                persistProgress(controller, chapters, it, bookId, context)
            },
            onDismiss = { sheet = null },
        )
        Sheet.SLEEP -> SleepSheet(
            current = sleepMode,
            onPick = { mode ->
                sleepMode = mode
                sleepChapterAnchor = if (mode == SleepTimerMode.EndOfChapter) currentIndex else null
            },
            onDismiss = { sheet = null },
        )
        Sheet.CHAPTERS -> ChaptersSheet(
            chapters = chapters,
            currentIndex = currentIndex,
            onPick = { i ->
                controller?.seekToDefaultPosition(i)
                controller?.play()
                sheet = null
            },
            onDismiss = { sheet = null },
        )
        null -> Unit
    }

    // ---- Duration-based sleep timer -------------------------------------------
    LaunchedEffect(sleepMode) {
        val mode = sleepMode
        if (mode is SleepTimerMode.Duration) {
            delay(mode.millis)
            if (sleepMode == mode) {
                controller?.pause()
                sleepMode = null
                sleepChapterAnchor = null
            }
        }
    }
}

private enum class Sheet { SPEED, SLEEP, CHAPTERS }

/** One playable file inside a book (folder book: one audio file = one chapter). */
private data class PlayableChapter(val title: String, val uri: String)

private data class ResolvedBook(
    val chapters: List<PlayableChapter>,
    val startIndex: Int,
    val startRatio: Float,
    val coverUrl: String? = null,
    val speed: Float? = null,
)

/** Single IO scope for progress writes (was one fresh scope per save). */
private val progressScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

private fun persistProgress(
    controller: MediaController?,
    chapters: List<PlayableChapter>,
    speed: Float,
    bookId: String,
    context: Context,
) {
    if (controller == null || chapters.isEmpty()) return
    // Same snapshot logic as the background service (see ProgressSaver): the
    // UI and the service write IDENTICAL records.
    val entry = ProgressSaver.snapshot(
        bookId = bookId,
        chapterCount = chapters.size,
        chapterIndex = controller.currentMediaItemIndex,
        positionInChapterMs = controller.currentPosition.coerceAtLeast(0L),
        chapterDurationMs = controller.duration,
        speed = speed,
        deviceId = AppSettings(context).deviceId,
    )
    val appContext = context.applicationContext
    progressScope.launch { ProgressSaver.save(appContext, entry) }
}

/** French, actionable label for a Media3 stream failure. */
private fun describePlaybackError(error: PlaybackException): String = when (error.errorCode) {
    // 401/403 surface as BAD_HTTP_STATUS (there is no dedicated IO auth code).
    PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ->
        "Réponse HTTP refusée par le serveur audio — vérifiez vos identifiants WebDAV"
    PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND ->
        "Fichier audio introuvable sur le serveur"
    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
        "Connexion au serveur audio interrompue"
    PlaybackException.ERROR_CODE_IO_CLEARTEXT_NOT_PERMITTED ->
        "Lien non sécurisé (http://) refusé par Android"
    else -> "Lecture impossible (${error.errorCodeName})"
}

private fun startPlayback(
    context: Context,
    controller: MediaController,
    chapters: List<PlayableChapter>,
    startIndex: Int,
    speed: Float,
    bookId: String,
    bookTitle: String?,
    coverUrl: String? = null,
    artist: String? = null,
) {
    if (isSameBookPlaying(controller, bookId)) {
        applySpeedIfDifferent(controller, speed)
        return
    }
    // Notification artwork: prefer the locally cached cover file — a private
    // WebDAV cover URL needs auth headers the notification loader does not
    // send; fall back to the remote URL for public sources.
    val artwork = CoverCache.diskUriIfCached(context, coverUrl)?.let { Uri.parse(it) }
        ?: coverUrl?.takeIf { it.isNotBlank() }?.let { Uri.parse(it) }
    val items = chapters.map { ch ->
        MediaItem.Builder()
            .setUri(ch.uri)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    // The notification shows the BOOK (title + author) and the
                    // chapter as the album line — not a bare file name.
                    .setTitle(bookTitle ?: ch.title)
                    .setArtist(artist)
                    .setAlbumTitle(ch.title)
                    .apply { artwork?.let { setArtworkUri(it) } }
                    .build(),
            )
            .build()
    }
    val index = startIndex.coerceIn(0, chapters.size - 1)
    controller.setMediaItems(items, index, 0L)
    applySpeedIfDifferent(controller, speed)
    controller.prepare()
    controller.playWhenReady = true
    PlaybackBus.nowPlaying.value = PlaybackBus.NowPlaying(
        bookId = bookId,
        title = bookTitle ?: "Livre audio",
        artist = artist,
        coverUrl = coverUrl,
        chapterCount = chapters.size,
    )
}

private suspend fun resolveBook(context: Context, bookId: String): ResolvedBook {
    val settings = AppSettings(context)
    var coverUrl: String? = null
    val chapters: List<PlayableChapter> = when {
        bookId.startsWith("demo:") -> {
            val demo = DemoLibrary.books().firstOrNull { it.id == bookId }
                ?: return ResolvedBook(emptyList(), 0, 0f)
            demo.chapters.mapIndexed { i, ch ->
                PlayableChapter(ch.title ?: "Chapitre ${i + 1}", "android.resource://${context.packageName}/raw/demo_tone")
            }
        }

        bookId.startsWith("webdav:dir:") -> {
            val path = bookId.removePrefix("webdav:dir:")
            val source = WebDavSource(
                account = settings.webdavUser.ifBlank { "mon-compte" },
                baseUrl = settings.webdavUrl,
                username = settings.webdavUser,
                password = settings.webdavPassword,
            )
            val children = source.list(path)
            coverUrl = children.firstOrNull { it.mediaKind == MediaKind.COVER }
                ?.let { runCatching { source.streamUrl(it.path) }.getOrNull() }
            children
                .filter { it.mediaKind == MediaKind.AUDIO }
                // Natural order: track "2" before track "10" — the old
                // lexicographic sort shuffled non zero-padded books.
                .sortedWith(compareBy(NaturalOrder) { it.name })
                .map {
                    PlayableChapter(
                        TitleCleaner.clean(it.name.substringBeforeLast('.')).title,
                        source.streamUrl(it.path),
                    )
                }
        }

        bookId.startsWith("webdav:file:") -> {
            val path = bookId.removePrefix("webdav:file:")
            val source = WebDavSource(
                account = settings.webdavUser.ifBlank { "mon-compte" },
                baseUrl = settings.webdavUrl,
                username = settings.webdavUser,
                password = settings.webdavPassword,
            )
            listOf(PlayableChapter(path.substringAfterLast('/').substringBeforeLast('.'), source.streamUrl(path)))
        }

        else -> emptyList()
    }

    val stored = runCatching {
        ProgressStore(context).progress.first().firstOrNull { it.bookId == bookId }
    }.getOrNull()
    val fraction = (stored?.fraction?.toFloat() ?: 0f).coerceIn(0f, 1f)
    val storedSpeed = stored?.speed?.takeIf { it in AudioSpeed.MIN..AudioSpeed.MAX }

    if (chapters.isEmpty()) return ResolvedBook(emptyList(), 0, 0f, coverUrl, storedSpeed)
    if (fraction >= 0.999f) return ResolvedBook(chapters, 0, 0f, coverUrl, storedSpeed)

    val scaled = fraction * chapters.size
    val index = scaled.toInt().coerceIn(0, chapters.size - 1)
    val ratio = (scaled - index).coerceIn(0f, 0.999f)
    return ResolvedBook(chapters, index, ratio, coverUrl, storedSpeed)
}

private fun isSameBookPlaying(controller: Player, bookId: String): Boolean =
    controller.mediaItemCount > 0 && PlaybackBus.nowPlaying.value?.bookId == bookId

private fun applySpeedIfDifferent(controller: Player, speed: Float) {
    val target = AudioSpeed.coerce(speed)
    if (abs(controller.playbackParameters.speed - target) > 0.01f) {
        controller.setPlaybackSpeed(target)
    }
}

// ---- Sheets -------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SpeedSheet(current: Float, onPick: (Float) -> Unit, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Vitesse de lecture", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AudioSpeed.PRESETS.forEach { preset ->
                    FilterChip(
                        selected = preset == current,
                        onClick = { onPick(preset) },
                        label = { Text(AudioSpeed.label(preset)) },
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SleepSheet(current: SleepTimerMode?, onPick: (SleepTimerMode?) -> Unit, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Minuteur de sommeil", style = MaterialTheme.typography.titleMedium)
            FilterChip(current == null, { onPick(null) }, label = { Text("Désactivé") })
            FilterChip(current == SleepTimerMode.EndOfChapter, { onPick(SleepTimerMode.EndOfChapter) }, label = { Text("Fin de chapitre") })
            listOf(15, 30, 45, 60).forEach { min ->
                FilterChip(
                    selected = current == SleepTimerMode.Duration(min * 60_000L),
                    onClick = { onPick(SleepTimerMode.Duration(min * 60_000L)) },
                    label = { Text("$min min") },
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChaptersSheet(
    chapters: List<PlayableChapter>,
    currentIndex: Int,
    onPick: (Int) -> Unit,
    onDismiss: () -> Unit,
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 24.dp)) {
            Text(
                "Chapitres",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(bottom = 12.dp),
            )
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                itemsIndexed(chapters) { i, ch ->
                    val active = i == currentIndex
                    Text(
                        text = "${i + 1}. ${ch.title}",
                        style = if (active) MaterialTheme.typography.bodyLarge else MaterialTheme.typography.bodyMedium,
                        color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                        fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onPick(i) }
                            .padding(vertical = 10.dp, horizontal = 8.dp),
                    )
                }
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}
