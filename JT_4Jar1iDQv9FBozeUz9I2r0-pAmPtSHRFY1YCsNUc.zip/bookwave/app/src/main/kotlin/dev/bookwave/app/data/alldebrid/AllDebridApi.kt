package dev.bookwave.app.data.alldebrid

import dev.bookwave.app.util.Http
import dev.bookwave.app.util.await
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Minimal AllDebrid v4 client: add a magnet link or a .torrent file, watch the
 * transfer, delete it.
 *
 * Auth is the account API key (the same string the user already typed as the
 * WebDAV username) sent as a Bearer token, plus the mandatory `agent` name.
 */
class AllDebridApi(private val apiKey: String) {

    data class Magnet(
        val id: Long,
        val filename: String,
        val sizeBytes: Long,
        val status: String,
        val statusCode: Int,
        val downloadedBytes: Long,
        val seeders: Int,
    ) : java.io.Serializable {
        val isReady: Boolean get() = statusCode == CODE_READY
        val isError: Boolean get() = statusCode >= CODE_UPLOAD_FAILED

        /** 0..1 download progress; -1 when the size is unknown. */
        val progress: Float
            get() = if (isReady) 1f
            else if (sizeBytes > 0) (downloadedBytes.toFloat() / sizeBytes).coerceIn(0f, 1f)
            else -1f

        val label: String get() = statusLabel(statusCode, status)
    }

    // Shares the app-wide connection pool (see dev.bookwave.app.util.Http).
    private val http = Http.shared.newBuilder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    /** Adds a magnet URI (or a bare info-hash). Returns the transfer id. */
    suspend fun uploadMagnet(magnet: String): Long = withContext(Dispatchers.IO) {
        val body = FormBody.Builder().add("magnets[]", magnet.trim()).build()
        val json = execute(
            Request.Builder().url("$BASE_V4/magnet/upload?$AGENT_Q")
                .header("Authorization", "Bearer $apiKey")
                .post(body).build(),
        )
        val first = json.optJSONObject("data")
            ?.let { it.optJSONArray("magnets") ?: it.optJSONArray("files") }
            ?.optJSONObject(0)
            ?: throw IOException("Réponse inattendue d'AllDebrid")
        first.optJSONObject("error")?.let { throw IOException(frenchError(it)) }
        val id = first.optLong("id", -1L)
        if (id <= 0) throw IOException("Transfert ajouté mais identifiant illisible")
        id
    }

    /** Uploads a local .torrent file (multipart). Returns the transfer id. */
    suspend fun uploadTorrentFile(fileName: String, bytes: ByteArray): Long = withContext(Dispatchers.IO) {
        val body = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart(
                "files[]",
                fileName,
                bytes.toRequestBody("application/x-bittorrent".toMediaType()),
            )
            .build()
        val json = execute(
            Request.Builder().url("$BASE_V4/magnet/upload/file?$AGENT_Q")
                .header("Authorization", "Bearer $apiKey")
                .post(body).build(),
        )
        val data = json.optJSONObject("data")
            ?: throw IOException("Réponse inattendue d'AllDebrid")
        // This endpoint answers under "files" (some builds) or "magnets".
        val first = (data.optJSONArray("files") ?: data.optJSONArray("magnets"))?.optJSONObject(0)
            ?: throw IOException("Transfert ajouté mais réponse illisible")
        first.optJSONObject("error")?.let { throw IOException(frenchError(it)) }
        val id = first.optLong("id", -1L)
        if (id <= 0) throw IOException("Transfert ajouté mais identifiant illisible")
        id
    }

    /** Every transfer of the account, most recent first. */
    suspend fun listMagnets(): List<Magnet> = withContext(Dispatchers.IO) {
        val json = execute(
            Request.Builder().url("$BASE_V41/magnet/status?$AGENT_Q")
                .header("Authorization", "Bearer $apiKey")
                .get().build(),
        )
        val array = json.optJSONObject("data")?.optJSONArray("magnets") ?: return@withContext emptyList()
        val out = mutableListOf<Magnet>()
        for (i in 0 until array.length()) {
            val o = array.optJSONObject(i) ?: continue
            // v4.1 sometimes answers ids as strings — parse tolerantly.
            val id = o.optLong("id").takeIf { it > 0 }
                ?: o.optString("id").toLongOrNull()
                ?: continue
            out += Magnet(
                id = id,
                filename = o.optString("filename").ifBlank { "Sans nom" },
                sizeBytes = o.optLong("size", 0L),
                status = o.optString("status"),
                statusCode = o.optInt("statusCode", -1),
                downloadedBytes = o.optLong("downloaded", 0L),
                seeders = o.optInt("seeders", 0),
            )
        }
        out.sortedByDescending { it.id }
    }

    suspend fun deleteMagnet(id: Long) = withContext(Dispatchers.IO) {
        val body = FormBody.Builder().add("id", id.toString()).build()
        execute(
            Request.Builder().url("$BASE_V4/magnet/delete?$AGENT_Q")
                .header("Authorization", "Bearer $apiKey")
                .post(body).build(),
        )
        Unit
    }

    /** Runs a request and returns the parsed envelope, or throws in French. */
    private suspend fun execute(request: Request): JSONObject {
        val response = http.newCall(request).await()
        val text = response.use { it.body?.string().orEmpty() }
        val json = runCatching { JSONObject(text) }.getOrElse {
            throw IOException("Réponse illisible d'AllDebrid (HTTP ${response.code})")
        }
        if (json.optString("status") != "success") {
            val err = json.optJSONObject("error")
                ?: json.optJSONArray("errors")?.optJSONObject(0)
                ?: JSONObject()
            throw IOException(frenchError(err))
        }
        return json
    }

    private fun frenchError(error: JSONObject): String {
        val code = error.optString("code")
        val message = error.optString("message")
        return when (code) {
            "AUTH_BAD_APIKEY", "AUTH_MISSING_APIKEY" -> "Clé API refusée par AllDebrid — vérifiez-la dans alldebrid.com/apikeys"
            "AGENT_MISSING", "AGENT_MISSING_OR_INVALID" -> "Agent invalide (bug applicatif)"
            "MAGNET_NO_URI" -> "Aucun lien magnet fourni"
            "MAGNET_INVALID_URI" -> "Lien magnet invalide"
            "MAGNET_MUST_BE_PREMIUM" -> "Compte premium requis pour ajouter des torrents"
            "MAGNET_NO_SERVER" -> "AllDebrid refuse la requête (VPN ou serveur détecté)"
            "MAGNET_TOO_MANY_ACTIVE" -> "Limite de transferts actifs atteinte (30) — supprimez-en un"
            "MAGNET_TOO_LARGE", "MAGNET_MAGNET_TOO_BIG" -> "Contenu trop volumineux (max 1 To)"
            "USER_NOT_PREMIUM" -> "Compte premium requis"
            else -> message.ifBlank { code.ifBlank { "Erreur AllDebrid inconnue" } }
        }
    }

    companion object {
        private const val BASE_V4 = "https://api.alldebrid.com/v4"
        private const val BASE_V41 = "https://api.alldebrid.com/v4.1"

        /** AllDebrid requires an application name on every call. */
        private const val AGENT_Q = "agent=Bookwave"

        const val CODE_READY = 4
        const val CODE_UPLOAD_FAILED = 5

        /** True when the configured WebDAV account is an AllDebrid one. */
        fun isAllDebridAccount(webdavUrl: String): Boolean =
            webdavUrl.contains("debrid.it", ignoreCase = true) ||
                webdavUrl.contains("alldebrid", ignoreCase = true)

        fun statusLabel(code: Int, fallback: String): String = when (code) {
            0 -> "En file d'attente"
            1 -> "Téléchargement en cours"
            2 -> "Compression / déplacement"
            3 -> "Envoi vers votre espace"
            CODE_READY -> "Prêt — disponible dans la bibliothèque"
            CODE_UPLOAD_FAILED -> "Échec de l'envoi"
            6 -> "Erreur de dépaquetage"
            7 -> "Non téléchargé en 20 min"
            8 -> "Fichier trop volumineux"
            9 -> "Erreur interne AllDebrid"
            10 -> "Téléchargement trop long (> 72 h)"
            11 -> "Supprimé chez l'hébergeur"
            12 -> "Échec du traitement"
            14 -> "Erreur de contact du tracker"
            15 -> "Fichier indisponible (aucun peer)"
            else -> fallback.ifBlank { "Statut inconnu" }
        }
    }
}
