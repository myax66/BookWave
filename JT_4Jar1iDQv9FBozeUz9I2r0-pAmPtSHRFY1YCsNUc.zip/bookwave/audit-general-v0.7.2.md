# Audit général — Bookwave v0.7.2 (versionCode 28)

**Date :** 22 octobre 2026
**Version auditée :** v0.7.1 (vc27) → **corrigée en v0.7.2** (vc28)
**Périmètre :** les 49 fichiers Kotlin (~8 600 lignes), manifeste, Gradle, ressources,
outillage — plus le pipeline de métadonnées revu en v0.7.x.
**Méthode :** lecture ciblée fichier par fichier, greps systématiques de motifs à
risque (`execute()`, `runCatching`, `!!`, `remember {`, `GlobalScope`, XXE, timeouts,
Locale…), compilation réelle (`:core:test` **80 verts**, `:app:assembleDebug` OK),
vérification ICU des 48 regex (`tools/check-regex-icu.sh`), et mesures directes sur
`api.audible.fr` / `api.audible.com`.

> ⚠️ Cet audit remplace celui de la v0.5.1 : les points déjà corrigés en 0.5.2/0.5.3
> (progression sauvée côté service, erreurs de lecture, XXE, sync réparée, slider,
> `rememberSaveable`, dépendances mortes…) ne sont pas réouverts ici. Seuls les
> constats **encore présents** ou **nouveaux** sont listés.

---

## 1. Verdict

Le socle reste sain : architecture `core` pur / `app` Android, aucune composante
exportée inutile, un seul pool OkHttp, scans bornés, parsing réseau défensif, 80 tests.
La v0.7.x a introduit une **dette de vérification** (les regex JVM ≠ ICU, corrigée)
et laisse quelques **angles morts classiques** : secrets en clair, absence de LWW
réseau/retry, caches disque sans plafond, et zéro outillage qualité (CI, lint statique,
tests instrumentés).

| Gravité | Constats | Dont corrigés ici |
|---|---|---|
| 🔴 Élevé | 2 | 1 |
| 🟠 Moyen | 9 | 4 |
| 🟡 Mineur | 11 | 2 |

---

## 2. 🔴 Élevé

### E1. Les regex ne sont testées que sur la JVM, pas sur ICU — **corrigé (outil)**
`MetadataMatcher.normalizeSeries()` contenait `\{[^}]*}`, accepté par OpenJDK mais
refusé par **ICU**, le moteur d'`android.util.regex` : `U_REGEX_RULE_SYNTAX`, exception
au premier scoring, **100 % des recherches Audible en échec** en production alors que
les tests étaient verts (v0.7.0). Motif corrigé en 0.7.1 et **outillage ajouté** :
`tools/check-regex-icu.sh` compile les 48 motifs du projet avec la vraie bibliothèque
ICU (gcc + libicu-dev) et échoue si l'un est invalide. À exécuter avant chaque
livraison — c'est désormais écrit dans le README (étape 5).
*Reste à faire :* le même piège existe pour toute API Android divergente de la JVM
(par ex. `String.format` localisé) → privilégier des tests **instrumentés** (cf. H2).

### E2. Secrets en clair dans des SharedPreferences — **non corrigé (assumé)**
`AppSettings` stocke mot de passe WebDAV, clés C411/TR4KER et clé AllDebrid en
`MODE_PRIVATE` non chiffré (`app/data/AppSettings.kt`). Atténuations existantes :
`allowBackup="false"` (pas de sauvegarde cloud), aucune composante exportée, pas de
log. Risque résiduel : appareil rooté, extraction physique, copie de `/data/data` via
une faille d'un autre composant.
**Recommandation :** `EncryptedSharedPreferences` (androidx.security-crypto) avec une
clé Keystore, migration one-shot des 4 secrets ; repli transparent si le Keystore
échoue. Impact : ~40 lignes + une dépendance, pas de changement d'API pour l'UI.

---

## 3. 🟠 Moyens

### M1. HTTP en clair impossible pour un WebDAV auto-hébergé — **corrigé (message)**
`targetSdk 35` + aucun `networkSecurityConfig` ⇒ Android bloque tout `http://`
(le début de `AppSettings.set` ne préfixe que si aucun schéma n'est présent). Un
serveur LAN en `http://192.168.x.x` est donc inutilisable, avec une erreur réseau
opaque. `PlayerScreen` mappe bien ce cas en « Lien non sécurisé (http://) refusé par
Android », mais l'écran **Réglages** ne prévient pas.
**Recommandation produit :** soit un `networkSecurityConfig` restreint aux plages
privées (impossible par IP — il faut un *user toggle* `usesCleartextTraffic`), soit
un message explicite dans Réglages. Décision à prendre ; non tranché ici.

### M2. `MainActivity` exportée + intents entrants non validés — **corrigé**
Filtres `SEND` (text/plain) et `VIEW` (`magnet:`) : n'importe quelle app peut pousser
un texte dans Bookwave ; `PendingTorrent.offer()` l'acceptait tel quel, sans borne de
taille ni format. Le contenu ne servait qu'à pré-remplir un champ (confirmation
utilisateur obligatoire), donc pas d'exécution silencieuse — mais un intent de 1 Mo
ou une URL arbitraire finissait dans l'UI.
**Corrigé :** `offer()` n'accepte plus qu'un `magnet:?…` ou un info-hash 40/64 hex,
≤ 4 096 caractères.

### M3. Caches disque sans plafond — **corrigé**
`CoverCache.diskDir()` ne purgeait jamais : chaque re-identification (Audible change
d'URL de pochette) créait un nouveau hash et l'ancien fichier restait à vie.
**Corrigé :** purge LRU par date à **150 Mo**, une fois par processus.

### M4. `metadata-cache.json` non borné — **corrigé**
Une entrée par livre + un registre « essayé » jamais purgé (le TTL n'était vérifié
qu'en lecture). **Corrigé :** purge des lignes de registre > 30 jours et plafond de
**5 000** fiches (les plus récentes conservées) à chaque écriture.

### M5. `runCatching` restants dans du code `suspend` — **à faire**
41 occurrences de `runCatching` (hors `suspendRunCatching`). La plupart sont
légitimes (parsing, I/O tolérante), mais deux sont dans un chemin annulable :
`BookRepository.booksFrom()` — `runCatching { source.streamUrl(...) }` (l.212, l.236).
Une annulation y est convertie en `null` et le scan continue au lieu de s'arrêter.
**Recommandation :** `suspendRunCatching` sur ces deux appels (et audit annuel du
reste). Risque faible mais c'est exactement la classe de bug corrigée en 0.5.2.

### M6. Aucune politique de retry/backoff réseau — **à faire**
Aucun appel HTTP ne réessaie sur 5xx/429 ; le worker de sync fait `Result.retry()`
sans backoff explicite (WorkManager applique le sien, par défaut linéaire). Sur un
WebDAV chargé ou une API Audible qui hoquette, l'utilisateur voit un échec immédiat.
**Recommandation :** un intercepteur OkHttp de retry borné (1 tentative, 300 ms,
uniquement pour GET idempotents sur 502/503/504/429).

### M7. `DataStore` réécrit tout l'historique à chaque position — **à faire**
`ProgressStore.upsert()` parse **et** resérialise l'intégralité du JSON à chaque
appel ; le service sauvegarde toutes les `SAVE_INTERVAL_MS` (10 s) en lecture. Avec
200 livres, c'est ~40 Ko réécrits toutes les 10 s (flash + batterie).
**Recommandation :** throttle en mémoire (n'écrire que si Δposition > 30 s ou sur
pause/stop), ou passer à une base Room pour la progression.

### M8. `PlayerScreen` : état non sauvegardé à la rotation — **à faire**
10 `remember` (contre 4 `rememberSaveable` ailleurs) : `sleepMode`, `sheet`,
`sleepChapterAnchor` sont perdus à la rotation. Non bloquant (le ViewModel et le
service gardent la lecture), mais le mode nuit/minuteur se réinitialise visuellement.
**Recommandation :** `rememberSaveable` sur ces trois-là.

### M9. `AddTorrentScreen` : polling sans fin ni backoff — **à faire**
`LaunchedEffect(apiKey) { while (true) { delay(10_000); refresh() } }` : tant que
l'écran est ouvert, une requête AllDebrid toutes les 10 s, même sans transfert actif,
sans limite de durée.
**Recommandation :** arrêter après N cycles sans transfert en cours (~5 min) et
reprendre à la prochaine action utilisateur.

---

## 4. 🟡 Mineurs

1. **Hash de pochette localisé** — `"%02x".format(it)` (CoverImage) produit des
   chiffres non-ASCII en arabe/persan → noms de fichiers instables. **Corrigé** :
   `String.format(Locale.ROOT, …)`.
2. **État partagé non volatil** — `BookRepository.cached` lu/écrit depuis plusieurs
   coroutines sans visibilité garantie. **Corrigé** : `@Volatile`.
3. **Message d'échec illisible** — la trace brute (`fr:T«…»→0, com:K«…»→0`) était
   affichée à l'utilisateur. **Corrigé** : résumé en français (« 6 requêtes de titre
   et de mots-clés sur Audible.fr puis Audible.com — sans résultat ») + conseil.
4. **`collectAsState()` non *lifecycle-aware*** dans le mini-lecteur de la
   bibliothèque. **Corrigé** → `collectAsStateWithLifecycle()`.
5. **Pas de `FLAG_SECURE`** sur l'écran Réglages où les clés API sont affichées
   (masquées en `PasswordVisualTransformation`, mais copiables) → captures d'écran
   possibles. À évaluer selon l'usage.
6. **Pas de garde-fou disque plein** : le téléchargement d'une pochette ou l'écriture
   du cache métadonnées échoue silencieusement (`runCatching`), sans message.
7. **APK de 23,8 Mo** : `material-icons-extended` non minifié en debug ; le build
   release (minify + shrinkResources) est configuré mais **jamais testé**.
8. **Aucune CI**, aucun `detekt`/`ktlint`, aucune baseline lint exploitable.
9. **Aucun test instrumenté** (`app/src/androidTest` absent) : tout ce qui dépend du
   framework (regex ICU, Media3, DataStore, intents) n'est validé que sur l'appareil
   de l'utilisateur. C'est la cause racine de la régression v0.7.0.
10. **`gradle.properties` calibré pour un bac à sable** (Xmx 700 Mo, 1 worker) :
    volontaire, documenté, mais ralentit les builds de dev ~3×.
11. **`debug.keystore` épinglé** : volontaire (mise à jour sans désinstaller),
    documenté comme dangereux à publier.

---

## 5. Ce qui est solide (à ne pas casser)

- **Manifeste verrouillé** : une seule composante exportée (le launcher) ; service de
  lecture `exported=false`.
- **XXE** : parser WebDAV durci (`disallow-doctype-decl`, `FEATURE_SECURE_PROCESSING`,
  accès DTD/schema bloqués) ; Torznab passe par `XmlPullParser` (pas de résolution
  d'entités externes).
- **Réseau** : un seul `OkHttpClient` partagé, appels annulables (`Call.await()`),
  `suspendRunCatching` sur les chemins de scan, timeouts explicites partout.
- **Scan bibliothèque** : budget de requêtes (`MAX_SCAN_REQUESTS`), parallélisme borné
  (`SCAN_PARALLEL`), cache disque versionné avec re-nettoyage des titres.
- **Lecture** : progression sauvée côté service (survit à la mort du process),
  `WAKE_MODE_NETWORK`, erreurs traduites en français avec « Réessayer ».
- **Métadonnées v0.7.x** : requêtes mesurées, pool de candidats, retry sans auteur,
  sortie anticipée, cache LRU, filtre de langue, feuille de recherche manuelle,
  découpage auteur préfixe/suffixe.

---

## 6. Plan d'action proposé (ordre coût/bénéfice)

| # | Action | Effort | Gain |
|---|---|---|---|
| 1 | Tests instrumentés minimaux (regex ICU, PendingTorrent, parsing) + CI locale | S | Bloque la classe de bug v0.7.0 |
| 2 | `EncryptedSharedPreferences` pour les 4 secrets | S | E2 |
| 3 | Retry OkHttp borné sur GET idempotents | S | M6 |
| 4 | Throttle des écritures de progression (Δ 30 s / pause) | S | M7 |
| 5 | `rememberSaveable` sur `sleepMode`/`sheet`/`sleepChannelAnchor` | XS | M8 |
| 6 | Fin du polling AllDebrid après 5 min | XS | M9 |
| 7 | `suspendRunCatching` sur les 2 appels de `booksFrom` | XS | M5 |
| 8 | Décision produit sur le WebDAV en `http://` LAN | S | M1 |
| 9 | Build release minifié (mesure + smoke test) | M | Mineur 7 |
| 10 | detekt + ktlint dans le build | M | Dette |

*(XS = minutes, S = heures, M = journée)*

---

## 7. Livré dans cette passe (v0.7.2, vc28)

- **Recherche** : découpe de l'auteur **en fin** de nom (« … - Joe Abercrombie ») et
  détection du **tome au milieu** (« L'Âge de la Folie **03** La Sagesse des Foules »),
  requête « derniers mots du titre » quand aucune saga n'est détectée.
  Mesure : `L'Âge de la Folie 03…` → **0,884, appliqué** (2 requêtes) ;
  non-régression vérifiée sur L'Ensoleillé (0,850), Solo Leveling 3 (0,850),
  Les Archives de Roshar 2 (0,914).
- **Sécurité/robustesse** : validation des intents entrants (M2), purge des caches
  disque et du cache métadonnées (M3/M4), `Locale.ROOT` sur le hash de pochette,
  `@Volatile` sur le cache bibliothèque.
- **UX** : message d'échec lisible (M3 mineur 3), `collectAsStateWithLifecycle`.
- **Outillage** : `tools/check-regex-icu.sh` (M/E1) + 48 motifs validés.
- **Tests** : 80 verts (74 + 4 nouveaux : tome au milieu, auteur en fin, sous-titre de
  saga, fenêtre de fin de titre). `MATCHING_VERSION = 7` → registre des échecs purgé,
  tous les livres sont réévalués.

## 8. Risques assumés / non faits

- `EncryptedSharedPreferences` non implémenté (M1 de l'audit 0.5.1, toujours ouvert) :
  dépendance supplémentaire + migration des secrets à tester sur appareil.
- WebDAV `http://` non tranché (M1) : décision produit, pas technique.
- Retry réseau, throttle DataStore, polling AllDebrid, `rememberSaveable` du lecteur :
  documentés, chiffrés, non codés dans cette passe pour ne pas mélanger correctifs de
  recherche et refonte d'architecture.
- Chapitres réels Audnexus, probing des durées, téléchargements hors-ligne : toujours
  en feuille de route.
