package dev.bookwave.core.util

/**
 * Natural-order comparator: digit runs inside strings compare as NUMBERS, so
 * audiobook tracks sort 1, 2, 10 instead of the lexicographic 1, 10, 2.
 * Case-insensitive for letters.
 */
object NaturalOrder : Comparator<String> {

    override fun compare(a: String, b: String): Int {
        var i = 0
        var j = 0
        while (i < a.length && j < b.length) {
            val ca = a[i]
            val cb = b[j]
            if (ca.isDigit() && cb.isDigit()) {
                var ei = i
                while (ei < a.length && a[ei].isDigit()) ei++
                var ej = j
                while (ej < b.length && b[ej].isDigit()) ej++
                // Compare digit runs by value: strip leading zeros, then length, then digits.
                val na = a.substring(i, ei).trimStart('0').ifEmpty { "0" }
                val nb = b.substring(j, ej).trimStart('0').ifEmpty { "0" }
                val cmp = if (na.length != nb.length) na.length - nb.length else na.compareTo(nb)
                if (cmp != 0) return cmp
                i = ei
                j = ej
            } else {
                val la = ca.lowercaseChar()
                val lb = cb.lowercaseChar()
                if (la != lb) return la.code - lb.code
                i++
                j++
            }
        }
        // Shorter string first when one is a prefix of the other.
        return (a.length - i) - (b.length - j)
    }
}
