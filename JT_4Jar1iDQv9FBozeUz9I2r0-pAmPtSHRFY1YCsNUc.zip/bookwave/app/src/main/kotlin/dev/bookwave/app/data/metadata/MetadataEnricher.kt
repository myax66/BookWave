package dev.bookwave.app.data.metadata

import dev.bookwave.core.library.TitleCleaner
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import dev.bookwave.core.metadata.AudibleQueries
import dev.bookwave.core.metadata.BookMetadata
import dev.bookwave.core.metadata.MetadataMatcher
import dev.bookwave.core.model.Audiobook
import java.util.Locale

sealed interface EnrichResult {
    data class Applied(val meta: BookMetadata) : EnrichResult
    data class Suggest(val options: List<Pair<BookMetadata, Double>>) : EnrichResult
    data class None(val trace: String = "") : EnrichResult
    data class Failed(val message: String) : EnrichResult
}

/**
 * Resolves official metadata for one book: cleaned torrent name → Audible
 * catalogue search (measured query ladder, see [AudibleQueries]) → scored match.
 *  - score ≥ 0.75: applied silently;
 *  - 0.50–0.75: candidates returned for the user to pick;
 *  - below: nothing (the cleaned title stays) AND the miss is ledgered so the
 *    background budget goes to books that can match.
 *
 * v0.7.0 — the search itself was reworked after measuring the live API:
 *  - queries are no longer "first one that returns anything wins": results
 *    from every step of the ladder are POOLED (a strict title query can return
 *    a lone English edition while the next one holds the French original);
 *  - a zero-result query is retried WITHOUT the guessed author (Audible ANDs
 *    the author filter: one bad guess returned 0 for every keyword);
 *  - a pass stops as soon as a candidate crosses the auto-apply threshold, so
 *    the average book now costs 1-2 requests instead of up to 14;
 *  - foreign-language clones are filtered against the preferred language;
 *  - [search] exposes the same engine to the manual search sheet, including
 *    direct ASIN lookup.
 */
class MetadataEnricher(
    private val store: MetadataStore,
    private val markets: List<String>,
    private val preferredLanguage: String? = null,
) {

    companion object {
        /** Bump whenever the matching/query logic changes: any stored miss
         *  ledger from an older engine is wiped on launch, so improved
         *  matching re-evaluates every book instead of inheriting old misses. */
        const val MATCHING_VERSION = 10

        /** Hard ceiling per book and per market (author retries included). */
        private const val MAX_CALLS_PER_MARKET = 6

        private val ASIN = Regex("^[A-Z0-9]{10}$")

        /** Which language a market speaks, when the caller has no preference. */
        fun languageOf(markets: List<String>): String? = when (markets.firstOrNull()) {
            "fr" -> "french"
            "com", "co.uk", "ca", "com.au" -> "english"
            "de" -> "german"
            "es" -> "spanish"
            "it" -> "italian"
            else -> null
        }
    }

    private class Call(val items: List<BookMetadata>, val error: String?)

    suspend fun enrich(book: Audiobook, force: Boolean = false): EnrichResult =
        // v0.8.0 — the store reads/writes a JSON file. `enrich` is called from
        // viewModelScope (main thread), so the ledger lookup and the metadata
        // write happened ON MAIN; the network part moved off later. The whole
        // function is I/O-bound anyway.
        withContext(Dispatchers.IO) { enrichBlocking(book, force) }

    private suspend fun enrichBlocking(book: Audiobook, force: Boolean): EnrichResult {
        if (!force) {
            store.of(book.id)?.let { return EnrichResult.Applied(it) }
            if (store.triedRecently(book.id)) {
                return EnrichResult.None("registre : déjà vérifié récemment")
            }
        }
        val raw = book.source.path.trimEnd('/').substringAfterLast('/')
        val cleaned = TitleCleaner.clean(raw.ifBlank { book.title })

        var series = cleaned.series
        var seriesIndex = cleaned.seriesIndex
        var author = cleaned.author ?: book.author

        // Saga keys copied from folder names keep the uploader's prefix
        // ("Brandon Sanderson - Les Archives de Roshar"): split it the same way
        // as a title prefix so the saga compares to the official one.
        if (author == null && series != null) {
            TitleCleaner.authorPrefix(series)?.let { (found, rest) ->
                author = found
                series = rest
            }
        }

        // "Chugong - Solo Leveling 1": a ONE-word author defeats the cleaner's
        // author pattern. Recover the saga from the part after the first dash —
        // but ONLY when that part ends with a volume number: the v0.6 heuristic
        // also fired on "Brandon Sanderson - L Ensoleille" and invented a saga
        // called "L Ensoleille".
        if (series == null) {
            val after = cleaned.title.substringAfter(" - ", "").trim()
            val idx = Regex("(\\d{1,3})$").find(after)?.groupValues?.get(1)?.toDoubleOrNull()
            if (after.length >= 4 && idx != null) {
                seriesIndex = idx
                series = after.replace(Regex("\\s+\\d{1,3}$"), "").trim().takeIf { it.isNotBlank() }
            }
        }

        val rawTitle = AudibleQueries.stripReleaseTags(cleaned.title)

        // No author and no saga: "Auteur - Titre" without a volume can only be
        // split here. Measured: "L'Ensoleillé" scored 0.41 with the author left
        // in the title, 0.85 once split.
        if (author == null && series == null) {
            TitleCleaner.authorPrefix(rawTitle)?.let { (found, _) -> author = found }
        }
        val searchTitle = AudibleQueries.stripReleaseTags(
            TitleCleaner.stripAuthorPrefix(rawTitle, author),
        )
        val surname = author?.trim()?.split(Regex("\\s+"))?.lastOrNull()?.takeIf { it.length >= 3 }

        val input = MetadataMatcher.MatchInput(
            title = searchTitle,
            author = author,
            series = series,
            seriesIndex = seriesIndex,
            estimatedMs = book.durationMs,
            language = preferredLanguage,
        )

        // When the author was split off the title, the FULL folder name goes
        // first as one keyword query: measured, `keywords=brandon sanderson
        // l ensoleille` finds the book while the bare title finds nothing.
        val plan = buildList {
            if (searchTitle != rawTitle) {
                addAll(
                    AudibleQueries.plan(rawTitle, series, seriesIndex, surname)
                        .filter { it.mode == AudibleQueries.Mode.KEYWORDS }
                        .take(1),
                )
            }
            addAll(AudibleQueries.plan(searchTitle, series, seriesIndex, surname))
            if (searchTitle != rawTitle) {
                addAll(AudibleQueries.plan(rawTitle, series, seriesIndex, surname))
            }
        }.distinctBy { it.mode to it.text.lowercase(Locale.ROOT) }.take(7)

        val pool = LinkedHashMap<String, BookMetadata>()
        val trace = mutableListOf<String>()
        var calls = 0
        var successes = 0
        var lastError: String? = null

        search@ for (market in markets) {
            val catalog = AudibleCatalog(market)
            var marketCalls = 0
            for (query in plan) {
                if (marketCalls >= MAX_CALLS_PER_MARKET) break
                // v0.7.4 — the author filter is NOT sent any more. Measured:
                // the API ANDs it, so one wrong guess (a translator, a
                // pen name, "Mélanie Fazi - traducteur") zeroes an otherwise
                // perfect query, and every such retry cost a second request.
                // Disambiguation happens locally in MetadataMatcher instead.
                val result = call(catalog, query, null, trace)
                calls++
                marketCalls++
                if (result.error == null) successes++ else lastError = result.error
                result.items.forEach { pool.putIfAbsent("$market|${it.asin}", it) }
                if (pool.isNotEmpty()) {
                    // Judge the early exit on the same candidates the final
                    // ranking will use (an English clone must not stop the
                    // ladder before the French original is looked up).
                    val best = MetadataMatcher.rank(input, preferLanguage(pool.values.toList())).first()
                    if (best.second >= MetadataMatcher.AUTO_THRESHOLD) break@search
                }
            }
            // The preferred market answered: do not burn the fallback market.
            if (pool.isNotEmpty()) break
        }

        // ------------------------------------------------------------------
        // v0.7.4 — LAST-RESORT AUTHOR SWEEP.
        //
        // No ladder of short phrases can cover every way an uploader names a
        // folder. What DOES work for any bestseller is asking the catalogue
        // for the author and ranking his books locally: measured, two pages of
        // `keywords=brandon sanderson` hold 100 editions, including "Vent et
        // vérité - Volume 2" whose official title shares only a few words with
        // "Les Archives de Roshar 05 Vent et verite 2".
        //
        // The results are pre-filtered on title containment: an author match
        // alone must never decide a book.
        // ------------------------------------------------------------------
        val knownAuthor = input.author?.takeIf { it.isNotBlank() }
        val bestSoFar = if (pool.isEmpty()) 0.0
        else MetadataMatcher.rank(input, preferLanguage(pool.values.toList())).first().second
        if (knownAuthor != null && bestSoFar < MetadataMatcher.AUTO_THRESHOLD) {
            val market = markets.first()
            val catalogue = try {
                AudibleCatalog(market).sweep(knownAuthor, pages = 2)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lastError = e.message ?: e.javaClass.simpleName
                emptyList()
            }
            calls++
            if (catalogue.isNotEmpty()) successes++
            trace += "$market:balayage «$knownAuthor»→${catalogue.size}"
            catalogue
                .filter { MetadataMatcher.titleContainment(searchTitle, it) >= 0.5 }
                .forEach { pool.putIfAbsent("$market|${it.asin}", it) }
        }

        if (pool.isEmpty()) {
            // EVERY request errored → network/API problem, NOT a miss:
            // ledgering here (v0.6.1) froze all later sessions silently.
            if (calls == 0) return EnrichResult.Failed(lastError ?: "requête impossible")
            if (successes == 0) return EnrichResult.Failed(lastError ?: "réseau indisponible")
            store.markTried(book.id)
            return EnrichResult.None(trace.joinToString(", "))
        }

        val candidates = preferLanguage(pool.values.toList())
        val ranked = MetadataMatcher.rank(input, candidates)
        val best = ranked.first()
        val second = ranked.getOrNull(1)?.second ?: 0.0
        return when {
            best.second >= MetadataMatcher.AUTO_THRESHOLD -> {
                store.put(book.id, best.first)
                EnrichResult.Applied(best.first)
            }
            // Clear leader well ahead of the runner-up: safe to apply even
            // below the auto threshold (saga editions whose Audible record
            // lacks the series/sequence pair used to stall here forever).
            best.second >= 0.60 && best.second - second >= 0.10 -> {
                store.put(book.id, best.first)
                EnrichResult.Applied(best.first)
            }
            // Doubtful: surface on long press; NOT ledgered, retried later.
            best.second >= MetadataMatcher.SUGGEST_THRESHOLD -> EnrichResult.Suggest(ranked.take(5))
            else -> {
                store.markTried(book.id)
                EnrichResult.None(trace.joinToString(", "))
            }
        }
    }

    private suspend fun call(
        catalog: AudibleCatalog,
        query: AudibleQueries.Query,
        author: String?,
        trace: MutableList<String>,
    ): Call = try {
        val found = catalog.search(query, author)
        trace += "${catalog.market}:${query.mode.name.first()}«${query.text}»→${found.size}"
        Call(found, null)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        trace += "${catalog.market}:«${query.text}» erreur"
        Call(emptyList(), e.message ?: e.javaClass.simpleName)
    }

    /**
     * Manual search for the "Rechercher sur Audible" sheet. No threshold and no
     * ledger: the user asked, the user picks. An ASIN pasted in the field is
     * looked up directly on every market.
     */
    suspend fun search(
        input: MetadataMatcher.MatchInput,
        query: String,
        author: String?,
        limit: Int = 25,
    ): List<Pair<BookMetadata, Double>> {
        val clean = query.trim()
        if (clean.isBlank()) return emptyList()
        val pool = LinkedHashMap<String, BookMetadata>()
        val asin = clean.uppercase(Locale.ROOT).takeIf { ASIN.matches(it) }
        if (asin != null) {
            for (market in markets) {
                try {
                    AudibleCatalog(market).byAsin(asin)?.let { pool.putIfAbsent("$market|${it.asin}", it) }
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Exception) {
                    // One dead market must not kill a manual lookup.
                }
            }
        } else {
            val surname = author?.trim()?.split(Regex("\\s+"))?.lastOrNull()?.takeIf { it.length >= 3 }
            val plan = AudibleQueries.manual(clean, surname, title = input.title)
            for (market in markets) {
                val catalog = AudibleCatalog(market)
                var calls = 0
                for (q in plan) {
                    if (calls >= MAX_CALLS_PER_MARKET) break
                    calls++
                    val found = try {
                        catalog.search(q, author)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (_: Exception) {
                        emptyList()
                    }
                    found.forEach { pool.putIfAbsent("$market|${it.asin}", it) }
                    if (pool.size >= limit) break
                }
                if (pool.isNotEmpty()) break
            }
        }
        return MetadataMatcher.rank(input, preferLanguage(pool.values.toList())).take(limit)
    }

    /**
     * A French library must not auto-adopt the English clone of the same book:
     * when the preferred language is known, editions in another KNOWN language
     * are dropped (unknown-language entries are kept — listings often omit it).
     */
    private fun preferLanguage(candidates: List<BookMetadata>): List<BookMetadata> {
        val want = preferredLanguage ?: return candidates
        val same = candidates.filter { candidate ->
            val lang = candidate.language
            lang.isNullOrBlank() || MetadataMatcher.normalize(lang) == MetadataMatcher.normalize(want)
        }
        return if (same.isNotEmpty()) same else candidates
    }
}
