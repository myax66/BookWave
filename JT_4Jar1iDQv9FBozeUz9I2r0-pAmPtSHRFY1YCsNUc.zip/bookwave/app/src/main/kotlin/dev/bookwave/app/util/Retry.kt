package dev.bookwave.app.util

import dev.bookwave.core.util.Backoff
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import java.io.IOException

/**
 * HTTP failure carrying its status, so the retry policy can tell a *transient*
 * server problem (503, 429) from a *configuration* problem (401, 404).
 *
 * Before this, every failure was a bare `IOException("Audible HTTP 503")`:
 * the caller could only match on the message, so nothing was ever retried and
 * a single 502 during a 60-book pass aborted the whole enrichment.
 */
class HttpStatusException(val code: Int, message: String) : IOException(message) {
    val isTransient: Boolean get() = Backoff.isTransientStatus(code)
}

/** True when retrying the same request has a real chance of succeeding. */
fun Throwable.isTransient(): Boolean = when (this) {
    is HttpStatusException -> isTransient
    // Socket timeouts, DNS hiccups, dropped Wi-Fi: always worth another try.
    is java.net.SocketTimeoutException -> true
    is java.net.UnknownHostException -> true
    is java.net.ConnectException -> true
    is java.io.InterruptedIOException -> true
    is IOException -> message?.contains("HTTP 4") != true
    else -> false
}

/**
 * Runs [block] up to [backoff].maxAttempts times while the failure is
 * transient, waiting [Backoff.delayFor] between attempts.
 *
 * Cancellation is NEVER retried: a coroutine cancelled by the user (screen
 * closed, view model cleared) must stop immediately instead of sleeping and
 * hammering the network from a dead scope.
 */
suspend fun <T> withRetry(
    backoff: Backoff = Backoff.READ,
    onRetry: (attempt: Int, error: Throwable, delayMs: Long) -> Unit = { _, _, _ -> },
    block: suspend (attempt: Int) -> T,
): T {
    var attempt = 1
    while (true) {
        try {
            return block(attempt)
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (e: Exception) {
            if (attempt >= backoff.maxAttempts || !e.isTransient()) throw e
            // Spread retries between clients sharing the same server.
            val jitter = 0.5 + Math.random() * 0.5
            val wait = backoff.delayFor(attempt, jitter)
            onRetry(attempt, e, wait)
            delay(wait)
            attempt++
        }
    }
}
