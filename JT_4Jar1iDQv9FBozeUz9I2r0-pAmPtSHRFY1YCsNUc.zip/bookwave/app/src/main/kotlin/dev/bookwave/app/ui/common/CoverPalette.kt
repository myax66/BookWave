package dev.bookwave.app.ui.common

import android.graphics.Bitmap
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.palette.graphics.Palette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Dominant colours extracted from a book's cover art, used to tint the
 * full-screen player background (Apple Music / Podcasts style).
 */
data class CoverColors(
    /** Most representative colour — used as the gradient accent. */
    val dominant: Color,
    /** Dark, desaturated variant — safe for large backgrounds. */
    val darkMuted: Color,
    /** Bright accent — used sparingly for highlights. */
    val vibrant: Color,
)

/** Fallback when no cover is available (dark neutral). */
val FallbackCoverColors = CoverColors(
    dominant = Color(0xFF2C2C2E),
    darkMuted = Color(0xFF1C1C1E),
    vibrant = Color(0xFF48484A),
)

/**
 * Loads the cover bitmap (via [CoverCache]) and extracts its palette.
 * Returns null while loading; callers should fall back to [FallbackCoverColors].
 */
@Composable
fun rememberCoverColors(url: String?): CoverColors? {
    val context = LocalContext.current
    var colors by remember(url) { mutableStateOf<CoverColors?>(null) }

    LaunchedEffect(url) {
        if (url == null) {
            colors = null
            return@LaunchedEffect
        }
        val bmp: Bitmap? = withContext(Dispatchers.IO) { CoverCache.load(context, url) }
        colors = bmp?.let {
            withContext(Dispatchers.Default) { extractColors(it) }
        }
    }
    return colors
}

/** Synchronous palette extraction — call from a background dispatcher. */
fun extractColors(bitmap: Bitmap): CoverColors {
    val palette = Palette.from(bitmap).generate()
    fun swatchRgb(s: Palette.Swatch?, fallback: Int): Color =
        Color(s?.rgb ?: fallback)

    return CoverColors(
        dominant = swatchRgb(palette.dominantSwatch, 0xFF2C2C2E.toInt()),
        darkMuted = swatchRgb(
            palette.darkMutedSwatch ?: palette.darkVibrantSwatch,
            0xFF1C1C1E.toInt(),
        ),
        vibrant = swatchRgb(
            palette.vibrantSwatch ?: palette.lightVibrantSwatch,
            0xFF48484A.toInt(),
        ),
    )
}
