package dev.bookwave.app.data.alldebrid

/**
 * Hand-off point for torrents shared INTO the app (browser "share" sheet,
 * clicking a magnet: link). MainActivity drops the text here; the add-torrent
 * screen consumes it once and pre-fills its field.
 */
object PendingTorrent {

    @Volatile
    private var pending: String? = null

    /** Anything longer is not a magnet/hash and is dropped outright. */
    private const val MAX_LENGTH = 4_096
    private val HASH = Regex("^[A-Fa-f0-9]{40}$|^[A-Fa-f0-9]{64}$")

    /**
     * Accepts what a browser/app can share into Bookwave — a magnet link or a
     * bare info hash — and nothing else: the activity is exported, so any app
     * can send this intent. The value only PRE-FILLS the add field (the user
     * still confirms), but junk is not worth carrying into the UI.
     */
    fun offer(text: String?) {
        val value = text?.trim().orEmpty()
        if (value.isEmpty() || value.length > MAX_LENGTH) return
        val valid = value.startsWith("magnet:?", ignoreCase = true) || HASH.matches(value)
        if (valid) pending = value
    }

    /** True when a shared magnet/hash is waiting to be picked up. */
    fun hasPending(): Boolean = !pending.isNullOrBlank()

    /** Returns the pending payload and clears it. */
    fun consume(): String? = pending.also { pending = null }
}
