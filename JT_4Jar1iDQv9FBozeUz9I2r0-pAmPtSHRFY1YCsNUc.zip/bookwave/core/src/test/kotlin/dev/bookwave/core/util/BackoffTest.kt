package dev.bookwave.core.util

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class BackoffTest {

    @Test
    fun `delays double from the base and never exceed the ceiling`() {
        val b = Backoff(maxAttempts = 6, baseDelayMs = 500, maxDelayMs = 6_000)
        assertEquals(0L, b.delayFor(0))
        assertEquals(500L, b.delayFor(1))
        assertEquals(1_000L, b.delayFor(2))
        assertEquals(2_000L, b.delayFor(3))
        assertEquals(4_000L, b.delayFor(4))
        assertEquals(6_000L, b.delayFor(5)) // capped
        assertEquals(6_000L, b.delayFor(9)) // stays capped
    }

    @Test
    fun `jitter spreads retries but stays inside half and full delay`() {
        val b = Backoff(baseDelayMs = 1_000, maxDelayMs = 8_000)
        assertEquals(1_000L, b.delayFor(1, jitter = 1.0))
        assertEquals(500L, b.delayFor(1, jitter = 0.5))
        // A hostile jitter cannot produce a negative or absurd wait.
        assertEquals(500L, b.delayFor(1, jitter = -3.0))
        assertEquals(1_000L, b.delayFor(1, jitter = 99.0))
    }

    @Test
    fun `a long schedule is bounded by the ceiling whatever the jitter`() {
        val b = Backoff(maxAttempts = 10, baseDelayMs = 400, maxDelayMs = 4_000)
        (1..12).forEach { attempt ->
            val d = b.delayFor(attempt, jitter = 1.0)
            assertTrue(d <= 4_000L, "attempt $attempt waited $d ms")
        }
    }

    @Test
    fun `configuration errors are not retried, server hiccups are`() {
        assertFalse(Backoff.isTransientStatus(400))
        assertFalse(Backoff.isTransientStatus(401)) // wrong credentials
        assertFalse(Backoff.isTransientStatus(403))
        assertFalse(Backoff.isTransientStatus(404)) // moved or mistyped URL
        assertTrue(Backoff.isTransientStatus(408))
        assertTrue(Backoff.isTransientStatus(429)) // AllDebrid rate limit
        assertTrue(Backoff.isTransientStatus(500))
        assertTrue(Backoff.isTransientStatus(502))
        assertTrue(Backoff.isTransientStatus(503)) // loaded Nextcloud
        assertTrue(Backoff.isTransientStatus(504))
        assertFalse(Backoff.isTransientStatus(507)) // disk full: retrying is pointless
    }

    @Test
    fun `the shipped policies are sane`() {
        assertEquals(3, Backoff.READ.maxAttempts)
        assertEquals(3, Backoff.CATALOG.maxAttempts)
        // Total worst-case wait must stay well below a scan's budget.
        val total = (1 until Backoff.READ.maxAttempts).sumOf { Backoff.READ.delayFor(it) }
        assertTrue(total <= 5_000L, "a read may not wait $total ms before failing")
    }
}
