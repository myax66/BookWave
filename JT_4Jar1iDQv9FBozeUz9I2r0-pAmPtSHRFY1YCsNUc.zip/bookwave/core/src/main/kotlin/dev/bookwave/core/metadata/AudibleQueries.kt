package dev.bookwave.core.metadata

/**
 * Builds the ladder of Audible queries tried for one book.
 *
 * Live measurements (2026-10-22, api.audible.fr) drove every rule here:
 *  - `title=` is a STRICT phrase-ish match: "harry potter ecole des sorciers"
 *    finds the official edition, while the full cleaned name with its volume
 *    number and elisions ("harry potter 1 a l ecole des sorciers") returns 0;
 *  - `keywords=` is an AND over tokens and tolerates elisions ("l ensorceleuse"
 *    finds "Les Ensorceleuses"), but a wrong `author=` filter zeroes it out;
 *  - therefore: short precise TITLE queries first (series + volume), then the
 *    subtitle alone, then keyword queries carrying the rest of the title.
 *
 * Pure and side-effect free: the ladder is unit-tested, the app only executes it.
 */
object AudibleQueries {

    enum class Mode { TITLE, KEYWORDS }

    data class Query(val mode: Mode, val text: String)

    private val SEPARATORS = Regex("[^\\p{L}\\p{N}]+")
    private val TRAILING_VOLUME = Regex("\\s+(\\d{1,3})$")
    private val RELEASE_TAG = Regex("^[a-z0-9]{1,5}-[a-z0-9]{1,6}$")
    private val RELEASE_WORDS = setOf("m4b", "mp3", "flac", "web", "dl", "fr", "french", "k")
    private val ARTICLES = setOf("l", "le", "la", "les", "un", "une", "the", "a", "an", "el", "der", "die", "das")

    /** Audible's title matcher starts returning 0 around ten tokens. */
    private const val TITLE_TOKEN_LIMIT = 8

    /** `keywords` is an AND: every extra word is one more chance to hit zero. */
    private const val KEYWORDS_TOKEN_LIMIT = 6

    /**
     * @param title cleaned title (may still carry "Saga 2 - Subtitle")
     * @param series detected saga, if any
     * @param seriesIndex detected volume, if any
     * @param authorSurname last name of the guessed author (relaxed last query)
     *
     * v0.7.4 — the ladder is built from SEGMENTS, never from the folder name.
     * Measured on 2026-10-22 with "Brandon Sanderson Les Archives de Roshar 05
     * Vent et verite 2": the whole string returns 0 everywhere (`keywords` is
     * an AND over tokens), while `title=vent et verite 2` returns exactly the
     * right edition and `title=les archives de roshar 5` returns both volumes.
     * Same lesson as v0.7.2, one level up: Audible is a catalogue, not a
     * search engine — we must send it short, likely-official phrases.
     *
     * Rules:
     *  - a `title=` query never exceeds [TITLE_TOKEN_LIMIT] tokens and keeps
     *    the END of the string (the identifying words follow the saga name);
     *  - a `keywords=` query never exceeds [KEYWORDS_TOKEN_LIMIT] tokens, for
     *    the same reason: each extra word is one more chance to get zero;
     *  - the saga + volume pair comes first (it is the identity);
     *  - then the subtitle alone, with and without a trailing part number
     *    ("Vent et verite 2" → also "Vent et verite");
     *  - the full folder name is only ever tried as a keyword query, capped.
     */
    fun plan(
        title: String,
        series: String? = null,
        seriesIndex: Double? = null,
        authorSurname: String? = null,
    ): List<Query> {
        val tidyTitle = tidy(title)
        if (tidyTitle.isBlank()) return emptyList()
        val cleanSeries = series?.let(::tidy)?.takeIf { it.isNotBlank() }

        val withoutVolume = if (seriesIndex != null) removeVolume(tidyTitle, seriesIndex) else tidyTitle
        val subtitle = if (seriesIndex != null) subtitleOf(tidyTitle, cleanSeries, seriesIndex) else null
        // The words an official Audible title is most likely made of: the
        // subtitle when a saga was parsed, the whole title otherwise.
        val core = subtitle ?: withoutVolume
        val partless = withoutTrailingPart(core)

        val out = mutableListOf<Query>()
        fun add(mode: Mode, text: String?) {
            val clean = text?.let(::tidy)?.takeIf { it.isNotBlank() } ?: return
            val limited = when (mode) {
                Mode.TITLE -> last(clean, TITLE_TOKEN_LIMIT)
                Mode.KEYWORDS -> last(clean, KEYWORDS_TOKEN_LIMIT)
            }
            if (limited.isNotBlank() &&
                out.none { it.mode == mode && it.text.equals(limited, ignoreCase = true) }
            ) {
                out += Query(mode, limited)
            }
        }

        // 1. The identity: saga + volume ("harry potter 1", "les archives de roshar 5").
        if (cleanSeries != null && seriesIndex != null) {
            add(Mode.TITLE, "$cleanSeries ${formatIndex(seriesIndex)}")
        }
        // 2. No saga parsed: the LAST words of a long name are the real title
        //    ("L'Âge de la Folie 03 La Sagesse des Foules" → "la sagesse des
        //    foules", measured: 1 result, the right one).
        if (seriesIndex == null) {
            val words = withoutVolume.split(' ').filter { it.isNotBlank() }
            if (words.size >= 5) add(Mode.TITLE, words.takeLast(4).joinToString(" "))
        }
        // 3. The subtitle / core title ("vent et verite 2").
        add(Mode.TITLE, core)
        // 4. The same without a trailing part number ("vent et verite").
        if (partless != null) add(Mode.TITLE, partless)
        // 5. Loose recall on the core title.
        add(Mode.KEYWORDS, core)
        // 6. The saga alone finds every volume when titles differ wildly.
        add(Mode.KEYWORDS, cleanSeries)
        // 7. The official-looking title without its volume digit.
        add(Mode.TITLE, withoutVolume)
        // 8. The full folder name, as a keyword query only (capped).
        add(Mode.KEYWORDS, tidyTitle)
        // 9. French elisions break AND searches: retry without leading articles.
        add(Mode.KEYWORDS, deArticle(core))
        // 10. Last resort: surname + core title (one-word authors defeat the cleaner).
        if (authorSurname != null) add(Mode.KEYWORDS, "$authorSurname ${deArticle(core)}")

        return out.take(7)
    }

    /**
     * "Vent et verite 2" → "Vent et verite".
     * A trailing single digit on a multi-word title is a PART number
     * ("volume 2"), not part of the official title.
     */
    fun withoutTrailingPart(t: String): String? {
        val words = t.split(' ').filter { it.isNotBlank() }
        if (words.size < 3) return null
        val lastWord = words.last()
        if (lastWord.length != 1 || !lastWord[0].isDigit()) return null
        return words.dropLast(1).joinToString(" ").takeIf { it.isNotBlank() }
    }

    /** Keeps the END of a long phrase: the identifying words come last. */
    private fun last(s: String, limit: Int): String {
        val words = s.split(' ').filter { it.isNotBlank() }
        return if (words.size <= limit) s else words.takeLast(limit).joinToString(" ")
    }

    /** Query typed by the user in the manual search sheet (no guessing). */
    fun manual(query: String, authorSurname: String?, title: String? = null): List<Query> {
        val clean = tidy(query)
        if (clean.isBlank()) return emptyList()
        val out = mutableListOf<Query>()
        fun add(mode: Mode, text: String?) {
            val c = text?.let(::tidy)?.takeIf { it.isNotBlank() } ?: return
            if (out.none { it.mode == mode && it.text.equals(c, ignoreCase = true) }) {
                out += Query(mode, c)
            }
        }
        add(Mode.TITLE, clean)
        add(Mode.KEYWORDS, clean)
        // The user typed the saga while the sheet knows the volume: aim the
        // strict title search at that exact volume ("Solo Leveling" + 3).
        val volume = title?.let(::tidy)?.let { TRAILING_VOLUME.find(it)?.groupValues?.get(1) }
        if (volume != null && clean.split(' ').size <= 5) add(Mode.TITLE, "$clean $volume")
        add(Mode.KEYWORDS, deArticle(clean))
        if (authorSurname != null) add(Mode.KEYWORDS, "$authorSurname $clean")
        return out.take(4)
    }

    /** Lowercase letters/digits/space only — Audible is diacritic-tolerant. */
    fun tidy(s: String): String = s.replace(SEPARATORS, " ").trim()

    fun deArticle(s: String): String =
        s.split(' ').filter { it.isNotBlank() }
            .dropWhile { it.lowercase() in ARTICLES }
            .joinToString(" ")
            .ifBlank { s }

    /** Drops the standalone volume token ("Solo Leveling 3 Le reveil"). */
    fun removeVolume(title: String, index: Double): String {
        val token = formatIndex(index)
        val words = title.split(' ')
        val at = words.indexOfFirst { it == token }
        return if (at >= 0) (words.take(at) + words.drop(at + 1)).joinToString(" ").trim() else title
    }

    /** Everything after "Saga 3 -" in a cleaned title, when there is one. */
    private fun subtitleOf(title: String, series: String?, index: Double): String? {
        val token = formatIndex(index)
        val words = title.split(' ')
        val at = words.indexOfFirst { it == token }
        if (at < 0) return null
        val seriesWords = series?.split(' ')?.size ?: 0
        // Refuse a "subtitle" that is really the saga name itself.
        val tail = words.drop(at + 1).joinToString(" ").trim()
        return tail.takeIf { it.split(' ').size >= 2 && (seriesWords == 0 || !series!!.startsWith(tail, true)) }
    }

    /**
     * Drops scene-release leftovers that survive the cleaner and zero out the
     * keyword search ("… m4b-k", "… web-dl").
     */
    fun stripReleaseTags(s: String): String = s.split(' ')
        .filter { tok ->
            val t = tok.lowercase()
            !t.matches(RELEASE_TAG) && t !in RELEASE_WORDS
        }
        .joinToString(" ")
        .trim()
        .ifBlank { s }

    fun formatIndex(index: Double): String =
        if (index % 1.0 == 0.0) index.toInt().toString() else index.toString()
}
