package dev.bookwave.core.metadata

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class AudibleQueriesTest {

    @Test
    fun `saga volume starts with a strict title query on series and volume`() {
        val plan = AudibleQueries.plan(
            title = "Harry Potter 1 - A l'ecole des sorciers",
            series = "Harry Potter",
            seriesIndex = 1.0,
            authorSurname = "Rowling",
        )
        assertEquals(AudibleQueries.Mode.TITLE, plan.first().mode)
        assertEquals("Harry Potter 1", plan.first().text)
    }

    @Test
    fun `title variants drop the volume digit once the series index knows it`() {
        val plan = AudibleQueries.plan("Solo Leveling 3 - Le réveil", "Solo Leveling", 3.0)
        val titles = plan.filter { it.mode == AudibleQueries.Mode.TITLE }
            .map { MetadataMatcher.normalize(it.text) }
        assertTrue(titles.any { it == "solo leveling 3" }, "got $titles")
        assertTrue(titles.any { it == "solo leveling le reveil" }, "got $titles")
        assertTrue(titles.none { it == "solo leveling 3 le reveil" }, "volume kept: $titles")
    }

    @Test
    fun `leading french article gets a variant without it`() {
        val plan = AudibleQueries.plan("L'Ensorceleuse", null, null)
        val keywords = plan.filter { it.mode == AudibleQueries.Mode.KEYWORDS }.map { it.text.lowercase() }
        assertTrue("l ensorceleuse" in keywords, "got $keywords")
        assertTrue("ensorceleuse" in keywords, "got $keywords")
    }

    @Test
    fun `author surname only appears as the last resort`() {
        val plan = AudibleQueries.plan("Chugong - Solo Leveling 1", "Solo Leveling", 1.0, "Chugong")
        assertTrue(plan.last().text.contains("Chugong", ignoreCase = true), "got $plan")
    }

    @Test
    fun `queries are de-duplicated case-insensitively`() {
        val plan = AudibleQueries.plan("dune", null, null)
        val keys = plan.map { it.mode to it.text.lowercase() }
        assertEquals(keys.distinct(), keys)
    }

    @Test
    fun `plan never exceeds seven queries`() {
        val plan = AudibleQueries.plan(
            "Le Sang des 7 Rois 1 - La prophétie des temps anciens",
            "Le Sang des 7 Rois",
            1.0,
            "Dupont",
        )
        assertTrue(plan.size <= 7, "got ${plan.size}")
    }

    @Test
    fun `blank title has no plan`() {
        assertTrue(AudibleQueries.plan("   ", null, null).isEmpty())
    }

    @Test
    fun `release tag leftovers are stripped for search`() {
        val cleaned = AudibleQueries.stripReleaseTags("Harry Potter 1 m4b-k")
        assertEquals("Harry Potter 1", cleaned)
    }

    @Test
    fun `manual search targets the volume the sheet already knows`() {
        val plan = AudibleQueries.manual("Solo Leveling", "Chugong", title = "Solo Leveling 3")
        assertTrue(plan.any { it.mode == AudibleQueries.Mode.TITLE && it.text == "Solo Leveling 3" }, "got $plan")
    }

    @Test
    fun `long titles are clipped to stay inside the strict title matcher`() {
        val plan = AudibleQueries.plan("un deux trois quatre cinq six sept huit neuf dix onze", null, null)
        val titles = plan.filter { it.mode == AudibleQueries.Mode.TITLE }
        assertTrue(titles.all { it.text.split(' ').size <= 8 }, "got $titles")
        // The tail window goes first ("la sagesse des foules" beats an
        // 8-token blend of saga name + volume + subtitle).
        assertEquals("huit neuf dix onze", titles.first().text)
        assertTrue(titles.any { it.text.split(' ').size == 8 }, "got $titles")
    }

    @Test
    fun `a saga with its volume in the middle searches the subtitle`() {
        val plan = AudibleQueries.plan(
            title = "L'Âge de la Folie 3 - La Sagesse des Foules",
            series = "L'Âge de la Folie",
            seriesIndex = 3.0,
        )
        val titles = plan.filter { it.mode == AudibleQueries.Mode.TITLE }
            .map { MetadataMatcher.normalize(it.text) }
        assertTrue("l age de la folie 3" in titles, "got $titles")
        assertTrue("la sagesse des foules" in titles, "got $titles")
    }

    @Test
    fun `a long title without saga searches its last words`() {
        val plan = AudibleQueries.plan("L Âge de la Folie La Sagesse des Foules", null, null)
        val titles = plan.filter { it.mode == AudibleQueries.Mode.TITLE }
            .map { MetadataMatcher.normalize(it.text) }
        assertTrue("la sagesse des foules" in titles, "got $titles")
    }
}
