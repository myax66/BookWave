package dev.bookwave.core.metadata

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class MetadataMatcherTest {

    private val hp1 = BookMetadata(
        asin = "B06Y66DT8R",
        title = "Harry Potter à l'école des sorciers",
        authors = listOf("J.K. Rowling"),
        narrators = listOf("Bernard Giraudeau"),
        seriesName = "Harry Potter",
        seriesIndex = 1.0,
        runtimeMin = 501,
    )

    @Test
    fun `clean torrent name auto-matches the official edition`() {
        val input = MetadataMatcher.MatchInput(
            title = "Harry Potter 1 - A l'ecole des sorciers",
            author = null,
            series = "Harry Potter",
            seriesIndex = 1.0,
            estimatedMs = 501L * 60_000,
        )
        val s = MetadataMatcher.score(input, hp1)
        assertTrue(s >= MetadataMatcher.AUTO_THRESHOLD, "score $s should auto-apply")
    }

    @Test
    fun `accent and case differences do not matter`() {
        assertEquals(
            MetadataMatcher.tokens("L'Âge de la Folie"),
            MetadataMatcher.tokens("l'age de la folie"),
        )
    }

    @Test
    fun `wrong author keeps the match below auto`() {
        val input = MetadataMatcher.MatchInput(
            title = "Gangsta Cowboy",
            author = "Carl Hiaasen",
            estimatedMs = 600L * 60_000,
        )
        val other = hp1.copy(title = "Gangsta Cowboy", seriesName = null, seriesIndex = null, runtimeMin = 610)
        val s = MetadataMatcher.score(input, other)
        assertTrue(s < MetadataMatcher.AUTO_THRESHOLD, "score $s must not auto-apply")
    }

    @Test
    fun `same title different volume ranks the right one first`() {
        val tome2 = hp1.copy(asin = "B06Y66DXXX", title = "Harry Potter et la chambre des secrets", seriesIndex = 2.0)
        val input = MetadataMatcher.MatchInput(
            title = "Harry Potter 2 - La chambre des secrets",
            series = "Harry Potter",
            seriesIndex = 2.0,
        )
        val ranked = MetadataMatcher.rank(input, listOf(hp1, tome2))
        assertEquals(tome2.asin, ranked.first().first.asin)
    }

    @Test
    fun `absurd runtime pulls the score down`() {
        val input = MetadataMatcher.MatchInput(title = "Harry Potter 1", series = "Harry Potter", seriesIndex = 1.0, estimatedMs = 501L * 60_000)
        val bloated = hp1.copy(runtimeMin = 5_000)
        assertTrue(MetadataMatcher.score(input, bloated) < MetadataMatcher.score(input, hp1))
    }

    @Test
    fun `confirmed series and volume floor the score to auto`() {
        val input = MetadataMatcher.MatchInput(
            title = "Harry Potter 1",
            series = "Harry Potter",
            seriesIndex = 1.0,
        )
        assertTrue(MetadataMatcher.score(input, hp1) >= MetadataMatcher.AUTO_THRESHOLD)
    }

    @Test
    fun `contradicting author vetoes the series floor`() {
        val input = MetadataMatcher.MatchInput(
            title = "Harry Potter 1",
            author = "Marcel Proust",
            series = "Harry Potter",
            seriesIndex = 1.0,
        )
        assertTrue(MetadataMatcher.score(input, hp1) < MetadataMatcher.AUTO_THRESHOLD)
    }

    @Test
    fun `unrelated book lands below the suggestion threshold`() {
        val input = MetadataMatcher.MatchInput(title = "Le Sang des 7 Rois 1", estimatedMs = 700L * 60_000)
        val s = MetadataMatcher.score(input, hp1)
        assertTrue(s < MetadataMatcher.SUGGEST_THRESHOLD, "score $s should not even suggest")
    }

    // ---- v5 search overhaul -------------------------------------------------

    @Test
    fun `every series pair returned by audible is compared, not just the first`() {
        // Audible lists this book under both sagas, in an order that changes
        // from one product to the next.
        val multi = hp1.copy(
            seriesName = "Le Monde des sorciers",
            seriesIndex = 1.0,
            seriesEntries = listOf(
                SeriesRef("Le Monde des sorciers", 1.0),
                SeriesRef("Harry Potter", 1.0),
            ),
        )
        val input = MetadataMatcher.MatchInput(
            title = "Harry Potter 1",
            series = "Harry Potter",
            seriesIndex = 1.0,
        )
        assertTrue(MetadataMatcher.score(input, multi) >= MetadataMatcher.AUTO_THRESHOLD)
    }

    @Test
    fun `suffixed series names still count as the same saga`() {
        val solo = BookMetadata(
            asin = "B0H417971Y",
            title = "Solo Leveling",
            authors = listOf("Chugong"),
            seriesName = "Solo Leveling (French Edition)",
            seriesIndex = 3.0,
            runtimeMin = 500,
        )
        val input = MetadataMatcher.MatchInput(
            title = "Solo Leveling 3",
            author = "Chugong",
            series = "Solo Leveling",
            seriesIndex = 3.0,
            estimatedMs = 500L * 60_000,
        )
        assertTrue(MetadataMatcher.score(input, solo) >= MetadataMatcher.AUTO_THRESHOLD)
    }

    @Test
    fun `an english edition does not auto-replace the french one`() {
        val input = MetadataMatcher.MatchInput(
            title = "Harry Potter 1 - A l'ecole des sorciers",
            series = "Harry Potter",
            seriesIndex = 1.0,
            estimatedMs = 501L * 60_000,
            language = "french",
        )
        val french = hp1.copy(language = "french")
        val english = hp1.copy(asin = "B000ENGLISH", language = "english")
        assertTrue(MetadataMatcher.score(input, french) >= MetadataMatcher.AUTO_THRESHOLD)
        assertTrue(
            MetadataMatcher.score(input, english) < MetadataMatcher.AUTO_THRESHOLD,
            "english clone scored ${MetadataMatcher.score(input, english)}",
        )
    }

    @Test
    fun `an official subtitle does not sink the title score`() {
        val withSubtitle = hp1.copy(subtitle = "Le Monde des sorciers")
        val input = MetadataMatcher.MatchInput(
            title = "Harry Potter 1 - A l'ecole des sorciers",
            series = "Harry Potter",
            seriesIndex = 1.0,
            estimatedMs = 501L * 60_000,
        )
        assertTrue(MetadataMatcher.score(input, withSubtitle) >= MetadataMatcher.AUTO_THRESHOLD)
    }

    @Test
    fun `initials with and without punctuation are the same author`() {
        val dotted = MetadataMatcher.MatchInput(
            title = "Harry Potter 1", author = "J.K. Rowling", series = "Harry Potter", seriesIndex = 1.0,
        )
        val compact = dotted.copy(author = "JK Rowling")
        assertEquals(
            MetadataMatcher.score(dotted, hp1),
            MetadataMatcher.score(compact, hp1),
        )
    }

    @Test
    fun `a volume digit in the title is not counted twice`() {
        val input = MetadataMatcher.MatchInput(
            title = "Solo Leveling 3",
            series = "Solo Leveling",
            seriesIndex = 3.0,
        )
        val candidate = BookMetadata(
            asin = "B0H95GR62X",
            title = "Solo Leveling",
            authors = listOf("Chugong"),
            seriesName = "Solo Leveling (French Edition)",
            seriesIndex = 3.0,
            runtimeMin = 518,
        )
        // Dropping the digit from the title tokens makes the title a perfect
        // coverage match instead of a 0.8 Dice match.
        assertTrue(MetadataMatcher.score(input, candidate) >= 0.85, "got ${MetadataMatcher.score(input, candidate)}")
    }

    @Test
    fun `an author written in front of the title is not counted as title`() {
        val soleil = BookMetadata(
            asin = "B0D63GMF39",
            title = "L'Ensoleillé",
            authors = listOf("Brandon Sanderson", "Mélanie Fazi - traducteur"),
            runtimeMin = 909,
            language = "french",
        )
        // Folder literally named "Brandon Sanderson L Ensoleille" (no dash):
        // measured 0.533 before v0.7.3, i.e. "aucune édition trouvée".
        val raw = MetadataMatcher.MatchInput(
            title = "Brandon Sanderson L Ensoleille",
            language = "french",
        )
        val s = MetadataMatcher.score(raw, soleil)
        assertTrue(s >= MetadataMatcher.AUTO_THRESHOLD, "score $s should auto-apply")
        assertTrue(s >= 0.84, "the author found in the title must count as a match (got $s)")
        // The same book with the author ALREADY split must score at least as
        // well — the strip must never punish a clean input.
        val split = raw.copy(title = "L Ensoleille", author = "Brandon Sanderson")
        val sSplit = MetadataMatcher.score(split, soleil)
        assertTrue(sSplit >= s - 1e-6, "split $sSplit should be >= raw $s")
        assertTrue(sSplit >= 0.84, "score $sSplit should auto-apply")
    }

    @Test
    fun `the author strip only fires on a real prefix`() {
        val candidate = BookMetadata(
            asin = "B0TEST0001",
            title = "Le Nom du Vent",
            authors = listOf("Patrick Rothfuss"),
            runtimeMin = 800,
        )
        val input = MetadataMatcher.MatchInput(title = "Patrick Rothfuss Le Nom du Vent")
        // "Patrick Rothfuss" IS the author here, so stripping is correct;
        // a title that merely CONTAINS the name elsewhere is not stripped.
        val inside = MetadataMatcher.MatchInput(title = "Le Nom du Vent Patrick Rothfuss")
        assertTrue(
            MetadataMatcher.score(input, candidate) >= MetadataMatcher.score(inside, candidate),
            "in-front author must not score worse than trailing author",
        )
    }
}
