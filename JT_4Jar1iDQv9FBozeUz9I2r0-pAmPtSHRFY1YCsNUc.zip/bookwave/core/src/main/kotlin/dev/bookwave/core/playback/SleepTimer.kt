package dev.bookwave.core.playback

/**
 * Sleep timer modes for audiobook listening.
 *
 * [EndOfChapter] is the classic audiobook mode: stop at the chapter boundary
 * instead of a fixed duration, so the listener never wakes mid-chapter.
 */
sealed interface SleepTimerMode {
    data class Duration(val millis: Long) : SleepTimerMode {
        init {
            require(millis > 0) { "sleep duration must be > 0" }
        }
    }

    data object EndOfChapter : SleepTimerMode
    data object EndOfBook : SleepTimerMode
}

/** Pure sleep-timer logic; the player layer owns ticking and enforcement. */
object SleepTimer {

    /**
     * Remaining audio time before the timer fires, or null when no timer is
     * active for the given mode. Inputs are audio positions (not wall clock):
     * the player converts using playback speed when showing a countdown.
     */
    fun remainingAudioMs(
        mode: SleepTimerMode?,
        elapsedSinceStartMs: Long,
        positionMs: Long,
        chapterEndMs: Long?,
        bookEndMs: Long?,
    ): Long? = when (mode) {
        null -> null
        is SleepTimerMode.Duration -> (mode.millis - elapsedSinceStartMs).coerceAtLeast(0)
        SleepTimerMode.EndOfChapter -> chapterEndMs?.let { (it - positionMs).coerceAtLeast(0) }
        SleepTimerMode.EndOfBook -> bookEndMs?.let { (it - positionMs).coerceAtLeast(0) }
    }

    /** True when playback must stop now. */
    fun shouldStop(
        mode: SleepTimerMode?,
        elapsedSinceStartMs: Long,
        positionMs: Long,
        chapterEndMs: Long?,
        bookEndMs: Long?,
    ): Boolean {
        val remaining = remainingAudioMs(mode, elapsedSinceStartMs, positionMs, chapterEndMs, bookEndMs)
        return remaining != null && remaining <= 0
    }
}

/** Playback speed handling tuned for spoken audio. */
object AudioSpeed {
    const val MIN = 0.5f
    const val MAX = 3.0f

    /** Common audiobook presets; fine-grained adjustment is allowed between them. */
    val PRESETS: List<Float> = listOf(0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 2.5f, 3.0f)

    fun coerce(speed: Float): Float = speed.coerceIn(MIN, MAX)

    /** Human label like "1.5×", without locale noise. */
    fun label(speed: Float): String {
        val v = coerce(speed)
        val text = if (v == v.toInt().toFloat()) "${v.toInt()}" else
            java.util.Locale.ROOT.let { String.format(it, "%.2f", v) }.trimEnd('0').trimEnd('.')
        return "${text}×"
    }

    /** Wall-clock duration of [audioMs] played at [speed]. */
    fun wallDurationMs(audioMs: Long, speed: Float): Long {
        val s = coerce(speed)
        return (audioMs / s).toLong()
    }
}
