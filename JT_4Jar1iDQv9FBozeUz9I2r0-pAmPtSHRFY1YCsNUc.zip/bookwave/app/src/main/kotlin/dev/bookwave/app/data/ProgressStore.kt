package dev.bookwave.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dev.bookwave.core.model.ListeningProgress
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant

private val Context.dataStore by preferencesDataStore("progress")

/**
 * Persists per-book [ListeningProgress] as compact JSON blobs in DataStore
 * (replaces the SharedPreferences approach of the legacy app). Records are the
 * unit of sync: see [dev.bookwave.core.sync.SyncEngine].
 */
class ProgressStore(private val context: Context) {

    private val entriesKey = stringPreferencesKey("entries_json")
    private val revisionKey = longPreferencesKey("revision")

    val progress: Flow<List<ListeningProgress>> = context.dataStore.data.map { prefs ->
        parse(prefs[entriesKey] ?: "[]")
    }

    suspend fun upsert(entry: ListeningProgress) {
        context.dataStore.edit { prefs ->
            val current = parse(prefs[entriesKey] ?: "[]")
            val previous = current.firstOrNull { it.bookId == entry.bookId }
            // v0.8.0 — the playback service saves every 10 s; re-serialising
            // the whole list AND rewriting the DataStore file when the record
            // is byte-for-byte identical (paused player, same position) burned
            // flash and woke the disk for nothing.
            if (previous != null && previous.sameState(entry)) return@edit
            val merged = current.filterNot { it.bookId == entry.bookId } + entry
            prefs[entriesKey] = serialize(merged)
            prefs[revisionKey] = (prefs[revisionKey] ?: 0L) + 1
        }
    }

    /**
     * True when two records describe the same listening state. The timestamp
     * and the device are ignored on purpose: only what the user can perceive
     * (position, speed, completion) decides whether a write is worth it.
     */
    private fun ListeningProgress.sameState(other: ListeningProgress): Boolean =
        bookId == other.bookId &&
            positionMs == other.positionMs &&
            durationMs == other.durationMs &&
            completed == other.completed &&
            speed == other.speed

    suspend fun replaceAll(entries: List<ListeningProgress>) {
        context.dataStore.edit { prefs ->
            prefs[entriesKey] = serialize(entries)
            prefs[revisionKey] = (prefs[revisionKey] ?: 0L) + 1
        }
    }

    suspend fun revision(): Long =
        context.dataStore.data.map { it[revisionKey] ?: 0L }.first()

    private fun serialize(entries: List<ListeningProgress>): String {
        val array = JSONArray()
        entries.forEach { e ->
            array.put(
                JSONObject()
                    .put("bookId", e.bookId)
                    .put("positionMs", e.positionMs)
                    .put("durationMs", e.durationMs)
                    .put("speed", e.speed.toDouble())
                    .put("completed", e.completed)
                    .put("updatedAt", e.updatedAt.toString())
                    .put("deviceId", e.deviceId),
            )
        }
        return array.toString()
    }

    /**
     * Record-by-record recovery: ONE corrupt entry must not wipe the whole
     * local progress (the old all-or-nothing runCatching returned emptyList
     * and silently lost every book's position).
     */
    private fun parse(json: String): List<ListeningProgress> {
        val array = runCatching { JSONArray(json) }.getOrNull() ?: return emptyList()
        return buildList {
            for (i in 0 until array.length()) {
                runCatching {
                    val o = array.getJSONObject(i)
                    add(
                        ListeningProgress(
                            bookId = o.getString("bookId"),
                            positionMs = o.getLong("positionMs").coerceAtLeast(0L),
                            durationMs = o.getLong("durationMs").coerceAtLeast(0L),
                            speed = o.getDouble("speed").toFloat(),
                            completed = o.getBoolean("completed"),
                            updatedAt = Instant.parse(o.getString("updatedAt")),
                            deviceId = o.getString("deviceId"),
                        ),
                    )
                }
            }
        }
    }
}
