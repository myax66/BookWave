package dev.bookwave.core.util

/**
 * Retry policy for idempotent network reads, shared by every client
 * (Audible catalogue, WebDAV PROPFIND, AllDebrid status, cover download).
 *
 * Why a policy object and not a bare loop: the delays must be *bounded* and
 * *jittered*. A library refresh fires up to six PROPFINDs in parallel against
 * the same host; without jitter they all retry in lockstep and the server sees
 * a burst instead of a trickle — exactly what made a loaded Nextcloud answer
 * 503 in the field.
 *
 * Pure and side-effect free: the whole schedule is unit-tested.
 */
data class Backoff(
    /** Total attempts including the first one. 3 = initial + 2 retries. */
    val maxAttempts: Int = 3,
    /** First retry waits this long; each attempt doubles it. */
    val baseDelayMs: Long = 500L,
    /** Ceiling for a single wait (a 5th retry must not park a scan for a minute). */
    val maxDelayMs: Long = 6_000L,
) {
    init {
        require(maxAttempts >= 1) { "maxAttempts must be >= 1" }
        require(baseDelayMs >= 0) { "baseDelayMs must be >= 0" }
        require(maxDelayMs >= baseDelayMs) { "maxDelayMs must be >= baseDelayMs" }
    }

    /**
     * Wait before retry number [attempt] (1 = wait before the 2nd try).
     * Exponential, capped, then scaled by [jitter] in 0.5..1.0 so N clients
     * sharing a server spread their retries instead of synchronising.
     */
    fun delayFor(attempt: Int, jitter: Double = 1.0): Long {
        if (attempt <= 0) return 0L
        var d = baseDelayMs
        repeat(attempt - 1) {
            d = if (d >= maxDelayMs / 2) maxDelayMs else d * 2
        }
        val capped = d.coerceAtMost(maxDelayMs)
        val factor = jitter.coerceIn(0.5, 1.0)
        return (capped * factor).toLong().coerceAtLeast(0L)
    }

    companion object {
        /** Read-only GET/PROPFIND against a possibly sleepy self-hosted server. */
        val READ = Backoff(maxAttempts = 3, baseDelayMs = 400, maxDelayMs = 4_000)

        /** Catalogue queries: cheap, so a third attempt is fine but keep it short. */
        val CATALOG = Backoff(maxAttempts = 3, baseDelayMs = 350, maxDelayMs = 2_000)

        /**
         * Which HTTP statuses are worth a retry.
         *
         * An ALLOW-LIST, not "any 5xx": 501 (not implemented) and 507
         * (insufficient storage) are permanent answers — retrying them makes
         * the user wait for the exact same failure, and a scan that retries a
         * full disk burns 20 seconds per folder. 4xx are configuration
         * problems (wrong password, wrong URL, moved file) for the same reason.
         */
        private val RETRYABLE_STATUSES = setOf(
            408, // request timeout
            425, // too early
            429, // rate limited (AllDebrid)
            500, 502, 503, 504, // the classic "server is having a moment"
            520, 521, 522, 524, // Cloudflare: origin unreachable / timeout
        )

        fun isTransientStatus(code: Int): Boolean = code in RETRYABLE_STATUSES
    }
}
