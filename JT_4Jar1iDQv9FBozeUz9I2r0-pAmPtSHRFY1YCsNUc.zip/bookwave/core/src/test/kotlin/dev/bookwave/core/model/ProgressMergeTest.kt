package dev.bookwave.core.model

import java.time.Instant
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class ProgressMergeTest {

    private fun progress(
        positionMs: Long,
        completed: Boolean = false,
        updatedAt: String = "2026-10-18T10:00:00Z",
        deviceId: String = "phone",
    ) = ListeningProgress(
        bookId = "book-1",
        positionMs = positionMs,
        durationMs = 10_000,
        completed = completed,
        updatedAt = Instant.parse(updatedAt),
        deviceId = deviceId,
    )

    @Test
    fun completedAlwaysWins() {
        val a = progress(positionMs = 9_000, completed = true)
        val b = progress(positionMs = 9_500)
        assertEquals(true, ProgressMerge.merge(a, b).completed)
        assertEquals(true, ProgressMerge.merge(b, a).completed)
    }

    @Test
    fun furthestPositionWins() {
        val a = progress(positionMs = 3_000, deviceId = "phone")
        val b = progress(positionMs = 4_500, deviceId = "car")
        assertEquals(4_500, ProgressMerge.merge(a, b).positionMs)
        assertEquals(4_500, ProgressMerge.merge(b, a).positionMs)
    }

    @Test
    fun replayOnOtherDeviceDoesNotRewind() {
        val ahead = progress(positionMs = 8_000, updatedAt = "2026-10-18T08:00:00Z")
        val behind = progress(positionMs = 1_000, updatedAt = "2026-10-18T11:00:00Z")
        assertEquals(8_000, ProgressMerge.merge(ahead, behind).positionMs)
    }

    @Test
    fun samePositionBreaksOnRecency() {
        val older = progress(positionMs = 5_000, updatedAt = "2026-10-18T09:00:00Z", deviceId = "phone")
        val newer = progress(positionMs = 5_000, updatedAt = "2026-10-18T11:00:00Z", deviceId = "car")
        assertEquals("car", ProgressMerge.merge(older, newer).deviceId)
    }

    @Test
    fun fractionAndFinished() {
        val p = progress(positionMs = 5_000)
        assertEquals(0.5, p.fraction, 1e-9)
        assertTrue(!p.isFinished)
        val end = progress(positionMs = 10_000)
        assertTrue(end.isFinished)
    }
}
